import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { useEffect } from "react";

const themeStyles: Record<string, Record<string, string>> = {
  "mocha-mousse": {
    "--background": "oklch(0.94 0.02 345.70)",
    "--foreground": "oklch(0.47 0 0)",
    "--card": "oklch(0.95 0.05 86.89)",
    "--card-foreground": "oklch(0.47 0 0)",
    "--popover": "oklch(1.00 0 0)",
    "--popover-foreground": "oklch(0.47 0 0)",
    "--primary": "oklch(0.62 0.18 348.14)",
    "--primary-foreground": "oklch(1.00 0 0)",
    "--secondary": "oklch(0.81 0.07 198.19)",
    "--secondary-foreground": "oklch(0.32 0 0)",
    "--muted": "oklch(0.88 0.05 212.10)",
    "--muted-foreground": "oklch(0.58 0 0)",
    "--accent": "oklch(0.92 0.08 87.67)",
    "--accent-foreground": "oklch(0.32 0 0)",
    "--destructive": "oklch(0.71 0.17 21.96)",
    "--border": "oklch(0.62 0.18 348.14)",
    "--input": "oklch(0.92 0 0)",
    "--ring": "oklch(0.70 0.16 350.75)",
  },
  "sky-stream": {
    "--background": "oklch(0.98 0.01 240)",
    "--foreground": "oklch(0.20 0 240)",
    "--card": "oklch(1.00 0 0)",
    "--card-foreground": "oklch(0.20 0 240)",
    "--popover": "oklch(1.00 0 0)",
    "--popover-foreground": "oklch(0.20 0 240)",
    "--primary": "oklch(0.55 0.20 240)",
    "--primary-foreground": "oklch(1.00 0 0)",
    "--secondary": "oklch(0.85 0.08 240)",
    "--secondary-foreground": "oklch(0.20 0 240)",
    "--muted": "oklch(0.92 0.04 240)",
    "--muted-foreground": "oklch(0.50 0 240)",
    "--accent": "oklch(0.88 0.06 240)",
    "--accent-foreground": "oklch(0.20 0 240)",
    "--destructive": "oklch(0.60 0.20 25)",
    "--border": "oklch(0.85 0.08 240)",
    "--input": "oklch(0.92 0.04 240)",
    "--ring": "oklch(0.55 0.20 240)",
  },
  "nature": {
    "--background": "oklch(0.96 0.02 140)",
    "--foreground": "oklch(0.25 0 140)",
    "--card": "oklch(0.98 0.01 140)",
    "--card-foreground": "oklch(0.25 0 140)",
    "--popover": "oklch(1.00 0 0)",
    "--popover-foreground": "oklch(0.25 0 140)",
    "--primary": "oklch(0.50 0.15 140)",
    "--primary-foreground": "oklch(1.00 0 0)",
    "--secondary": "oklch(0.75 0.08 140)",
    "--secondary-foreground": "oklch(0.25 0 140)",
    "--muted": "oklch(0.88 0.04 140)",
    "--muted-foreground": "oklch(0.50 0 140)",
    "--accent": "oklch(0.85 0.06 140)",
    "--accent-foreground": "oklch(0.25 0 140)",
    "--destructive": "oklch(0.60 0.20 25)",
    "--border": "oklch(0.75 0.08 140)",
    "--input": "oklch(0.92 0.02 140)",
    "--ring": "oklch(0.50 0.15 140)",
  },
  "catppuccin": {
    "--background": "oklch(0.96 0.02 280)",
    "--foreground": "oklch(0.30 0 280)",
    "--card": "oklch(0.98 0.01 280)",
    "--card-foreground": "oklch(0.30 0 280)",
    "--popover": "oklch(1.00 0 0)",
    "--popover-foreground": "oklch(0.30 0 280)",
    "--primary": "oklch(0.70 0.12 280)",
    "--primary-foreground": "oklch(1.00 0 0)",
    "--secondary": "oklch(0.80 0.08 320)",
    "--secondary-foreground": "oklch(0.30 0 280)",
    "--muted": "oklch(0.90 0.04 280)",
    "--muted-foreground": "oklch(0.55 0 280)",
    "--accent": "oklch(0.85 0.06 30)",
    "--accent-foreground": "oklch(0.30 0 280)",
    "--destructive": "oklch(0.60 0.20 25)",
    "--border": "oklch(0.80 0.08 280)",
    "--input": "oklch(0.92 0.02 280)",
    "--ring": "oklch(0.70 0.12 280)",
  },
  "sunset-horizon": {
    "--background": "oklch(0.97 0.02 30)",
    "--foreground": "oklch(0.25 0 30)",
    "--card": "oklch(0.99 0.01 30)",
    "--card-foreground": "oklch(0.25 0 30)",
    "--popover": "oklch(1.00 0 0)",
    "--popover-foreground": "oklch(0.25 0 30)",
    "--primary": "oklch(0.65 0.18 30)",
    "--primary-foreground": "oklch(1.00 0 0)",
    "--secondary": "oklch(0.75 0.12 50)",
    "--secondary-foreground": "oklch(0.25 0 30)",
    "--muted": "oklch(0.88 0.04 30)",
    "--muted-foreground": "oklch(0.50 0 30)",
    "--accent": "oklch(0.85 0.10 45)",
    "--accent-foreground": "oklch(0.25 0 30)",
    "--destructive": "oklch(0.60 0.20 25)",
    "--border": "oklch(0.75 0.12 30)",
    "--input": "oklch(0.92 0.02 30)",
    "--ring": "oklch(0.65 0.18 30)",
  },
  "ocean-breeze": {
    "--background": "oklch(0.97 0.02 200)",
    "--foreground": "oklch(0.25 0 200)",
    "--card": "oklch(0.99 0.01 200)",
    "--card-foreground": "oklch(0.25 0 200)",
    "--popover": "oklch(1.00 0 0)",
    "--popover-foreground": "oklch(0.25 0 200)",
    "--primary": "oklch(0.58 0.15 200)",
    "--primary-foreground": "oklch(1.00 0 0)",
    "--secondary": "oklch(0.78 0.10 200)",
    "--secondary-foreground": "oklch(0.25 0 200)",
    "--muted": "oklch(0.90 0.04 200)",
    "--muted-foreground": "oklch(0.50 0 200)",
    "--accent": "oklch(0.85 0.08 200)",
    "--accent-foreground": "oklch(0.25 0 200)",
    "--destructive": "oklch(0.60 0.20 25)",
    "--border": "oklch(0.78 0.10 200)",
    "--input": "oklch(0.92 0.02 200)",
    "--ring": "oklch(0.58 0.15 200)",
  },
};

export function UserThemeProvider({ children }: { children: React.ReactNode }) {
  const currentUser = useQuery(api.users.getCurrentUser);

  useEffect(() => {
    if (currentUser?.colorProfile && themeStyles[currentUser.colorProfile]) {
      const theme = themeStyles[currentUser.colorProfile];
      const root = document.documentElement;

      // Apply theme styles
      Object.entries(theme).forEach(([property, value]) => {
        root.style.setProperty(property, value);
      });
    }
  }, [currentUser?.colorProfile]);

  return <>{children}</>;
}
