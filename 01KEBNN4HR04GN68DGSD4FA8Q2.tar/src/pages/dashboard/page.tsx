import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import {
  Calendar,
  Users,
  FileText,
  TrendingUp,
  ChevronRight,
  MessageSquare,
  ThumbsUp,
  Send,
  Bell,
  BellOff,
  Archive,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge.tsx";
import { format } from "date-fns";
import { Textarea } from "@/components/ui/textarea.tsx";
import { ScrollArea } from "@/components/ui/scroll-area.tsx";
import { useState, useRef, useEffect } from "react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { ConvexError } from "convex/values";

const quickActions = [
  {
    title: "Start a Reading Plan",
    description: "Create or join a structured reading schedule",
    icon: Calendar,
    href: "/plans",
    comingSoon: false,
  },
  {
    title: "Join a Group",
    description: "Connect with other readers in a community",
    icon: Users,
    href: "/groups",
    comingSoon: false,
  },
];

// Individual Group Chat Component
function GroupChatCard({ groupId, groupName }: { groupId: Id<"groups">; groupName: string }) {
  const messages = useQuery(api.groupMessages.getGroupMessages, { groupId });
  const sendMessage = useMutation(api.groupMessages.send);
  const [messageContent, setMessageContent] = useState("");
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageContent.trim()) return;

    setIsSending(true);
    try {
      await sendMessage({
        groupId,
        content: messageContent.trim(),
      });
      setMessageContent("");
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to send message");
      }
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Group Chat: {groupName}</span>
          <Link to={`/groups/${groupId}`}>
            <Button variant="ghost" size="sm">
              View Group
            </Button>
          </Link>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Messages */}
        <ScrollArea className="h-[300px] rounded-lg border border-border p-4">
          {!messages || messages.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No messages yet. Start the conversation!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message._id}
                  className={`flex gap-3 ${message.isAuthor ? "flex-row-reverse" : ""}`}
                >
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarImage src={message.authorAvatar ?? undefined} />
                    <AvatarFallback>
                      {getInitials(message.authorName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`flex-1 ${message.isAuthor ? "text-right" : ""}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium text-foreground">
                        {message.authorName}
                      </p>
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(message._creationTime), "h:mm a")}
                      </span>
                    </div>
                    <div
                      className={`inline-block px-3 py-2 rounded-lg ${
                        message.isAuthor
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap break-words">
                        {message.content}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>

        {/* Message Input */}
        <form onSubmit={handleSendMessage} className="space-y-2">
          <Textarea
            value={messageContent}
            onChange={(e) => setMessageContent(e.target.value)}
            placeholder="Type your message..."
            rows={2}
            className="resize-none"
            disabled={isSending}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage(e);
              }
            }}
          />
          <div className="flex justify-end">
            <Button type="submit" size="sm" disabled={isSending || !messageContent.trim()}>
              <Send className="h-4 w-4 mr-2" />
              {isSending ? "Sending..." : "Send"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

function DashboardContent() {
  const currentUser = useQuery(api.users.getCurrentUser);
  const myPlans = useQuery(api.readingPlans.getMyPlans);
  const myGroups = useQuery(api.groups.getMyGroups);
  const recentReflections = useQuery(api.reflections.getRecentReflections);
  const groupChats = useQuery(api.groupMessages.getAllGroupChats);

  const archiveReflection = useMutation(api.reflections.archiveReflection);
  const deleteReflection = useMutation(api.reflections.deleteReflection);

  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [notificationsSupported, setNotificationsSupported] = useState(false);
  const [processingReflectionId, setProcessingReflectionId] = useState<Id<"reflections"> | null>(null);

  // Check notification support
  useEffect(() => {
    if ("Notification" in window && "serviceWorker" in navigator) {
      setNotificationsSupported(true);
      setNotificationsEnabled(Notification.permission === "granted");
    }
  }, []);

  const ReadingPlansIcon = () => <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-5 w-5 sm:h-6 sm:w-6 object-contain" />;
  
  const stats = [
    { label: "Reading Plans", value: myPlans?.length.toString() || "0", icon: ReadingPlansIcon },
    { label: "Groups Joined", value: myGroups?.length.toString() || "0", icon: Users },
    { label: "Reflections", value: "0", icon: FileText },
    { label: "Day Streak", value: "0", icon: TrendingUp },
  ];

  const handleComingSoon = () => {
    toast.info("Coming soon in a future milestone!");
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const requestNotificationPermission = async () => {
    if (!notificationsSupported) {
      toast.error("Push notifications are not supported in this browser");
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        setNotificationsEnabled(true);
        toast.success("Notifications enabled!");
        
        // Show a test notification
        new Notification("Read Reflect React", {
          body: "You'll now receive notifications for group messages and updates",
          icon: "https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk",
        });
      } else {
        toast.error("Notification permission denied");
      }
    } catch (error) {
      toast.error("Failed to request notification permission");
    }
  };

  const toggleNotifications = () => {
    if (!notificationsEnabled) {
      requestNotificationPermission();
    } else {
      toast.info("To disable notifications, please change your browser settings");
    }
  };

  const handleArchiveReflection = async (reflectionId: Id<"reflections">, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    setProcessingReflectionId(reflectionId);
    try {
      await archiveReflection({ reflectionId });
      toast.success("Reflection archived");
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to archive reflection");
      }
    } finally {
      setProcessingReflectionId(null);
    }
  };

  const handleDeleteReflection = async (reflectionId: Id<"reflections">, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!confirm("Are you sure you want to delete this reflection? This action cannot be undone.")) {
      return;
    }

    setProcessingReflectionId(reflectionId);
    try {
      await deleteReflection({ reflectionId });
      toast.success("Reflection deleted");
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to delete reflection");
      }
    } finally {
      setProcessingReflectionId(null);
    }
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16 border-2 border-primary/20">
            <AvatarImage src={currentUser?.avatarUrl ?? undefined} />
            <AvatarFallback className="text-lg">
              {getInitials(currentUser?.name)}
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
              Welcome back, {currentUser?.name?.split(" ")[0] || "Reader"}!
            </h1>
            <p className="text-muted-foreground">
              {currentUser?.readingGoal || "Ready to dive into some reading?"}
            </p>
          </div>
        </div>
        {notificationsSupported && (
          <Button
            variant={notificationsEnabled ? "default" : "outline"}
            size="sm"
            onClick={toggleNotifications}
            className="gap-2"
          >
            {notificationsEnabled ? (
              <>
                <Bell className="h-4 w-4" />
                Notifications On
              </>
            ) : (
              <>
                <BellOff className="h-4 w-4" />
                Enable Notifications
              </>
            )}
          </Button>
        )}
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {stats.map((stat, index) => (
          <Card key={stat.label} className="overflow-hidden">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl sm:text-3xl font-bold text-foreground mt-1">
                    {stat.value}
                  </p>
                </div>
                <div
                  className="h-10 w-10 sm:h-12 sm:w-12 rounded-xl bg-primary/10 flex items-center justify-center"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <stat.icon className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="hidden"
      >
        <h2 className="text-xl font-semibold text-foreground mb-4">
          Quick Actions
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickActions.map((action) => (
            action.comingSoon ? (
              <div
                key={action.title}
                onClick={handleComingSoon}
              >
                <Card className="cursor-pointer hover:shadow-md transition-shadow group">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                        <action.icon className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                          {action.title}
                        </h3>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Link
                key={action.title}
                to={action.href}
              >
                <Card className="cursor-pointer hover:shadow-md transition-shadow group">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                        <action.icon className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                          {action.title}
                        </h3>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            )
          ))}
        </div>
      </motion.div>

      {/* Current Reading Plans */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>My Reading Plans</span>
              <Link to="/plans">
                <Button variant="ghost" size="sm">
                  View All
                </Button>
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!myPlans || myPlans.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <Calendar />
                  </EmptyMedia>
                  <EmptyTitle>No reading plans yet</EmptyTitle>
                  <EmptyDescription>
                    Start your reading journey by creating or joining a plan
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Link to="/plans/browse">
                    <Button size="sm">
                      Browse Plans
                    </Button>
                  </Link>
                </EmptyContent>
              </Empty>
            ) : (
              <div className="space-y-3">
                {myPlans.slice(0, 3).map((plan) => {
                  // Construct the URL with reading ID if currentReading exists
                  const planUrl = plan.currentReading 
                    ? `/plans/${plan._id}?reading=${plan.currentReading._id}`
                    : `/plans/${plan._id}`;
                  
                  return (
                    <Link key={plan._id} to={planUrl}>
                      <div className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors group">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-foreground group-hover:text-primary transition-colors">
                            {plan.title}
                          </h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            {plan.entriesCount} readings · {plan.userProgress}% complete
                          </p>
                          {plan.currentReading && (
                            <div className="mt-2 pt-2 border-t border-border/50">
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Calendar className="h-3 w-3" />
                                <span className="font-medium">
                                  {plan.currentReading.scheduledDate === new Date().toISOString().split("T")[0]
                                    ? "Today's Reading"
                                    : "Next Reading"}:
                                </span>
                              </div>
                              <p className="text-sm text-foreground mt-1 font-medium">
                                {plan.currentReading.title}
                              </p>
                              {plan.currentReading.bibleReferences && plan.currentReading.bibleReferences.length > 0 && (
                                <p className="text-xs text-muted-foreground mt-0.5">
                                  {plan.currentReading.bibleReferences.join(", ")}
                                </p>
                              )}
                              {plan.currentReading.scheduledDate && (
                                <p className="text-xs text-muted-foreground mt-0.5">
                                  {new Date(plan.currentReading.scheduledDate).toLocaleDateString("en-US", {
                                    weekday: "short",
                                    month: "short",
                                    day: "numeric",
                                  })}
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Recent Reflections (Last 7 Days) */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>My Recent Reflections</span>
              <Link to="/reflections">
                <Button variant="ghost" size="sm">
                  View All
                </Button>
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!recentReflections || recentReflections.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <MessageSquare />
                  </EmptyMedia>
                  <EmptyTitle>No recent reflections</EmptyTitle>
                  <EmptyDescription>
                    Start reflecting on your reading journey
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Link to="/plans">
                    <Button size="sm">
                      Go to Plans
                    </Button>
                  </Link>
                </EmptyContent>
              </Empty>
            ) : (
              <div className="space-y-4">
                {recentReflections.slice(0, 5).map((reflection) => (
                  <Link key={reflection._id} to={`/plans/${reflection.planId}`}>
                    <div className="p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="secondary" className="text-xs">
                              {reflection.planTitle}
                            </Badge>
                            {reflection.entryTitle && (
                              <span className="text-xs text-muted-foreground">
                                • {reflection.entryTitle}
                                {reflection.entryScheduledDate && (
                                  <span className="ml-1">
                                    ({new Date(reflection.entryScheduledDate).toLocaleDateString()})
                                  </span>
                                )}
                              </span>
                            )}
                          </div>
                          {reflection.questionText && (
                            <p className="text-xs font-medium text-primary mb-1">
                              Q: {reflection.questionText}
                            </p>
                          )}
                          <p className="text-sm text-foreground line-clamp-2 mb-2">
                            {reflection.content}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>
                              {format(new Date(reflection._creationTime), "MMM d, yyyy")}
                            </span>
                            <div className="flex items-center gap-1">
                              <ThumbsUp className="h-3 w-3" />
                              {reflection.likeCount}
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageSquare className="h-3 w-3" />
                              {reflection.commentCount}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={(e) => handleArchiveReflection(reflection._id, e)}
                            disabled={processingReflectionId === reflection._id}
                            title="Archive reflection"
                          >
                            <Archive className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={(e) => handleDeleteReflection(reflection._id, e)}
                            disabled={processingReflectionId === reflection._id}
                            title="Delete reflection"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* My Groups */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>My Groups</span>
              <Link to="/groups">
                <Button variant="ghost" size="sm">
                  View All
                </Button>
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!myGroups || myGroups.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <Users />
                  </EmptyMedia>
                  <EmptyTitle>No groups joined</EmptyTitle>
                  <EmptyDescription>
                    Connect with other readers by joining a community group
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Link to="/groups">
                    <Button size="sm">
                      Find Groups
                    </Button>
                  </Link>
                </EmptyContent>
              </Empty>
            ) : (
              <div className="space-y-3">
                {myGroups.slice(0, 3).map((group) => (
                  <Link key={group._id} to={`/groups/${group._id}`}>
                    <div className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors group">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-foreground group-hover:text-primary transition-colors">
                          {group.name}
                        </h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          {group.memberCount} {group.memberCount === 1 ? 'member' : 'members'}
                        </p>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Group Chats */}
      {groupChats && groupChats.length > 0 && groupChats.map((chat, index) => (
        <motion.div
          key={chat.groupId}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 + (index * 0.1) }}
        >
          <GroupChatCard groupId={chat.groupId} groupName={chat.groupName} />
        </motion.div>
      ))}
    </div>
  );
}

export default function Dashboard() {
  return (
    <AppLayout>
      <div 
        className="relative -m-4 sm:-m-6 lg:-m-8 p-4 sm:p-6 lg:p-8 min-h-[calc(100vh-4rem)] lg:min-h-screen bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.7), rgba(255, 255, 255, 0.7)), url('https://cdn.hercules.app/file_QbSoU8y6OuweoxCL7RsJqdNx')`,
        }}
      >
        <DashboardContent />
      </div>
    </AppLayout>
  );
}
