import { motion } from "motion/react";
import {
  BookOpen,
  Users,
  Target,
  MessageSquare,
  Calendar,
  Lock,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";
import { useAuth } from "@/hooks/use-auth.ts";
import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";

const features = [
  {
    icon: BookOpen,
    title: "Structured Reading Plans",
    description:
      "Create daily, weekly, or custom reading schedules with flexible options and reminders to keep you on track.",
  },
  {
    icon: Users,
    title: "Community Groups",
    description:
      "Join or create groups to read together, share insights, and stay accountable with like-minded readers.",
  },
  {
    icon: Target,
    title: "Progress Tracking",
    description:
      "Monitor your reading journey with visual progress indicators and celebrate milestones along the way.",
  },
  {
    icon: MessageSquare,
    title: "Reflections & Reactions",
    description:
      "Document your thoughts, reactions, and insights as you read. Share them publicly or keep them private.",
  },
  {
    icon: Calendar,
    title: "Flexible Scheduling",
    description:
      "Set your own pace with customizable schedules that adapt to your lifestyle and reading goals.",
  },
  {
    icon: Lock,
    title: "Privacy Controls",
    description:
      "Choose what to share and with whom. Keep reflections private, share with groups, or go public.",
  },
];

const steps = [
  {
    number: "01",
    title: "Create Your Profile",
    description: "Sign up and set your reading preferences and goals.",
  },
  {
    number: "02",
    title: "Join or Create a Plan",
    description: "Find a reading plan or create your own custom schedule.",
  },
  {
    number: "03",
    title: "Connect with Others",
    description: "Join groups to read together and share your journey.",
  },
  {
    number: "04",
    title: "Read, Reflect, React",
    description: "Track progress, write reflections, and engage with the community.",
  },
];

export default function Index() {
  const { user } = useAuth();
  const totalUsers = useQuery(api.users.getTotalUsers);
  const landingContent = useQuery(api.landingPage.getContent);

  return (
    <div className="min-h-screen bg-background pt-12">
      {/* Navigation */}
      <nav className="fixed top-12 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <img 
                src={landingContent?.logoUrl || "https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk"} 
                alt="Read Reflect React Logo" 
                className="h-10 w-10 object-contain"
              />
              <span className="text-xl font-bold text-foreground">
                Read Reflect React
              </span>
            </div>
            <div className="flex items-center gap-4">
              {user ? (
                <Link to="/dashboard">
                  <Button>Go to Dashboard</Button>
                </Link>
              ) : (
                <SignInButton />
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/10" />
        <div className="max-w-7xl mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium">
                <Sparkles className="h-4 w-4" />
                {landingContent?.heroSubtitle || "Build consistent reading habits"}
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground text-balance">
                {landingContent?.heroTitle || "Read Together. Grow Together."}
              </h1>
              <p className="text-xl text-muted-foreground max-w-xl">
                {landingContent?.heroDescription ||
                  "A community-driven platform designed to help you build consistent reading habits, connect with like-minded readers, and transform how you engage with what you read."}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <SignInButton>
                  <Button size="lg" className="gap-2">
                    Get Started Free
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </SignInButton>
                <Button size="lg" variant="secondary">
                  Learn More
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src={landingContent?.heroImageUrl || "https://cdn.hercules.app/file_zeQ0h2yMdWHQm4HUHBntzgcy"}
                  alt="Community gathering together"
                  className="w-full h-[400px] lg:h-[500px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
              </div>
              {/* Floating stats card */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="absolute -left-4 bottom-8 bg-card border border-border rounded-xl p-4 shadow-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">
                      {totalUsers ?? 0}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Active Readers
                    </p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              {landingContent?.featuresTitle || "Everything You Need to Read Better"}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {landingContent?.featuresDescription ||
                "Powerful tools designed to help you build lasting reading habits and connect with a supportive community."}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow border-border/50 bg-card/50 backdrop-blur-sm">
                  <CardContent className="pt-6">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              {landingContent?.howItWorksTitle || "How It Works"}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {landingContent?.howItWorksDescription ||
                "Get started in minutes and begin your journey to better reading habits."}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
                className="relative"
              >
                <div className="text-6xl font-bold text-primary/10 mb-4">
                  {step.number}
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  {step.title}
                </h3>
                <p className="text-muted-foreground">{step.description}</p>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-primary/20 to-transparent -translate-x-8" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img
                src={landingContent?.missionImageUrl || "https://cdn.hercules.app/file_ICeWFA5jMtFvV2TMpvNstTbJ"}
                alt="People reading together"
                className="rounded-2xl shadow-xl object-cover h-[400px] w-full"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
                {landingContent?.missionTitle || "Our Mission"}
              </h2>
              <p className="text-lg text-muted-foreground">
                {landingContent?.missionParagraph1 ||
                  "We believe that consistent reading and meeting with others is a powerful habit for personal growth, spiritual development, and the joy of learning."}
              </p>
              <p className="text-lg text-muted-foreground">
                {landingContent?.missionParagraph2 ||
                  "Read Reflect React provides structure, community support, and tracking tools to help you stay accountable and connected. Highlight how readings inspire change, review commitments privately, or share them with groups."}
              </p>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2 text-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary" />
                  Personal Growth
                </div>
                <div className="flex items-center gap-2 text-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary" />
                  Spiritual Development
                </div>
                <div className="flex items-center gap-2 text-foreground">
                  <div className="h-2 w-2 rounded-full bg-primary" />
                  Community Connection
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-gradient-to-br from-primary/10 via-accent/5 to-primary/5 rounded-3xl p-12 border border-border/50"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              {landingContent?.ctaTitle || "Ready to Transform Your Reading?"}
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              {landingContent?.ctaDescription ||
                "Join thousands of readers who are building better habits, deeper understanding, and meaningful connections through Read Reflect React."}
            </p>
            <SignInButton>
              <Button size="lg" className="gap-2">
                Start Your Journey
                <ChevronRight className="h-4 w-4" />
              </Button>
            </SignInButton>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <img 
                src={landingContent?.logoUrl || "https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk"} 
                alt="Read Reflect React Logo" 
                className="h-8 w-8 object-contain"
              />
              <span className="text-lg font-semibold text-foreground">
                Read Reflect React
              </span>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">
                About
              </a>
              <a href="#" className="hover:text-foreground transition-colors">
                Features
              </a>
              <a href="#" className="hover:text-foreground transition-colors">
                Contact
              </a>
              <a href="#" className="hover:text-foreground transition-colors">
                Privacy
              </a>
            </div>
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Read Reflect React. All rights
              reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
