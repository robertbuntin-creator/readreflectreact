import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import AppLayout from "@/components/layout/app-layout.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { MoreVertical, Users, BookOpen, UsersRound, FileText, Shield, ShieldOff, Trash2, Image as ImageIcon, Upload, Copy, Check, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { ConvexError } from "convex/values";

export default function Admin() {
  const currentUser = useQuery(api.users.getCurrentUser);
  
  // Only fetch admin data if user is loaded and is admin
  const isAdmin = currentUser?.role === "admin";
  
  const stats = useQuery(api.admin.getPlatformStats, isAdmin ? {} : "skip");
  const users = useQuery(api.admin.getAllUsers, isAdmin ? {} : "skip");
  const plans = useQuery(api.admin.getAllPlans, isAdmin ? {} : "skip");
  const groups = useQuery(api.admin.getAllGroups, isAdmin ? {} : "skip");
  const reflections = useQuery(api.admin.getAllReflections, isAdmin ? {} : "skip");
  const mediaFiles = useQuery(api.admin.getAllMediaFiles, isAdmin ? {} : "skip");
  const feedback = useQuery(api.admin.getAllFeedback, isAdmin ? {} : "skip");

  const updateUserRole = useMutation(api.admin.updateUserRole);
  const deleteUser = useMutation(api.admin.deleteUser);
  const updatePlanStatus = useMutation(api.admin.updatePlanStatus);
  const deletePlan = useMutation(api.admin.deletePlan);
  const deleteGroup = useMutation(api.admin.deleteGroup);
  const deleteReflection = useMutation(api.admin.deleteReflection);
  const generateMediaUploadUrl = useMutation(api.admin.generateMediaUploadUrl);
  const saveMediaFile = useMutation(api.admin.saveMediaFile);
  const deleteMediaFile = useMutation(api.admin.deleteMediaFile);
  const updateFeedbackStatus = useMutation(api.admin.updateFeedbackStatus);
  const updateFeedbackPriority = useMutation(api.admin.updateFeedbackPriority);
  const deleteFeedback = useMutation(api.admin.deleteFeedback);

  const landingContent = useQuery(api.landingPage.getContent, isAdmin ? {} : "skip");
  const updateLandingContent = useMutation(api.landingPage.updateContent);

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{
    type: "user" | "plan" | "group" | "reflection" | "media" | "feedback";
    id: Id<"users"> | Id<"readingPlans"> | Id<"groups"> | Id<"reflections"> | Id<"mediaFiles"> | Id<"feedback">;
    name: string;
  } | null>(null);
  
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadCategory, setUploadCategory] = useState<"icon" | "background" | "image" | "other">("image");
  const [uploadDescription, setUploadDescription] = useState("");
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Landing page content form state
  const [landingForm, setLandingForm] = useState({
    // Landing Page
    heroTitle: "",
    heroSubtitle: "",
    heroDescription: "",
    featuresTitle: "",
    featuresDescription: "",
    howItWorksTitle: "",
    howItWorksDescription: "",
    missionTitle: "",
    missionParagraph1: "",
    missionParagraph2: "",
    ctaTitle: "",
    ctaDescription: "",
    logoUrl: "",
    heroImageUrl: "",
    missionImageUrl: "",
    inviteDialogTitle: "",
    inviteDialogDescription: "",
    inviteDialogHelpText: "",
    // Dashboard
    dashboardWelcome: "",
    dashboardSubtitle: "",
    // My Plans
    myPlansTitle: "",
    myPlansEmptyTitle: "",
    myPlansEmptyDescription: "",
    myPlansCreateButton: "",
    myPlansBrowseButton: "",
    // Browse Plans
    browsePlansTitle: "",
    browsePlansDescription: "",
    // Start Reading Plan
    startPlanTitle: "",
    startPlanDescription: "",
    startPlanBrowseTitle: "",
    startPlanBrowseDescription: "",
    startPlanBrowseBullet1: "",
    startPlanBrowseBullet2: "",
    startPlanBrowseBullet3: "",
    startPlanBrowseButton: "",
    startPlanCreateTitle: "",
    startPlanCreateDescription: "",
    startPlanCreateBullet1: "",
    startPlanCreateBullet2: "",
    startPlanCreateBullet3: "",
    startPlanCreateButton: "",
    startPlanTipTitle: "",
    startPlanTipDescription: "",
    // Create Plan
    createPlanTitle: "",
    createPlanDescription: "",
    // Groups
    myGroupsTitle: "",
    myGroupsEmptyTitle: "",
    myGroupsEmptyDescription: "",
    // Browse Groups
    browseGroupsTitle: "",
    browseGroupsDescription: "",
    // Profile
    profileTitle: "",
    profileDescription: "",
    // Reflections
    reflectionsTitle: "",
    reflectionsEmptyTitle: "",
    reflectionsEmptyDescription: "",
    // Feedback
    feedbackTitle: "",
    feedbackDescription: "",
  });
  const [isSavingLanding, setIsSavingLanding] = useState(false);

  // Initialize landing page form when content loads
  useEffect(() => {
    if (landingContent) {
      setLandingForm({
        // Landing Page
        heroTitle: landingContent.heroTitle,
        heroSubtitle: landingContent.heroSubtitle,
        heroDescription: landingContent.heroDescription,
        featuresTitle: landingContent.featuresTitle,
        featuresDescription: landingContent.featuresDescription,
        howItWorksTitle: landingContent.howItWorksTitle,
        howItWorksDescription: landingContent.howItWorksDescription,
        missionTitle: landingContent.missionTitle,
        missionParagraph1: landingContent.missionParagraph1,
        missionParagraph2: landingContent.missionParagraph2,
        ctaTitle: landingContent.ctaTitle,
        ctaDescription: landingContent.ctaDescription,
        logoUrl: landingContent.logoUrl || "",
        heroImageUrl: landingContent.heroImageUrl || "",
        missionImageUrl: landingContent.missionImageUrl || "",
        inviteDialogTitle: landingContent.inviteDialogTitle || "",
        inviteDialogDescription: landingContent.inviteDialogDescription || "",
        inviteDialogHelpText: landingContent.inviteDialogHelpText || "",
        // Dashboard
        dashboardWelcome: landingContent.dashboardWelcome || "",
        dashboardSubtitle: landingContent.dashboardSubtitle || "",
        // My Plans
        myPlansTitle: landingContent.myPlansTitle || "",
        myPlansEmptyTitle: landingContent.myPlansEmptyTitle || "",
        myPlansEmptyDescription: landingContent.myPlansEmptyDescription || "",
        myPlansCreateButton: landingContent.myPlansCreateButton || "",
        myPlansBrowseButton: landingContent.myPlansBrowseButton || "",
        // Browse Plans
        browsePlansTitle: landingContent.browsePlansTitle || "",
        browsePlansDescription: landingContent.browsePlansDescription || "",
        // Start Reading Plan
        startPlanTitle: landingContent.startPlanTitle || "",
        startPlanDescription: landingContent.startPlanDescription || "",
        startPlanBrowseTitle: landingContent.startPlanBrowseTitle || "",
        startPlanBrowseDescription: landingContent.startPlanBrowseDescription || "",
        startPlanBrowseBullet1: landingContent.startPlanBrowseBullet1 || "",
        startPlanBrowseBullet2: landingContent.startPlanBrowseBullet2 || "",
        startPlanBrowseBullet3: landingContent.startPlanBrowseBullet3 || "",
        startPlanBrowseButton: landingContent.startPlanBrowseButton || "",
        startPlanCreateTitle: landingContent.startPlanCreateTitle || "",
        startPlanCreateDescription: landingContent.startPlanCreateDescription || "",
        startPlanCreateBullet1: landingContent.startPlanCreateBullet1 || "",
        startPlanCreateBullet2: landingContent.startPlanCreateBullet2 || "",
        startPlanCreateBullet3: landingContent.startPlanCreateBullet3 || "",
        startPlanCreateButton: landingContent.startPlanCreateButton || "",
        startPlanTipTitle: landingContent.startPlanTipTitle || "",
        startPlanTipDescription: landingContent.startPlanTipDescription || "",
        // Create Plan
        createPlanTitle: landingContent.createPlanTitle || "",
        createPlanDescription: landingContent.createPlanDescription || "",
        // Groups
        myGroupsTitle: landingContent.myGroupsTitle || "",
        myGroupsEmptyTitle: landingContent.myGroupsEmptyTitle || "",
        myGroupsEmptyDescription: landingContent.myGroupsEmptyDescription || "",
        // Browse Groups
        browseGroupsTitle: landingContent.browseGroupsTitle || "",
        browseGroupsDescription: landingContent.browseGroupsDescription || "",
        // Profile
        profileTitle: landingContent.profileTitle || "",
        profileDescription: landingContent.profileDescription || "",
        // Reflections
        reflectionsTitle: landingContent.reflectionsTitle || "",
        reflectionsEmptyTitle: landingContent.reflectionsEmptyTitle || "",
        reflectionsEmptyDescription: landingContent.reflectionsEmptyDescription || "",
        // Feedback
        feedbackTitle: landingContent.feedbackTitle || "",
        feedbackDescription: landingContent.feedbackDescription || "",
      });
    }
  }, [landingContent]);

  // Loading state
  if (currentUser === undefined) {
    return (
      <AppLayout>
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-12 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </div>
        </div>
      </AppLayout>
    );
  }

  // Check if current user is admin
  if (!currentUser || currentUser.role !== "admin") {
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto text-center py-12">
          <div className="rounded-lg border border-border bg-card p-8">
            <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-muted-foreground">
              You need admin privileges to access this page.
            </p>
          </div>
        </div>
      </AppLayout>
    );
  }

  const handleRoleToggle = async (userId: Id<"users">, currentRole: "user" | "admin" | undefined) => {
    try {
      const newRole = currentRole === "admin" ? "user" : "admin";
      await updateUserRole({ userId, role: newRole });
      toast.success(`User role updated to ${newRole}`);
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to update user role");
      }
    }
  };

  const handlePlanStatusChange = async (planId: Id<"readingPlans">, status: "draft" | "pending_approval" | "published" | "archived") => {
    try {
      await updatePlanStatus({ planId, status });
      toast.success(`Plan status updated to ${status}`);
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to update plan status");
      }
    }
  };

  const confirmDelete = (
    type: "user" | "plan" | "group" | "reflection" | "media" | "feedback",
    id: Id<"users"> | Id<"readingPlans"> | Id<"groups"> | Id<"reflections"> | Id<"mediaFiles"> | Id<"feedback">,
    name: string
  ) => {
    setDeleteTarget({ type, id, name });
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;

    try {
      switch (deleteTarget.type) {
        case "user":
          await deleteUser({ userId: deleteTarget.id as Id<"users"> });
          toast.success("User deleted successfully");
          break;
        case "plan":
          await deletePlan({ planId: deleteTarget.id as Id<"readingPlans"> });
          toast.success("Plan deleted successfully");
          break;
        case "group":
          await deleteGroup({ groupId: deleteTarget.id as Id<"groups"> });
          toast.success("Group deleted successfully");
          break;
        case "reflection":
          await deleteReflection({ reflectionId: deleteTarget.id as Id<"reflections"> });
          toast.success("Reflection deleted successfully");
          break;
        case "media":
          await deleteMediaFile({ mediaId: deleteTarget.id as Id<"mediaFiles"> });
          toast.success("Media file deleted successfully");
          break;
        case "feedback":
          await deleteFeedback({ feedbackId: deleteTarget.id as Id<"feedback"> });
          toast.success("Feedback deleted successfully");
          break;
      }
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to delete item");
      }
    } finally {
      setDeleteDialogOpen(false);
      setDeleteTarget(null);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type (images only)
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error("File size must be less than 10MB");
      return;
    }

    setUploading(true);

    try {
      // Step 1: Get upload URL
      const uploadUrl = await generateMediaUploadUrl();

      // Step 2: Upload file
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });

      const { storageId } = await result.json();

      // Step 3: Save metadata
      await saveMediaFile({
        storageId,
        filename: file.name,
        fileType: file.type,
        fileSize: file.size,
        category: uploadCategory,
        description: uploadDescription || undefined,
      });

      toast.success("File uploaded successfully");
      setUploadDialogOpen(false);
      setUploadDescription("");
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to upload file");
      }
    } finally {
      setUploading(false);
    }
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    toast.success("URL copied to clipboard");
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  const handleSaveLandingContent = async () => {
    setIsSavingLanding(true);
    try {
      await updateLandingContent(landingForm);
      toast.success("Landing page content updated successfully");
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to update landing page content");
      }
    } finally {
      setIsSavingLanding(false);
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <AppLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Manage users, plans, groups, and content across the platform
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="plans">Plans</TabsTrigger>
            <TabsTrigger value="groups">Groups</TabsTrigger>
            <TabsTrigger value="reflections">Reflections</TabsTrigger>
            <TabsTrigger value="feedback">Feedback</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
            <TabsTrigger value="landing">Platform Content</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {stats === undefined ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-32 w-full" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.totalUsers}</div>
                    <p className="text-xs text-muted-foreground">
                      {stats.activeUsers} active users
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Plans</CardTitle>
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.totalPlans}</div>
                    <p className="text-xs text-muted-foreground">
                      {stats.publishedPlans} published
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Groups</CardTitle>
                    <UsersRound className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.totalGroups}</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Reflections</CardTitle>
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.totalReflections}</div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Manage user accounts and roles</CardDescription>
              </CardHeader>
              <CardContent>
                {users === undefined ? (
                  <div className="space-y-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Activity</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user._id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={user.avatarUrl ?? undefined} />
                                <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{user.name || "Unnamed"}</p>
                                {user.isOnboarded ? (
                                  <Badge variant="secondary" className="text-xs">Active</Badge>
                                ) : (
                                  <Badge variant="outline" className="text-xs">Not Onboarded</Badge>
                                )}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {user.email || "N/A"}
                          </TableCell>
                          <TableCell>
                            {user.role === "admin" ? (
                              <Badge variant="default">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin
                              </Badge>
                            ) : (
                              <Badge variant="outline">User</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {user.planCount} plans, {user.groupCount} groups
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {format(new Date(user._creationTime), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() => handleRoleToggle(user._id, user.role)}
                                >
                                  {user.role === "admin" ? (
                                    <>
                                      <ShieldOff className="h-4 w-4 mr-2" />
                                      Remove Admin
                                    </>
                                  ) : (
                                    <>
                                      <Shield className="h-4 w-4 mr-2" />
                                      Make Admin
                                    </>
                                  )}
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() =>
                                    confirmDelete("user", user._id, user.name || "Unnamed User")
                                  }
                                  className="text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete User
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Plans Tab */}
          <TabsContent value="plans" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Plan Management</CardTitle>
                <CardDescription>Manage reading plans and their status</CardDescription>
              </CardHeader>
              <CardContent>
                {plans === undefined ? (
                  <div className="space-y-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Owner</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Visibility</TableHead>
                        <TableHead>Stats</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {plans.map((plan) => (
                        <TableRow key={plan._id}>
                          <TableCell className="font-medium">{plan.title}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {plan.owner?.name || "Unknown"}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                plan.status === "published"
                                  ? "default"
                                  : plan.status === "archived"
                                    ? "secondary"
                                    : "outline"
                              }
                            >
                              {plan.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={plan.visibility === "public" ? "default" : "outline"}>
                              {plan.visibility}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {plan.memberCount} members, {plan.entryCount} entries
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {format(new Date(plan._creationTime), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                {plan.status !== "published" && (
                                  <DropdownMenuItem
                                    onClick={() => handlePlanStatusChange(plan._id, "published")}
                                  >
                                    Publish
                                  </DropdownMenuItem>
                                )}
                                {plan.status !== "archived" && (
                                  <DropdownMenuItem
                                    onClick={() => handlePlanStatusChange(plan._id, "archived")}
                                  >
                                    Archive
                                  </DropdownMenuItem>
                                )}
                                <DropdownMenuItem
                                  onClick={() => confirmDelete("plan", plan._id, plan.title)}
                                  className="text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete Plan
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Groups Tab */}
          <TabsContent value="groups" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Group Management</CardTitle>
                <CardDescription>Manage community groups</CardDescription>
              </CardHeader>
              <CardContent>
                {groups === undefined ? (
                  <div className="space-y-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Owner</TableHead>
                        <TableHead>Visibility</TableHead>
                        <TableHead>Members</TableHead>
                        <TableHead>Activity</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {groups.map((group) => (
                        <TableRow key={group._id}>
                          <TableCell className="font-medium">{group.name}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {group.owner?.name || "Unknown"}
                          </TableCell>
                          <TableCell>
                            <Badge variant={group.visibility === "public" ? "default" : "outline"}>
                              {group.visibility}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {group.memberCount}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {group.planCount} plans, {group.reflectionCount} reflections
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {format(new Date(group._creationTime), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() => confirmDelete("group", group._id, group.name)}
                                  className="text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete Group
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reflections Tab */}
          <TabsContent value="reflections" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Reflection Moderation</CardTitle>
                <CardDescription>Monitor and moderate user reflections</CardDescription>
              </CardHeader>
              <CardContent>
                {reflections === undefined ? (
                  <div className="space-y-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={i} className="h-24 w-full" />
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Author</TableHead>
                        <TableHead>Content</TableHead>
                        <TableHead>Plan</TableHead>
                        <TableHead>Visibility</TableHead>
                        <TableHead>Engagement</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reflections.map((reflection) => (
                        <TableRow key={reflection._id}>
                          <TableCell className="text-sm text-muted-foreground">
                            {reflection.author?.name || "Unknown"}
                          </TableCell>
                          <TableCell>
                            <p className="text-sm line-clamp-2 max-w-md">
                              {reflection.content}
                            </p>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {reflection.plan?.title || "Unknown"}
                            {reflection.group && (
                              <Badge variant="outline" className="ml-2 text-xs">
                                {reflection.group.name}
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{reflection.visibility}</Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {reflection.likeCount} likes, {reflection.commentCount} comments
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {format(new Date(reflection._creationTime), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() =>
                                    confirmDelete(
                                      "reflection",
                                      reflection._id,
                                      reflection.content.slice(0, 50)
                                    )
                                  }
                                  className="text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete Reflection
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Feedback Tab */}
          <TabsContent value="feedback" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Feedback Management</CardTitle>
                <CardDescription>Review and manage user feedback and bug reports</CardDescription>
              </CardHeader>
              <CardContent>
                {feedback === undefined ? (
                  <div className="space-y-2">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={i} className="h-24 w-full" />
                    ))}
                  </div>
                ) : feedback.length === 0 ? (
                  <div className="text-center py-12">
                    <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No feedback yet</h3>
                    <p className="text-sm text-muted-foreground">
                      User feedback will appear here when submitted
                    </p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Type</TableHead>
                        <TableHead>Title</TableHead>
                        <TableHead>Author</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead>Submitted</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {feedback.map((item) => (
                        <TableRow key={item._id}>
                          <TableCell>
                            <Badge variant="outline" className="capitalize">
                              {item.type}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{item.title}</p>
                              <p className="text-sm text-muted-foreground line-clamp-1 mt-1">
                                {item.description}
                              </p>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {item.author?.name || "Unknown"}
                          </TableCell>
                          <TableCell>
                            <Select
                              value={item.status}
                              onValueChange={(value: "new" | "in_progress" | "resolved" | "closed") =>
                                updateFeedbackStatus({ feedbackId: item._id, status: value })
                              }
                            >
                              <SelectTrigger className="w-[130px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="new">New</SelectItem>
                                <SelectItem value="in_progress">In Progress</SelectItem>
                                <SelectItem value="resolved">Resolved</SelectItem>
                                <SelectItem value="closed">Closed</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={item.priority || "none"}
                              onValueChange={(value) => {
                                if (value !== "none") {
                                  updateFeedbackPriority({ 
                                    feedbackId: item._id, 
                                    priority: value as "low" | "medium" | "high" 
                                  });
                                }
                              }}
                            >
                              <SelectTrigger className="w-[110px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="none">None</SelectItem>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {format(new Date(item._creationTime), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem
                                  onClick={() =>
                                    confirmDelete("feedback", item._id, item.title)
                                  }
                                  className="text-destructive focus:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete Feedback
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Media Tab */}
          <TabsContent value="media" className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-semibold">Media Library</h3>
                <p className="text-sm text-muted-foreground">
                  Upload and manage images for icons, backgrounds, and designs
                </p>
              </div>
              <Button onClick={() => setUploadDialogOpen(true)}>
                <Upload className="h-4 w-4 mr-2" />
                Upload File
              </Button>
            </div>

            {mediaFiles === undefined ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-64 w-full" />
                ))}
              </div>
            ) : mediaFiles.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <ImageIcon className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No media files yet</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Upload your first image to get started
                  </p>
                  <Button onClick={() => setUploadDialogOpen(true)}>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload File
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {mediaFiles.map((media) => (
                  <Card key={media._id} className="overflow-hidden">
                    <div className="aspect-video bg-muted relative">
                      {media.url ? (
                        <img
                          src={media.url}
                          alt={media.filename}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <ImageIcon className="h-12 w-12 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-sm truncate">{media.filename}</CardTitle>
                          <CardDescription className="text-xs mt-1">
                            {formatFileSize(media.fileSize)} • {format(new Date(media._creationTime), "MMM d, yyyy")}
                          </CardDescription>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => media.url && handleCopyUrl(media.url)}
                            >
                              {copiedUrl === media.url ? (
                                <>
                                  <Check className="h-4 w-4 mr-2" />
                                  Copied!
                                </>
                              ) : (
                                <>
                                  <Copy className="h-4 w-4 mr-2" />
                                  Copy URL
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() =>
                                confirmDelete("media", media._id, media.filename)
                              }
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="text-xs">
                          {media.category}
                        </Badge>
                        {media.description && (
                          <p className="text-xs text-muted-foreground line-clamp-2">
                            {media.description}
                          </p>
                        )}
                      </div>
                      <div className="mt-3">
                        <Button
                          variant="secondary"
                          size="sm"
                          className="w-full"
                          onClick={() => media.url && handleCopyUrl(media.url)}
                        >
                          {copiedUrl === media.url ? (
                            <>
                              <Check className="h-3 w-3 mr-2" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="h-3 w-3 mr-2" />
                              Copy URL
                            </>
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Landing Page Tab */}
          <TabsContent value="landing" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Platform Content</CardTitle>
                <CardDescription>
                  Edit text content across all pages - landing page, dashboard, plans, groups, and more
                </CardDescription>
              </CardHeader>
              <CardContent>
                {landingContent === undefined ? (
                  <div className="space-y-4">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <Skeleton key={i} className="h-20 w-full" />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Hero Section */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Hero Section</h3>
                      <div className="space-y-2">
                        <Label htmlFor="heroTitle">Title</Label>
                        <Input
                          id="heroTitle"
                          value={landingForm.heroTitle}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, heroTitle: e.target.value })
                          }
                          placeholder="Read Together. Grow Together."
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="heroSubtitle">Subtitle</Label>
                        <Input
                          id="heroSubtitle"
                          value={landingForm.heroSubtitle}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, heroSubtitle: e.target.value })
                          }
                          placeholder="Build consistent reading habits"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="heroDescription">Description</Label>
                        <Textarea
                          id="heroDescription"
                          value={landingForm.heroDescription}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, heroDescription: e.target.value })
                          }
                          placeholder="A community-driven platform..."
                          rows={3}
                        />
                      </div>
                    </div>

                    {/* Features Section */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Features Section</h3>
                      <div className="space-y-2">
                        <Label htmlFor="featuresTitle">Title</Label>
                        <Input
                          id="featuresTitle"
                          value={landingForm.featuresTitle}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, featuresTitle: e.target.value })
                          }
                          placeholder="Everything You Need to Read Better"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="featuresDescription">Description</Label>
                        <Textarea
                          id="featuresDescription"
                          value={landingForm.featuresDescription}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, featuresDescription: e.target.value })
                          }
                          placeholder="Powerful tools designed to help you..."
                          rows={2}
                        />
                      </div>
                    </div>

                    {/* How It Works Section */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">How It Works Section</h3>
                      <div className="space-y-2">
                        <Label htmlFor="howItWorksTitle">Title</Label>
                        <Input
                          id="howItWorksTitle"
                          value={landingForm.howItWorksTitle}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, howItWorksTitle: e.target.value })
                          }
                          placeholder="How It Works"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="howItWorksDescription">Description</Label>
                        <Textarea
                          id="howItWorksDescription"
                          value={landingForm.howItWorksDescription}
                          onChange={(e) =>
                            setLandingForm({
                              ...landingForm,
                              howItWorksDescription: e.target.value,
                            })
                          }
                          placeholder="Get started in minutes..."
                          rows={2}
                        />
                      </div>
                    </div>

                    {/* Mission Section */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Mission Section</h3>
                      <div className="space-y-2">
                        <Label htmlFor="missionTitle">Title</Label>
                        <Input
                          id="missionTitle"
                          value={landingForm.missionTitle}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, missionTitle: e.target.value })
                          }
                          placeholder="Our Mission"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="missionParagraph1">Paragraph 1</Label>
                        <Textarea
                          id="missionParagraph1"
                          value={landingForm.missionParagraph1}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, missionParagraph1: e.target.value })
                          }
                          placeholder="We believe that consistent reading..."
                          rows={3}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="missionParagraph2">Paragraph 2</Label>
                        <Textarea
                          id="missionParagraph2"
                          value={landingForm.missionParagraph2}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, missionParagraph2: e.target.value })
                          }
                          placeholder="Read Reflect React provides structure..."
                          rows={3}
                        />
                      </div>
                    </div>

                    {/* CTA Section */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Call to Action Section</h3>
                      <div className="space-y-2">
                        <Label htmlFor="ctaTitle">Title</Label>
                        <Input
                          id="ctaTitle"
                          value={landingForm.ctaTitle}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, ctaTitle: e.target.value })
                          }
                          placeholder="Ready to Transform Your Reading?"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="ctaDescription">Description</Label>
                        <Textarea
                          id="ctaDescription"
                          value={landingForm.ctaDescription}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, ctaDescription: e.target.value })
                          }
                          placeholder="Join thousands of readers who are building..."
                          rows={3}
                        />
                      </div>
                    </div>

                    {/* Images & Icons Section */}
                    <div className="space-y-4 border-t pt-6">
                      <h3 className="text-lg font-semibold">Images & Icons</h3>
                      <p className="text-sm text-muted-foreground">
                        Upload images in the Media tab, then paste the URLs here
                      </p>
                      
                      {/* Logo */}
                      <div className="space-y-2">
                        <Label htmlFor="logoUrl">Logo URL</Label>
                        <Input
                          id="logoUrl"
                          value={landingForm.logoUrl}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, logoUrl: e.target.value })
                          }
                          placeholder="https://cdn.hercules.app/file_..."
                        />
                        {landingForm.logoUrl && (
                          <div className="mt-2 p-4 bg-muted rounded-lg">
                            <img
                              src={landingForm.logoUrl}
                              alt="Logo preview"
                              className="h-16 w-16 object-contain"
                            />
                          </div>
                        )}
                      </div>

                      {/* Hero Image */}
                      <div className="space-y-2">
                        <Label htmlFor="heroImageUrl">Hero Image URL</Label>
                        <Input
                          id="heroImageUrl"
                          value={landingForm.heroImageUrl}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, heroImageUrl: e.target.value })
                          }
                          placeholder="https://cdn.hercules.app/file_..."
                        />
                        {landingForm.heroImageUrl && (
                          <div className="mt-2 p-4 bg-muted rounded-lg">
                            <img
                              src={landingForm.heroImageUrl}
                              alt="Hero image preview"
                              className="w-full max-w-md h-48 object-cover rounded-lg"
                            />
                          </div>
                        )}
                      </div>

                      {/* Mission Image */}
                      <div className="space-y-2">
                        <Label htmlFor="missionImageUrl">Mission Section Image URL</Label>
                        <Input
                          id="missionImageUrl"
                          value={landingForm.missionImageUrl}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, missionImageUrl: e.target.value })
                          }
                          placeholder="https://cdn.hercules.app/file_..."
                        />
                        {landingForm.missionImageUrl && (
                          <div className="mt-2 p-4 bg-muted rounded-lg">
                            <img
                              src={landingForm.missionImageUrl}
                              alt="Mission image preview"
                              className="w-full max-w-md h-48 object-cover rounded-lg"
                            />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Group Invite Wording Section */}
                    <div className="space-y-4 border-t pt-6">
                      <h3 className="text-lg font-semibold">Group Invite Wording</h3>
                      <p className="text-sm text-muted-foreground">
                        Customize the text shown in the group invite link dialog
                      </p>
                      
                      <div className="space-y-2">
                        <Label htmlFor="inviteDialogTitle">Dialog Title</Label>
                        <Input
                          id="inviteDialogTitle"
                          value={landingForm.inviteDialogTitle}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, inviteDialogTitle: e.target.value })
                          }
                          placeholder="Invite People to Group"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="inviteDialogDescription">Dialog Description</Label>
                        <Input
                          id="inviteDialogDescription"
                          value={landingForm.inviteDialogDescription}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, inviteDialogDescription: e.target.value })
                          }
                          placeholder="Share this link with anyone you want to invite to"
                        />
                        <p className="text-xs text-muted-foreground">
                          Note: The group name will be automatically appended to this text
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="inviteDialogHelpText">Help Text</Label>
                        <Textarea
                          id="inviteDialogHelpText"
                          value={landingForm.inviteDialogHelpText}
                          onChange={(e) =>
                            setLandingForm({ ...landingForm, inviteDialogHelpText: e.target.value })
                          }
                          placeholder="Anyone with this link can view and join this group"
                          rows={2}
                        />
                      </div>
                    </div>

                    {/* Other Pages Content - Compact */}
                    <Accordion type="multiple" className="w-full border-t pt-6">
                      {/* Dashboard */}
                      <AccordionItem value="dashboard">
                        <AccordionTrigger className="text-lg font-semibold">Dashboard</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Welcome Message</Label>
                            <Input
                              value={landingForm.dashboardWelcome}
                              onChange={(e) => setLandingForm({ ...landingForm, dashboardWelcome: e.target.value })}
                              placeholder="Welcome back"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Subtitle</Label>
                            <Input
                              value={landingForm.dashboardSubtitle}
                              onChange={(e) => setLandingForm({ ...landingForm, dashboardSubtitle: e.target.value })}
                              placeholder="Ready to dive into some reading?"
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* My Plans */}
                      <AccordionItem value="myplans">
                        <AccordionTrigger className="text-lg font-semibold">My Plans Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.myPlansTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, myPlansTitle: e.target.value })}
                              placeholder="My Reading Plans"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Empty State Title</Label>
                            <Input
                              value={landingForm.myPlansEmptyTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, myPlansEmptyTitle: e.target.value })}
                              placeholder="No reading plans yet"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Empty State Description</Label>
                            <Input
                              value={landingForm.myPlansEmptyDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, myPlansEmptyDescription: e.target.value })}
                              placeholder="Start your reading journey..."
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>"Create Plan" Button Text</Label>
                            <Input
                              value={landingForm.myPlansCreateButton}
                              onChange={(e) => setLandingForm({ ...landingForm, myPlansCreateButton: e.target.value })}
                              placeholder="Create Plan"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>"Browse Plans" Button Text</Label>
                            <Input
                              value={landingForm.myPlansBrowseButton}
                              onChange={(e) => setLandingForm({ ...landingForm, myPlansBrowseButton: e.target.value })}
                              placeholder="Browse Plans"
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Browse Plans */}
                      <AccordionItem value="browseplans">
                        <AccordionTrigger className="text-lg font-semibold">Browse Plans Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.browsePlansTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, browsePlansTitle: e.target.value })}
                              placeholder="Discover Reading Plans"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Page Description</Label>
                            <Input
                              value={landingForm.browsePlansDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, browsePlansDescription: e.target.value })}
                              placeholder="Explore curated reading plans..."
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Start Reading Plan */}
                      <AccordionItem value="startplan">
                        <AccordionTrigger className="text-lg font-semibold">Start Reading Plan Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.startPlanTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, startPlanTitle: e.target.value })}
                              placeholder="Start a Reading Plan"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Page Description</Label>
                            <Input
                              value={landingForm.startPlanDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, startPlanDescription: e.target.value })}
                              placeholder="Choose how you'd like to begin..."
                            />
                          </div>
                          
                          <div className="pt-4 border-t border-border">
                            <h4 className="font-medium mb-3">Browse Plans Card</h4>
                            <div className="space-y-3">
                              <div className="space-y-2">
                                <Label>Card Title</Label>
                                <Input
                                  value={landingForm.startPlanBrowseTitle}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanBrowseTitle: e.target.value })}
                                  placeholder="Browse Public Plans"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Card Description</Label>
                                <Input
                                  value={landingForm.startPlanBrowseDescription}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanBrowseDescription: e.target.value })}
                                  placeholder="Discover and join reading plans..."
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Bullet Point 1</Label>
                                <Input
                                  value={landingForm.startPlanBrowseBullet1}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanBrowseBullet1: e.target.value })}
                                  placeholder="Find plans that match your interests"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Bullet Point 2</Label>
                                <Input
                                  value={landingForm.startPlanBrowseBullet2}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanBrowseBullet2: e.target.value })}
                                  placeholder="Join established reading schedules"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Bullet Point 3</Label>
                                <Input
                                  value={landingForm.startPlanBrowseBullet3}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanBrowseBullet3: e.target.value })}
                                  placeholder="Connect with other readers"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Button Text</Label>
                                <Input
                                  value={landingForm.startPlanBrowseButton}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanBrowseButton: e.target.value })}
                                  placeholder="Browse Plans"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="pt-4 border-t border-border">
                            <h4 className="font-medium mb-3">Create Plan Card</h4>
                            <div className="space-y-3">
                              <div className="space-y-2">
                                <Label>Card Title</Label>
                                <Input
                                  value={landingForm.startPlanCreateTitle}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanCreateTitle: e.target.value })}
                                  placeholder="Create New Plan"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Card Description</Label>
                                <Input
                                  value={landingForm.startPlanCreateDescription}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanCreateDescription: e.target.value })}
                                  placeholder="Design a custom reading plan..."
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Bullet Point 1</Label>
                                <Input
                                  value={landingForm.startPlanCreateBullet1}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanCreateBullet1: e.target.value })}
                                  placeholder="Set your own schedule and pace"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Bullet Point 2</Label>
                                <Input
                                  value={landingForm.startPlanCreateBullet2}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanCreateBullet2: e.target.value })}
                                  placeholder="Add custom reflection questions"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Bullet Point 3</Label>
                                <Input
                                  value={landingForm.startPlanCreateBullet3}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanCreateBullet3: e.target.value })}
                                  placeholder="Share with your groups"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Button Text</Label>
                                <Input
                                  value={landingForm.startPlanCreateButton}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanCreateButton: e.target.value })}
                                  placeholder="Create Plan"
                                />
                              </div>
                            </div>
                          </div>

                          <div className="pt-4 border-t border-border">
                            <h4 className="font-medium mb-3">Tip Box</h4>
                            <div className="space-y-3">
                              <div className="space-y-2">
                                <Label>Tip Title</Label>
                                <Input
                                  value={landingForm.startPlanTipTitle}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanTipTitle: e.target.value })}
                                  placeholder="New to reading plans?"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label>Tip Description</Label>
                                <Textarea
                                  value={landingForm.startPlanTipDescription}
                                  onChange={(e) => setLandingForm({ ...landingForm, startPlanTipDescription: e.target.value })}
                                  placeholder="Browse public plans to see how others structure..."
                                  rows={3}
                                />
                              </div>
                            </div>
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Create Plan */}
                      <AccordionItem value="createplan">
                        <AccordionTrigger className="text-lg font-semibold">Create Plan Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.createPlanTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, createPlanTitle: e.target.value })}
                              placeholder="Create a Reading Plan"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Page Description</Label>
                            <Input
                              value={landingForm.createPlanDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, createPlanDescription: e.target.value })}
                              placeholder="Set up a structured reading schedule..."
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Groups */}
                      <AccordionItem value="mygroups">
                        <AccordionTrigger className="text-lg font-semibold">My Groups Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.myGroupsTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, myGroupsTitle: e.target.value })}
                              placeholder="My Groups"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Empty State Title</Label>
                            <Input
                              value={landingForm.myGroupsEmptyTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, myGroupsEmptyTitle: e.target.value })}
                              placeholder="No groups joined"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Empty State Description</Label>
                            <Input
                              value={landingForm.myGroupsEmptyDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, myGroupsEmptyDescription: e.target.value })}
                              placeholder="Connect with other readers..."
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Browse Groups */}
                      <AccordionItem value="browsegroups">
                        <AccordionTrigger className="text-lg font-semibold">Browse Groups Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.browseGroupsTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, browseGroupsTitle: e.target.value })}
                              placeholder="Discover Groups"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Page Description</Label>
                            <Input
                              value={landingForm.browseGroupsDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, browseGroupsDescription: e.target.value })}
                              placeholder="Find communities of readers..."
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Profile */}
                      <AccordionItem value="profile">
                        <AccordionTrigger className="text-lg font-semibold">Profile Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.profileTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, profileTitle: e.target.value })}
                              placeholder="My Profile"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Page Description</Label>
                            <Input
                              value={landingForm.profileDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, profileDescription: e.target.value })}
                              placeholder="Manage your account settings..."
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Reflections */}
                      <AccordionItem value="reflections">
                        <AccordionTrigger className="text-lg font-semibold">Reflections Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.reflectionsTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, reflectionsTitle: e.target.value })}
                              placeholder="My Reflections"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Empty State Title</Label>
                            <Input
                              value={landingForm.reflectionsEmptyTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, reflectionsEmptyTitle: e.target.value })}
                              placeholder="No reflections yet"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Empty State Description</Label>
                            <Input
                              value={landingForm.reflectionsEmptyDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, reflectionsEmptyDescription: e.target.value })}
                              placeholder="Start reflecting on your reading..."
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      {/* Feedback */}
                      <AccordionItem value="feedback">
                        <AccordionTrigger className="text-lg font-semibold">Feedback Page</AccordionTrigger>
                        <AccordionContent className="space-y-4 pt-4">
                          <div className="space-y-2">
                            <Label>Page Title</Label>
                            <Input
                              value={landingForm.feedbackTitle}
                              onChange={(e) => setLandingForm({ ...landingForm, feedbackTitle: e.target.value })}
                              placeholder="Send Feedback"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Page Description</Label>
                            <Input
                              value={landingForm.feedbackDescription}
                              onChange={(e) => setLandingForm({ ...landingForm, feedbackDescription: e.target.value })}
                              placeholder="Help us improve..."
                            />
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>

                    <div className="flex justify-end pt-4">
                      <Button
                        onClick={handleSaveLandingContent}
                        disabled={isSavingLanding}
                        size="lg"
                      >
                        {isSavingLanding ? "Saving..." : "Save Changes"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Upload Dialog */}
        <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Upload Media File</DialogTitle>
              <DialogDescription>
                Upload an image file for use in your app (icons, backgrounds, designs)
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={uploadCategory} onValueChange={(value) => setUploadCategory(value as typeof uploadCategory)}>
                  <SelectTrigger id="category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="icon">Icon</SelectItem>
                    <SelectItem value="background">Background</SelectItem>
                    <SelectItem value="image">Image</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Textarea
                  id="description"
                  placeholder="Add a description for this file..."
                  value={uploadDescription}
                  onChange={(e) => setUploadDescription(e.target.value)}
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="file">File</Label>
                <Input
                  id="file"
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  disabled={uploading}
                />
                <p className="text-xs text-muted-foreground">
                  Supported formats: PNG, JPG, GIF, SVG (max 10MB)
                </p>
              </div>
              {uploading && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full" />
                  Uploading...
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete <span className="font-semibold">{deleteTarget?.name}</span> and all associated data. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AppLayout>
  );
}
