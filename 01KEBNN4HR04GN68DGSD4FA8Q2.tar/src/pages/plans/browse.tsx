import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import { Search, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from "@/components/ui/empty.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import PlanCard from "./_components/plan-card.tsx";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function BrowsePlansContent() {
  const publicPlans = useQuery(api.readingPlans.getPublicPlans);
  const joinPlan = useMutation(api.readingPlans.joinPlan);
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [joiningPlanId, setJoiningPlanId] = useState<Id<"readingPlans"> | null>(null);

  const handleJoinPlan = async (planId: Id<"readingPlans">) => {
    setJoiningPlanId(planId);
    try {
      await joinPlan({ planId });
      toast.success("Successfully joined plan!");
      navigate(`/plans/${planId}`);
    } catch (error) {
      const err = error as { data?: { message?: string } };
      if (err.data?.message === "Already enrolled in this plan") {
        toast.info("You're already enrolled in this plan");
        navigate(`/plans/${planId}`);
      } else {
        toast.error("Failed to join plan");
      }
    } finally {
      setJoiningPlanId(null);
    }
  };

  const filteredPlans = publicPlans?.filter((plan) =>
    plan.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    plan.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (publicPlans === undefined) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-pulse text-muted-foreground">Loading plans...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to="/plans">
          <Button variant="ghost" size="sm" className="gap-2 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to My Plans
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            Browse Reading Plans
          </h1>
          <p className="text-muted-foreground mt-1">
            Discover and join community reading plans
          </p>
        </div>
      </motion.div>

      {/* Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="relative"
      >
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search plans..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9"
        />
      </motion.div>

      {/* Plans Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {publicPlans.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-12 w-12 object-contain" />
              </EmptyMedia>
              <EmptyTitle>No public plans available</EmptyTitle>
              <EmptyDescription>
                Check back later for community reading plans
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : filteredPlans && filteredPlans.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPlans.map((plan) => (
              <div key={plan._id} className="relative">
                <PlanCard plan={plan} />
                <div className="mt-2">
                  <Button
                    className="w-full"
                    onClick={() => handleJoinPlan(plan._id)}
                    disabled={joiningPlanId === plan._id}
                  >
                    {joiningPlanId === plan._id ? "Joining..." : "Join Plan"}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No plans found matching your search
          </div>
        )}
      </motion.div>
    </div>
  );
}

export default function BrowsePlans() {
  return (
    <AppLayout>
      <BrowsePlansContent />
    </AppLayout>
  );
}
