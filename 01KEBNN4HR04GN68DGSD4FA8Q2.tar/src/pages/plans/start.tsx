import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import AppLayout from "@/components/layout/app-layout.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Search, Plus, ArrowRight } from "lucide-react";

export default function StartReadingPlan() {
  const content = useQuery(api.landingPage.getContent);

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-8 w-8 object-contain" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">
              {content?.startPlanTitle || "Start a Reading Plan"}
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {content?.startPlanDescription || "Choose how you'd like to begin your reading journey"}
            </p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Browse Public Plans */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Link to="/plans/browse">
              <Card className="h-full hover:shadow-lg transition-all hover:border-primary/50 cursor-pointer group">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      <Search className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{content?.startPlanBrowseTitle || "Browse Public Plans"}</CardTitle>
                  </div>
                  <CardDescription className="text-base">
                    {content?.startPlanBrowseDescription || "Discover and join reading plans created by the community"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {content?.startPlanBrowseBullet1 || "Find plans that match your interests"}
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {content?.startPlanBrowseBullet2 || "Join established reading schedules"}
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {content?.startPlanBrowseBullet3 || "Connect with other readers"}
                    </li>
                  </ul>
                  <div className="flex items-center gap-2 text-primary font-medium group-hover:gap-3 transition-all">
                    {content?.startPlanBrowseButton || "Browse Plans"}
                    <ArrowRight className="h-4 w-4" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          </motion.div>

          {/* Create New Plan */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Link to="/plans/create">
              <Card className="h-full hover:shadow-lg transition-all hover:border-primary/50 cursor-pointer group">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-3 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      <Plus className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{content?.startPlanCreateTitle || "Create New Plan"}</CardTitle>
                  </div>
                  <CardDescription className="text-base">
                    {content?.startPlanCreateDescription || "Design a custom reading plan tailored to your goals"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {content?.startPlanCreateBullet1 || "Set your own schedule and pace"}
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {content?.startPlanCreateBullet2 || "Add custom reflection questions"}
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {content?.startPlanCreateBullet3 || "Share with your groups"}
                    </li>
                  </ul>
                  <div className="flex items-center gap-2 text-primary font-medium group-hover:gap-3 transition-all">
                    {content?.startPlanCreateButton || "Create Plan"}
                    <ArrowRight className="h-4 w-4" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          </motion.div>
        </div>

        {/* Quick Stats or Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-8"
        >
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="flex items-center gap-4 py-6">
              <div className="p-3 rounded-full bg-primary/10">
                <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-6 w-6 object-contain" />
              </div>
              <div>
                <p className="font-medium text-foreground">{content?.startPlanTipTitle || "New to reading plans?"}</p>
                <p className="text-sm text-muted-foreground">
                  {content?.startPlanTipDescription || "Browse public plans to see how others structure their reading journeys, or dive in and create your own custom plan."}
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </AppLayout>
  );
}
