import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import { ArrowLeft, Plus, X, ExternalLink, Upload, CheckCircle, AlertCircle, Download } from "lucide-react";
import { Separator } from "@/components/ui/separator.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { toast } from "sonner";
import Papa from "papaparse";
import * as XLSX from "xlsx";

type DayType = "reading" | "meeting" | "sabbath";
type WeekDay = "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday" | "sunday";

interface WeeklySchedule {
  day: WeekDay;
  type: DayType;
}

interface ResourceMaterial {
  title: string;
  url: string;
}

interface CSVEntry {
  title: string;
  description?: string;
  content?: string;
  scheduledDate?: string;
  bibleReferences?: string;
  externalLinks?: string;
  reflectionPrompts?: string;
}

interface GeneratedReadingDay {
  date: string;
  dayOfWeek: WeekDay;
  type: DayType;
  title: string;
  notes: string;
}

const predefinedColors = [
  { name: "Brown", value: "#8B4513" },
  { name: "Blue", value: "#4169E1" },
  { name: "Green", value: "#228B22" },
  { name: "Purple", value: "#9370DB" },
  { name: "Orange", value: "#FF8C00" },
  { name: "Red", value: "#DC143C" },
  { name: "Teal", value: "#008B8B" },
  { name: "Pink", value: "#FF69B4" },
];

function CreatePlanContent() {
  const navigate = useNavigate();
  const createPlan = useMutation(api.readingPlans.create);
  const createEntry = useMutation(api.planEntries.create);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    visibility: "private" as "public" | "private",
    scheduleType: "daily" as "daily" | "weekly" | "custom",
    startDate: "",
    endDate: "",
    color: "#8B4513",
    reminderEnabled: false,
  });

  const [labels, setLabels] = useState<string[]>([]);
  const [newLabel, setNewLabel] = useState("");

  // Custom weekly schedule state
  const [selectedDays, setSelectedDays] = useState<Set<WeekDay>>(new Set());
  const [dayTypes, setDayTypes] = useState<Record<WeekDay, DayType>>({
    monday: "reading",
    tuesday: "reading",
    wednesday: "reading",
    thursday: "reading",
    friday: "reading",
    saturday: "reading",
    sunday: "reading",
  });

  // Resource materials state
  const [resourceMaterials, setResourceMaterials] = useState<ResourceMaterial[]>([]);
  const [newResource, setNewResource] = useState({ title: "", url: "" });

  // Reflection prompts state
  const [reflectionPrompts, setReflectionPrompts] = useState<string[]>([]);
  const [newPrompt, setNewPrompt] = useState("");

  // CSV import state
  const [csvEntries, setCSVEntries] = useState<CSVEntry[]>([]);
  const [csvErrors, setCsvErrors] = useState<string[]>([]);
  const [isParsing, setIsParsing] = useState(false);

  // Generated reading days state
  const [generatedDays, setGeneratedDays] = useState<GeneratedReadingDay[]>([]);

  const weekDays: { value: WeekDay; label: string }[] = [
    { value: "monday", label: "Monday" },
    { value: "tuesday", label: "Tuesday" },
    { value: "wednesday", label: "Wednesday" },
    { value: "thursday", label: "Thursday" },
    { value: "friday", label: "Friday" },
    { value: "saturday", label: "Saturday" },
    { value: "sunday", label: "Sunday" },
  ];

  const dayTypeOptions = [
    { value: "reading", label: "Reading Day" },
    { value: "meeting", label: "Meeting Day" },
    { value: "sabbath", label: "Sabbath/Reflection Day" },
  ];

  const addLabel = () => {
    if (newLabel.trim() && !labels.includes(newLabel.trim())) {
      setLabels([...labels, newLabel.trim()]);
      setNewLabel("");
    }
  };

  const removeLabel = (label: string) => {
    setLabels(labels.filter((l) => l !== label));
  };

  const toggleDay = (day: WeekDay) => {
    setSelectedDays((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(day)) {
        newSet.delete(day);
      } else {
        newSet.add(day);
      }
      return newSet;
    });
  };

  const setDayType = (day: WeekDay, type: DayType) => {
    setDayTypes((prev) => ({ ...prev, [day]: type }));
  };

  // Generate reading days based on date range and selected days
  const generateReadingDays = () => {
    if (!formData.startDate || !formData.endDate || selectedDays.size === 0) {
      return;
    }

    const start = new Date(formData.startDate);
    const end = new Date(formData.endDate);

    if (start > end) {
      toast.error("End date must be after start date");
      return;
    }

    const dayMap: Record<number, WeekDay> = {
      0: "sunday",
      1: "monday",
      2: "tuesday",
      3: "wednesday",
      4: "thursday",
      5: "friday",
      6: "saturday",
    };

    const days: GeneratedReadingDay[] = [];
    const current = new Date(start);

    while (current <= end) {
      const dayOfWeek = dayMap[current.getDay()];
      if (selectedDays.has(dayOfWeek)) {
        days.push({
          date: current.toISOString().split("T")[0],
          dayOfWeek,
          type: dayTypes[dayOfWeek],
          title: "",
          notes: "",
        });
      }
      current.setDate(current.getDate() + 1);
    }

    setGeneratedDays(days);
    toast.success(`Generated ${days.length} reading days`);
  };

  const updateGeneratedDay = (index: number, field: "title" | "notes", value: string) => {
    setGeneratedDays((prev) =>
      prev.map((day, i) => (i === index ? { ...day, [field]: value } : day))
    );
  };

  const insertBibleReference = (dayIndex: number, reference: string) => {
    if (!reference.trim()) return;

    const formatted = `[${reference.trim()}](https://www.bible.com/search/bible?q=${encodeURIComponent(reference.trim())})`;
    const currentNotes = generatedDays[dayIndex]?.notes || "";
    const newNotes = currentNotes ? `${currentNotes} ${formatted}` : formatted;

    updateGeneratedDay(dayIndex, "notes", newNotes);
  };

  const clearGeneratedDays = () => {
    setGeneratedDays([]);
  };

  const addResourceMaterial = () => {
    if (newResource.title.trim() && newResource.url.trim()) {
      setResourceMaterials([...resourceMaterials, { ...newResource }]);
      setNewResource({ title: "", url: "" });
    }
  };

  const removeResourceMaterial = (index: number) => {
    setResourceMaterials(resourceMaterials.filter((_, i) => i !== index));
  };

  const addReflectionPrompt = () => {
    if (newPrompt.trim() && !reflectionPrompts.includes(newPrompt.trim())) {
      setReflectionPrompts([...reflectionPrompts, newPrompt.trim()]);
      setNewPrompt("");
    }
  };

  const removeReflectionPrompt = (index: number) => {
    setReflectionPrompts(reflectionPrompts.filter((_, i) => i !== index));
  };

  const handleCSVUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const fileExtension = file.name.split(".").pop()?.toLowerCase();
    const isCSV = fileExtension === "csv";
    const isExcel = fileExtension === "xls" || fileExtension === "xlsx";

    if (!isCSV && !isExcel) {
      toast.error("Please upload a CSV or Excel file (.csv, .xls, .xlsx)");
      return;
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size must be less than 5MB");
      return;
    }

    setIsParsing(true);
    setCsvErrors([]);

    if (isCSV) {
      // Parse CSV
      Papa.parse<Record<string, string>>(file, {
        header: true,
        skipEmptyLines: true,
        dynamicTyping: false,
        transformHeader: (header) => header.trim().toLowerCase().replace(/\s+/g, ""),
        complete: (results) => {
          setIsParsing(false);

          // Check for parsing errors
          if (results.errors.length > 0) {
            setCsvErrors(results.errors.map((err) => `Row ${err.row}: ${err.message}`));
            return;
          }

          processSpreadsheetData(results.data);
        },
        error: (error) => {
          setIsParsing(false);
          setCsvErrors([error.message]);
          toast.error("Failed to parse CSV file");
        },
      });
    } else if (isExcel) {
      // Parse Excel
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array", cellDates: true, dateNF: "yyyy-mm-dd" });
          
          // Get first sheet
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          
          // Convert to JSON - let xlsx handle the headers automatically
          const jsonData = XLSX.utils.sheet_to_json(worksheet, {
            defval: "",
            raw: false, // Convert all values to strings
          }) as Record<string, unknown>[];

          if (jsonData.length === 0) {
            setIsParsing(false);
            setCsvErrors(["Excel file is empty or has no data rows"]);
            return;
          }

          // Transform the data to match our expected format (lowercase headers, no spaces)
          const rows = jsonData.map((row) => {
            const transformedRow: Record<string, string> = {};
            Object.keys(row).forEach((key) => {
              const normalizedKey = String(key).trim().toLowerCase().replace(/\s+/g, "");
              const value = row[key];
              
              // Handle different value types
              if (value instanceof Date) {
                // Format date as YYYY-MM-DD
                transformedRow[normalizedKey] = value.toISOString().split("T")[0];
              } else if (value !== undefined && value !== null) {
                transformedRow[normalizedKey] = String(value).trim();
              } else {
                transformedRow[normalizedKey] = "";
              }
            });
            return transformedRow;
          });

          setIsParsing(false);
          processSpreadsheetData(rows);
        } catch (error) {
          setIsParsing(false);
          const errorMessage = error instanceof Error ? error.message : "Failed to parse Excel file";
          setCsvErrors([errorMessage]);
          toast.error("Failed to parse Excel file");
        }
      };
      reader.onerror = () => {
        setIsParsing(false);
        setCsvErrors(["Failed to read Excel file"]);
        toast.error("Failed to read Excel file");
      };
      reader.readAsArrayBuffer(file);
    }

    // Reset input so same file can be uploaded again if needed
    event.target.value = "";
  };

  const processSpreadsheetData = (data: Record<string, string>[]) => {
    console.log("Processing spreadsheet data:", data); // Debug log
    
    const validationErrors: string[] = [];
    const validEntries: CSVEntry[] = [];

    data.forEach((row, index) => {
      console.log(`Row ${index + 1}:`, row); // Debug log
      
      // Access transformed property names (lowercase, no spaces)
      const title = row.title || "";
      const description = row.description || "";
      const content = row.content || "";
      const scheduleddate = row.scheduleddate || "";
      const biblereferences = row.biblereferences || "";
      const externallinks = row.externallinks || "";
      const reflectionprompts = row.reflectionprompts || "";

      if (!title || title.trim() === "") {
        validationErrors.push(`Row ${index + 2}: Missing required field 'title'`);
        return;
      }

      // Validate date format if provided
      if (scheduleddate && scheduleddate.trim() !== "") {
        const dateTest = new Date(scheduleddate);
        if (isNaN(dateTest.getTime())) {
          validationErrors.push(
            `Row ${index + 2}: Invalid date format '${scheduleddate}'. Use YYYY-MM-DD`
          );
          return;
        }
      }

      validEntries.push({
        title: title.trim(),
        description: description.trim() || undefined,
        content: content.trim() || undefined,
        scheduledDate: scheduleddate.trim() || undefined,
        bibleReferences: biblereferences.trim() || undefined,
        externalLinks: externallinks.trim() || undefined,
        reflectionPrompts: reflectionprompts.trim() || undefined,
      });
    });

    console.log("Valid entries:", validEntries); // Debug log
    console.log("Validation errors:", validationErrors); // Debug log

    if (validationErrors.length > 0) {
      setCsvErrors(validationErrors);
      toast.error(`Found ${validationErrors.length} validation errors`);
      return;
    }

    setCSVEntries(validEntries);
    toast.success(`Successfully loaded ${validEntries.length} entries from file`);
  };

  const clearCSVEntries = () => {
    setCSVEntries([]);
    setCsvErrors([]);
  };

  const downloadCSVTemplate = () => {
    const template = `title,description,content,scheduledDate,bibleReferences,externalLinks,reflectionPrompts
Day 1 - Genesis,"Introduction to Genesis","Read and reflect on the creation story",2024-01-01,"Genesis 1:1-31, Genesis 2:1-25","https://example.com/study-guide","What does this passage reveal about God's character?, How does understanding creation impact your view of humanity?"
Day 2 - The Fall,"The story of Adam and Eve","Examine the fall of humanity",2024-01-02,"Genesis 3:1-24","https://example.com/commentary","What are the consequences of sin in this passage?, How does this relate to your life today?"
Day 3 - Noah's Ark,"The great flood","Study the covenant with Noah",2024-01-03,"Genesis 6:1-22, Genesis 7:1-24","https://example.com/resources","What does this covenant tell us about God's faithfulness?, How can you trust God in difficult times?"`;

    const blob = new Blob([template], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "reading-plan-template.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title.trim()) {
      toast.error("Please enter a plan title");
      return;
    }

    setIsSubmitting(true);
    try {
      // Build custom weekly schedule if custom type
      const customWeeklySchedule =
        formData.scheduleType === "custom" && selectedDays.size > 0
          ? Array.from(selectedDays).map((day) => ({
              day,
              type: dayTypes[day],
            }))
          : undefined;

      const planId = await createPlan({
        title: formData.title,
        description: formData.description || undefined,
        visibility: formData.visibility,
        scheduleType: formData.scheduleType,
        startDate: formData.startDate || undefined,
        endDate: formData.endDate || undefined,
        color: formData.color,
        labels: labels.length > 0 ? labels : undefined,
        reminderEnabled: formData.reminderEnabled,
        reflectionPrompts: reflectionPrompts.length > 0 ? reflectionPrompts : undefined,
        customWeeklySchedule,
        resourceMaterials: resourceMaterials.length > 0 ? resourceMaterials : undefined,
      });

      // Create entries from CSV if any
      if (csvEntries.length > 0) {
        for (let i = 0; i < csvEntries.length; i++) {
          const entry = csvEntries[i];
          await createEntry({
            planId,
            title: entry.title,
            description: entry.description,
            content: entry.content,
            order: i + 1,
            scheduledDate: entry.scheduledDate,
            bibleReferences: entry.bibleReferences
              ? entry.bibleReferences.split(",").map((ref) => ref.trim())
              : undefined,
            externalLinks: entry.externalLinks
              ? entry.externalLinks.split(",").map((link) => link.trim())
              : undefined,
            reflectionPrompts: entry.reflectionPrompts
              ? entry.reflectionPrompts.split(",").map((prompt) => prompt.trim())
              : undefined,
          });
        }
      }

      // Create entries from generated reading days if any
      if (generatedDays.length > 0) {
        const startOrder = csvEntries.length + 1;
        for (let i = 0; i < generatedDays.length; i++) {
          const day = generatedDays[i];
          
          // Extract Bible references from markdown links in notes
          const markdownRefRegex = /\[([^\]]+)\]\(https:\/\/www\.bible\.com[^)]+\)/g;
          const markdownMatches = [...day.notes.matchAll(markdownRefRegex)];
          const markdownRefs = markdownMatches.map((match) => match[1]);

          // Also auto-detect Bible references in plain text format
          // Matches patterns like: Genesis 1:1, John 3:16, 1 Corinthians 13:4-7, etc.
          const plainTextRefRegex = /\b(\d\s)?([A-Z][a-z]+(?:\s[A-Z][a-z]+)?)\s+(\d+):(\d+)(?:-(\d+))?(?::(\d+))?\b/g;
          const plainTextMatches = [...day.notes.matchAll(plainTextRefRegex)];
          const plainTextRefs = plainTextMatches.map((match) => match[0].trim());

          // Combine both types of references, removing duplicates
          const allRefs = [...new Set([...markdownRefs, ...plainTextRefs])];

          await createEntry({
            planId,
            title: day.title || `${day.dayOfWeek} - ${day.date}`,
            description: day.notes,
            content: day.notes,
            order: startOrder + i,
            scheduledDate: day.date,
            bibleReferences: allRefs.length > 0 ? allRefs : undefined,
          });
        }
      }

      toast.success(
        formData.visibility === "public"
          ? "Plan created and pending approval"
          : "Plan created successfully"
      );
      navigate(`/plans/${planId}`);
    } catch {
      toast.error("Failed to create plan");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to="/plans">
          <Button variant="ghost" size="sm" className="gap-2 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to My Plans
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            Create Reading Plan
          </h1>
          <p className="text-muted-foreground mt-1">
            Set up a new reading plan for yourself or your community
          </p>
        </div>
      </motion.div>

      {/* Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Plan Title *</Label>
                <Input
                  id="title"
                  placeholder="30 Days of Scripture Reading"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, title: e.target.value }))
                  }
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your reading plan..."
                  value={formData.description}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, description: e.target.value }))
                  }
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="visibility">Visibility</Label>
                <Select
                  value={formData.visibility}
                  onValueChange={(value: "public" | "private") =>
                    setFormData((prev) => ({ ...prev, visibility: value }))
                  }
                >
                  <SelectTrigger id="visibility">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="private">Private (Only visible to members)</SelectItem>
                    <SelectItem value="public">Public (Visible to everyone)</SelectItem>
                  </SelectContent>
                </Select>
                {formData.visibility === "public" && (
                  <p className="text-sm text-muted-foreground">
                    Public plans require admin approval before being published
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Schedule */}
          <Card>
            <CardHeader>
              <CardTitle>Schedule</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="scheduleType">Schedule Type</Label>
                <Select
                  value={formData.scheduleType}
                  onValueChange={(value: "daily" | "weekly" | "custom") =>
                    setFormData((prev) => ({ ...prev, scheduleType: value }))
                  }
                >
                  <SelectTrigger id="scheduleType">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily Reading</SelectItem>
                    <SelectItem value="weekly">Weekly Reading</SelectItem>
                    <SelectItem value="custom">Custom Schedule</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date (Optional)</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, startDate: e.target.value }))
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date (Optional)</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={formData.endDate}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, endDate: e.target.value }))
                    }
                  />
                </div>
              </div>

              {formData.scheduleType === "custom" && (
                <div className="space-y-4">
                  <Separator className="my-4" />
                  
                  <div className="space-y-4">
                    <div className="text-sm font-medium">Choose how to create your reading schedule:</div>
                    
                    {/* Option 1: Generate from dates */}
                    <div className="border rounded-lg p-4 space-y-4">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm font-medium">
                          1
                        </div>
                        <h3 className="font-medium">Generate Reading Days</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Select days of the week and generate a schedule based on your date range
                      </p>
                      
                      <div className="space-y-2">
                        <Label>Select Days of the Week</Label>
                        <div className="space-y-3">
                          {weekDays.map((day) => (
                            <div key={day.value} className="space-y-2">
                              <div className="flex items-center gap-2">
                                <Checkbox
                                  id={day.value}
                                  checked={selectedDays.has(day.value)}
                                  onCheckedChange={() => toggleDay(day.value)}
                                />
                                <Label htmlFor={day.value} className="font-normal cursor-pointer">
                                  {day.label}
                                </Label>
                              </div>
                              {selectedDays.has(day.value) && (
                                <div className="ml-6">
                                  <Select
                                    value={dayTypes[day.value]}
                                    onValueChange={(value: DayType) =>
                                      setDayType(day.value, value)
                                    }
                                  >
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {dayTypeOptions.map((option) => (
                                        <SelectItem key={option.value} value={option.value}>
                                          {option.label}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      {formData.startDate && formData.endDate && selectedDays.size > 0 && (
                        <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                          <p className="text-sm text-muted-foreground">
                            Ready to generate reading days from {formData.startDate} to{" "}
                            {formData.endDate}
                          </p>
                          <Button type="button" size="sm" onClick={generateReadingDays}>
                            Generate Days
                          </Button>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      <Separator className="flex-1" />
                      <span className="text-sm text-muted-foreground font-medium">OR</span>
                      <Separator className="flex-1" />
                    </div>

                    {/* Option 2: Import from CSV/Excel */}
                    <div className="border rounded-lg p-4 space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm font-medium">
                            2
                          </div>
                          <h3 className="font-medium">Import from CSV or Excel</h3>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={downloadCSVTemplate}
                          className="gap-2"
                        >
                          <Download className="h-4 w-4" />
                          Download Template
                        </Button>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Upload a CSV or Excel file with your reading schedule
                      </p>
                      
                      <div className="space-y-2">
                        <Label htmlFor="csv-upload">Upload File</Label>
                        <p className="text-sm text-muted-foreground">
                          File should include: title (required), description, content, scheduledDate
                          (YYYY-MM-DD), bibleReferences (comma-separated), externalLinks
                          (comma-separated), reflectionPrompts (comma-separated). Supports .csv, .xls, and .xlsx formats.
                        </p>
                        <div className="flex items-center gap-2">
                          <Input
                            id="csv-upload"
                            type="file"
                            accept=".csv,.xls,.xlsx"
                            onChange={handleCSVUpload}
                            disabled={isParsing}
                            className="flex-1"
                          />
                          <Upload className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        </div>
                      </div>

                      {isParsing && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <div className="h-4 w-4 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
                          Parsing file...
                        </div>
                      )}

                      {csvErrors.length > 0 && (
                        <div className="rounded-lg border border-destructive bg-destructive/10 p-3">
                          <div className="flex items-center gap-2 text-sm font-medium text-destructive mb-2">
                            <AlertCircle className="h-4 w-4" />
                            Validation Errors ({csvErrors.length})
                          </div>
                          <ul className="text-sm text-destructive space-y-1 max-h-40 overflow-y-auto">
                            {csvErrors.slice(0, 10).map((error, i) => (
                              <li key={i}>{error}</li>
                            ))}
                            {csvErrors.length > 10 && (
                              <li className="font-medium">
                                ...and {csvErrors.length - 10} more errors
                              </li>
                            )}
                          </ul>
                        </div>
                      )}

                      {csvEntries.length > 0 && (
                        <div className="space-y-3">
                          <div className="rounded-lg border border-green-500 bg-green-50 p-3 dark:bg-green-950">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 text-sm font-medium text-green-700 dark:text-green-400">
                                <CheckCircle className="h-4 w-4" />
                                Successfully loaded {csvEntries.length} entries
                              </div>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={clearCSVEntries}
                                className="text-green-700 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300"
                              >
                                Clear
                              </Button>
                            </div>
                          </div>
                          <div className="border rounded-lg p-3 bg-muted/30 max-h-60 overflow-y-auto space-y-2">
                            <p className="text-sm font-medium text-foreground mb-2">Preview (first 5 entries):</p>
                            {csvEntries.slice(0, 5).map((entry, index) => (
                              <div key={index} className="text-sm border-l-2 border-primary pl-3 py-2 space-y-1">
                                <p className="font-medium text-foreground">
                                  {index + 1}. {entry.title}
                                </p>
                                {entry.scheduledDate && (
                                  <p className="text-muted-foreground text-xs">
                                    📅 Date: {entry.scheduledDate}
                                  </p>
                                )}
                                {entry.bibleReferences && (
                                  <p className="text-muted-foreground text-xs">
                                    📖 Bible: {entry.bibleReferences}
                                  </p>
                                )}
                                {entry.description && (
                                  <p className="text-muted-foreground text-xs line-clamp-2">
                                    📝 {entry.description}
                                  </p>
                                )}
                                {entry.content && (
                                  <p className="text-muted-foreground text-xs line-clamp-1">
                                    💬 Content: {entry.content}
                                  </p>
                                )}
                                {entry.externalLinks && (
                                  <p className="text-muted-foreground text-xs">
                                    🔗 Links: {entry.externalLinks}
                                  </p>
                                )}
                                {entry.reflectionPrompts && (
                                  <p className="text-muted-foreground text-xs line-clamp-2">
                                    💭 Questions: {entry.reflectionPrompts}
                                  </p>
                                )}
                              </div>
                            ))}
                            {csvEntries.length > 5 && (
                              <p className="text-sm text-muted-foreground italic">
                                ...and {csvEntries.length - 5} more entries
                              </p>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <Separator className="my-4" />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="reminderEnabled">Reminders</Label>
                  <p className="text-sm text-muted-foreground">
                    Get notified about daily readings
                  </p>
                </div>
                <Switch
                  id="reminderEnabled"
                  checked={formData.reminderEnabled}
                  onCheckedChange={(checked) =>
                    setFormData((prev) => ({ ...prev, reminderEnabled: checked }))
                  }
                />
              </div>
            </CardContent>
          </Card>

          {/* Generated Reading Days */}
          {generatedDays.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Reading Days ({generatedDays.length})</CardTitle>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={clearGeneratedDays}
                  >
                    Clear All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                  {generatedDays.map((day, index) => (
                    <div key={index} className="border rounded-lg p-4 space-y-3 bg-muted/30">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {new Date(day.date).toLocaleDateString("en-US", {
                                weekday: "short",
                                month: "short",
                                day: "numeric",
                              })}
                            </Badge>
                            <Badge
                              variant={
                                day.type === "reading"
                                  ? "default"
                                  : day.type === "meeting"
                                    ? "secondary"
                                    : "outline"
                              }
                              className="text-xs"
                            >
                              {dayTypeOptions.find((o) => o.value === day.type)?.label}
                            </Badge>
                          </div>
                        </div>
                        <span className="text-sm font-medium text-muted-foreground">
                          Day {index + 1}
                        </span>
                      </div>

                      <div className="space-y-2">
                        <Input
                          placeholder="Enter title for this day"
                          value={day.title}
                          onChange={(e) => updateGeneratedDay(index, "title", e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm">Notes & Bible References</Label>
                        </div>
                        <Textarea
                          placeholder="Add notes or type Bible references (e.g., Genesis 1:1-10)..."
                          value={day.notes}
                          onChange={(e) => updateGeneratedDay(index, "notes", e.target.value)}
                          rows={3}
                          className="resize-none"
                        />
                        <div className="flex gap-2">
                          <Input
                            placeholder="e.g., Genesis 1:1-10"
                            className="text-sm"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="secondary"
                            onClick={(e) => {
                              const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                              if (input?.value) {
                                insertBibleReference(index, input.value);
                                input.value = "";
                              }
                            }}
                            className="whitespace-nowrap"
                          >
                            Add Reference
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Bible references will be auto-detected and linked (e.g., "Genesis 1:1"). You can also click "Add Reference" to insert a formatted link.
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Resource Materials */}
          <Card>
            <CardHeader>
              <CardTitle>Resource Materials</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Add study resources, books, or materials</Label>
                <div className="space-y-2">
                  <Input
                    placeholder="Resource title (e.g., Study Guide, Book)"
                    value={newResource.title}
                    onChange={(e) =>
                      setNewResource((prev) => ({ ...prev, title: e.target.value }))
                    }
                  />
                  <div className="flex gap-2">
                    <Input
                      placeholder="URL to purchase or download"
                      value={newResource.url}
                      onChange={(e) =>
                        setNewResource((prev) => ({ ...prev, url: e.target.value }))
                      }
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          addResourceMaterial();
                        }
                      }}
                    />
                    <Button type="button" onClick={addResourceMaterial} size="icon">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                {resourceMaterials.length > 0 && (
                  <div className="space-y-2 mt-4">
                    {resourceMaterials.map((resource, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 border rounded-lg bg-muted/30"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{resource.title}</p>
                          <a
                            href={resource.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1 truncate"
                          >
                            {resource.url}
                            <ExternalLink className="h-3 w-3 flex-shrink-0" />
                          </a>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeResourceMaterial(index)}
                          className="ml-2 hover:text-destructive"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Reflection Prompts */}
          <Card>
            <CardHeader>
              <CardTitle>Reflection Questions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Add prompting questions for daily reflection</Label>
                <p className="text-sm text-muted-foreground">
                  These questions will appear with each reading to guide participants' reflections
                </p>
                <div className="flex gap-2">
                  <Textarea
                    placeholder="e.g., What does this passage teach about God's character?"
                    value={newPrompt}
                    onChange={(e) => setNewPrompt(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        addReflectionPrompt();
                      }
                    }}
                    rows={2}
                    className="resize-none"
                  />
                  <Button type="button" onClick={addReflectionPrompt} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                {reflectionPrompts.length > 0 && (
                  <div className="space-y-2 mt-4">
                    {reflectionPrompts.map((prompt, index) => (
                      <div
                        key={index}
                        className="flex items-start justify-between p-3 border rounded-lg bg-muted/30 gap-2"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">{prompt}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeReflectionPrompt(index)}
                          className="ml-2 hover:text-destructive flex-shrink-0"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>



          {/* Customization */}
          <Card>
            <CardHeader>
              <CardTitle>Customization</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Color Theme</Label>
                <div className="flex flex-wrap gap-2">
                  {predefinedColors.map((color) => (
                    <button
                      key={color.value}
                      type="button"
                      onClick={() =>
                        setFormData((prev) => ({ ...prev, color: color.value }))
                      }
                      className={`h-10 w-10 rounded-lg border-2 transition-all ${
                        formData.color === color.value
                          ? "border-foreground scale-110"
                          : "border-border hover:scale-105"
                      }`}
                      style={{ backgroundColor: color.value }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Labels</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Add a label"
                    value={newLabel}
                    onChange={(e) => setNewLabel(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addLabel();
                      }
                    }}
                  />
                  <Button type="button" onClick={addLabel} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                {labels.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {labels.map((label) => (
                      <Badge key={label} variant="secondary">
                        {label}
                        <button
                          type="button"
                          onClick={() => removeLabel(label)}
                          className="ml-1 hover:text-destructive"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end gap-2">
            <Link to="/plans">
              <Button type="button" variant="ghost">
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Creating..." : "Create Plan"}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

export default function CreatePlan() {
  return (
    <AppLayout>
      <CreatePlanContent />
    </AppLayout>
  );
}
