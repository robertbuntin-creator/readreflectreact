import { Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import { Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Label } from "@/components/ui/label.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import PlanCard from "./_components/plan-card.tsx";
import { useState } from "react";
import { toast } from "sonner";
import { ConvexError } from "convex/values";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

function MyPlansContent() {
  const myPlans = useQuery(api.readingPlans.getMyPlans);
  const duplicatePlan = useMutation(api.readingPlans.duplicate);
  const deletePlan = useMutation(api.readingPlans.deletePlan);
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [duplicateDialogOpen, setDuplicateDialogOpen] = useState(false);
  const [duplicatePlanId, setDuplicatePlanId] = useState<Id<"readingPlans"> | null>(null);
  const [duplicateTitle, setDuplicateTitle] = useState("");
  const [isDuplicating, setIsDuplicating] = useState(false);

  const handleOpenDuplicateDialog = (planId: Id<"readingPlans">) => {
    const plan = myPlans?.find((p) => p._id === planId);
    if (plan) {
      setDuplicatePlanId(planId);
      setDuplicateTitle(`${plan.title} (Copy)`);
      setDuplicateDialogOpen(true);
    }
  };

  const handleConfirmDuplicate = async () => {
    if (!duplicatePlanId || !duplicateTitle.trim()) {
      toast.error("Please enter a title for the duplicated plan");
      return;
    }
    
    setIsDuplicating(true);
    try {
      const newPlanId = await duplicatePlan({ 
        planId: duplicatePlanId, 
        newTitle: duplicateTitle.trim() 
      });
      toast.success("Plan duplicated successfully!");
      setDuplicateDialogOpen(false);
      // Navigate to the new duplicated plan
      navigate(`/plans/${newPlanId}`);
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to duplicate plan");
      }
    } finally {
      setIsDuplicating(false);
    }
  };

  const handleDelete = async (planId: Id<"readingPlans">) => {
    if (!confirm("Are you sure you want to delete this plan? This action cannot be undone.")) {
      return;
    }
    try {
      await deletePlan({ planId });
      toast.success("Plan deleted successfully");
    } catch {
      toast.error("Failed to delete plan");
    }
  };

  const filteredPlans = myPlans?.filter((plan) =>
    plan.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const myOwnedPlans = filteredPlans?.filter((plan) => plan.isOwner);
  const joinedPlans = filteredPlans?.filter((plan) => !plan.isOwner);

  if (myPlans === undefined) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-pulse text-muted-foreground">Loading plans...</div>
      </div>
    );
  }

  return (
    <>
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            My Reading Plans
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your reading plans and track your progress
          </p>
        </div>
        <div className="flex gap-2">
          <Link to="/plans/browse">
            <Button variant="secondary" className="gap-2">
              <Search className="h-4 w-4" />
              Browse Plans
            </Button>
          </Link>
          <Link to="/plans/create">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Create Plan
            </Button>
          </Link>
        </div>
      </motion.div>

      {myPlans.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-12 w-12 object-contain" />
              </EmptyMedia>
              <EmptyTitle>No reading plans yet</EmptyTitle>
              <EmptyDescription>
                Start your reading journey by creating a new plan or joining an
                existing one
              </EmptyDescription>
            </EmptyHeader>
            <EmptyContent>
              <div className="flex gap-2">
                <Link to="/plans/create">
                  <Button size="sm">Create Plan</Button>
                </Link>
                <Link to="/plans/browse">
                  <Button variant="secondary" size="sm">
                    Browse Plans
                  </Button>
                </Link>
              </div>
            </EmptyContent>
          </Empty>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search plans..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>

          {/* Tabs */}
          <Tabs defaultValue="all" className="space-y-6">
            <TabsList>
              <TabsTrigger value="all">
                All Plans ({myPlans.length})
              </TabsTrigger>
              <TabsTrigger value="owned">
                Created by Me ({myOwnedPlans?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="joined">
                Joined ({joinedPlans?.length || 0})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              {filteredPlans && filteredPlans.length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredPlans.map((plan) => (
                    <PlanCard
                      key={plan._id}
                      plan={plan}
                      showProgress
                      onDuplicate={() => handleOpenDuplicateDialog(plan._id)}
                      onDelete={plan.isOwner ? () => handleDelete(plan._id) : undefined}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  No plans found matching your search
                </div>
              )}
            </TabsContent>

            <TabsContent value="owned" className="space-y-4">
              {myOwnedPlans && myOwnedPlans.length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {myOwnedPlans.map((plan) => (
                    <PlanCard
                      key={plan._id}
                      plan={plan}
                      showProgress
                      onDuplicate={() => handleOpenDuplicateDialog(plan._id)}
                      onDelete={() => handleDelete(plan._id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">
                    You haven't created any plans yet
                  </p>
                  <Link to="/plans/create">
                    <Button size="sm">Create Your First Plan</Button>
                  </Link>
                </div>
              )}
            </TabsContent>

            <TabsContent value="joined" className="space-y-4">
              {joinedPlans && joinedPlans.length > 0 ? (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {joinedPlans.map((plan) => (
                    <PlanCard
                      key={plan._id}
                      plan={plan}
                      showProgress
                      onDuplicate={() => handleOpenDuplicateDialog(plan._id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">
                    You haven't joined any plans yet
                  </p>
                  <Link to="/plans/browse">
                    <Button size="sm">Browse Plans</Button>
                  </Link>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      )}
    </div>

    {/* Duplicate Plan Dialog */}
    <Dialog open={duplicateDialogOpen} onOpenChange={setDuplicateDialogOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Duplicate Reading Plan</DialogTitle>
          <DialogDescription>
            Enter a new name for the duplicated plan. All readings and settings will be copied.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="duplicate-title">Plan Title</Label>
            <Input
              id="duplicate-title"
              value={duplicateTitle}
              onChange={(e) => setDuplicateTitle(e.target.value)}
              placeholder="Enter plan title"
            />
          </div>
          <div className="flex gap-2 justify-end">
            <Button
              variant="outline"
              onClick={() => setDuplicateDialogOpen(false)}
              disabled={isDuplicating}
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmDuplicate}
              disabled={isDuplicating || !duplicateTitle.trim()}
            >
              {isDuplicating ? "Duplicating..." : "Duplicate Plan"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
    </>
  );
}

export default function MyPlans() {
  return (
    <AppLayout>
      <MyPlansContent />
    </AppLayout>
  );
}
