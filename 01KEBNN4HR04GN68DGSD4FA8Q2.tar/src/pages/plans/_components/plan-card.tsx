import { Link } from "react-router-dom";
import { Calendar, Users, Clock, MoreVertical } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Progress } from "@/components/ui/progress.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";

type PlanCardProps = {
  plan: {
    _id: string;
    title: string;
    description?: string;
    scheduleType: "daily" | "weekly" | "custom";
    color?: string;
    labels?: string[];
    ownerName: string;
    entriesCount: number;
    membersCount: number;
    userProgress?: number;
    isOwner?: boolean;
  };
  onDuplicate?: () => void;
  onDelete?: () => void;
  showProgress?: boolean;
};

const scheduleTypeLabels = {
  daily: "Daily",
  weekly: "Weekly",
  custom: "Custom",
};

export default function PlanCard({ plan, onDuplicate, onDelete, showProgress }: PlanCardProps) {
  const colorClass = plan.color || "#8B4513";

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow group">
      <div
        className="h-2"
        style={{ backgroundColor: colorClass }}
      />
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <Link to={`/plans/${plan._id}`}>
              <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                {plan.title}
              </h3>
            </Link>
            <p className="text-sm text-muted-foreground mt-1">
              by {plan.ownerName}
            </p>
          </div>
          {(onDuplicate || onDelete) && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {onDuplicate && (
                  <DropdownMenuItem onClick={onDuplicate}>
                    Duplicate
                  </DropdownMenuItem>
                )}
                {onDuplicate && onDelete && <DropdownMenuSeparator />}
                {onDelete && (
                  <DropdownMenuItem
                    onClick={onDelete}
                    className="text-destructive focus:text-destructive"
                  >
                    Delete
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {plan.description && (
          <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
            {plan.description}
          </p>
        )}

        {plan.labels && plan.labels.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {plan.labels.slice(0, 3).map((label) => (
              <Badge key={label} variant="secondary" className="text-xs">
                {label}
              </Badge>
            ))}
            {plan.labels.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{plan.labels.length - 3}
              </Badge>
            )}
          </div>
        )}
      </CardHeader>

      <CardContent className="pb-3">
        <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            <span>{scheduleTypeLabels[plan.scheduleType]}</span>
          </div>
          <div className="flex items-center gap-1">
            <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-4 w-4 object-contain" />
            <span>{plan.entriesCount} readings</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{plan.membersCount} {plan.membersCount === 1 ? "member" : "members"}</span>
          </div>
        </div>

        {showProgress && plan.userProgress !== undefined && (
          <div className="mt-3 space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium text-foreground">{plan.userProgress}%</span>
            </div>
            <Progress value={plan.userProgress} className="h-2" />
          </div>
        )}
      </CardContent>

      <CardFooter className="pt-3 border-t">
        <Link to={`/plans/${plan._id}`} className="w-full">
          <Button variant="secondary" size="sm" className="w-full gap-2">
            <Clock className="h-4 w-4" />
            View Plan
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
