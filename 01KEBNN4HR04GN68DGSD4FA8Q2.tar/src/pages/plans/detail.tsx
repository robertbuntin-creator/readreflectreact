import { useParams, useNavigate, Link, useSearchParams } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Calendar,
  Users,
  CheckCircle2,
  Circle,
  Clock,
  Edit,
  Trash2,
  UserPlus,
  UserMinus,
  Link as LinkIcon,
  ExternalLink,
  Plus,
  X,
  Send,
  Bell,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Progress } from "@/components/ui/progress.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { useState, useEffect } from "react";
import { ConvexError } from "convex/values";
import ReactMarkdown from "react-markdown";

const scheduleTypeLabels = {
  daily: "Daily",
  weekly: "Weekly",
  custom: "Custom",
};

const dayTypeLabels = {
  reading: "Reading Day",
  meeting: "Meeting Day",
  sabbath: "Sabbath/Reflection Day",
};

const weekDayLabels: Record<string, string> = {
  monday: "Monday",
  tuesday: "Tuesday",
  wednesday: "Wednesday",
  thursday: "Thursday",
  friday: "Friday",
  saturday: "Saturday",
  sunday: "Sunday",
};

function PlanDetailContent() {
  const { planId } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const plan = useQuery(
    api.readingPlans.getPlanById,
    planId ? { planId: planId as Id<"readingPlans"> } : "skip"
  );
  const myGroups = useQuery(api.groups.getMyGroups, {});
  const myReflections = useQuery(
    api.reflections.getMyReflectionsByPlan,
    planId ? { planId: planId as Id<"readingPlans"> } : "skip"
  );
  const joinPlan = useMutation(api.readingPlans.joinPlan);
  const leavePlan = useMutation(api.readingPlans.leavePlan);
  const markComplete = useMutation(api.planEntries.markComplete);
  const markIncomplete = useMutation(api.planEntries.markIncomplete);
  const updatePlan = useMutation(api.readingPlans.update);

  const [isJoining, setIsJoining] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);
  const [togglingEntry, setTogglingEntry] = useState<number | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editForm, setEditForm] = useState({
    title: "",
    description: "",
    visibility: "" as "public" | "private",
    scheduleType: "" as "daily" | "weekly" | "custom",
    color: "",
    startDate: "",
    endDate: "",
    labels: [] as string[],
    reminderEnabled: false,
    reflectionPrompts: [] as string[],
    customWeeklySchedule: [] as Array<{
      day: "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday" | "sunday";
      type: "reading" | "meeting" | "sabbath";
    }>,
    resourceMaterials: [] as Array<{ title: string; url: string }>,
  });
  const [newPrompt, setNewPrompt] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [newResourceTitle, setNewResourceTitle] = useState("");
  const [newResourceUrl, setNewResourceUrl] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);
  const [reflectionResponses, setReflectionResponses] = useState<Record<string, Record<number, string>>>({});
  const [reflectionVisibility, setReflectionVisibility] = useState<Record<string, Record<number, "private" | "group">>>({});
  const [savingReflection, setSavingReflection] = useState<string | null>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [notificationsSupported, setNotificationsSupported] = useState(false);
  const [editReadingDialogOpen, setEditReadingDialogOpen] = useState(false);
  const [selectedEntryId, setSelectedEntryId] = useState<Id<"planEntries"> | null>(null);
  const [editReadingForm, setEditReadingForm] = useState({
    title: "",
    description: "",
    scheduledDate: "",
    bibleReferences: [] as string[],
    externalLinks: [] as string[],
    reflectionPrompts: [] as string[],
  });
  const [newBibleRef, setNewBibleRef] = useState("");
  const [newExternalLink, setNewExternalLink] = useState("");
  const [newReadingPrompt, setNewReadingPrompt] = useState("");
  const [isUpdatingReading, setIsUpdatingReading] = useState(false);
  const [viewingReadingId, setViewingReadingId] = useState<Id<"planEntries"> | null>(null);

  const createReflection = useMutation(api.reflections.create);
  const updateEntry = useMutation(api.planEntries.update);

  // Check if notifications are supported and enabled
  useEffect(() => {
    if ("Notification" in window) {
      setNotificationsSupported(true);
      setNotificationsEnabled(Notification.permission === "granted");
    }
  }, []);

  // Check for reading query parameter and automatically show that reading
  useEffect(() => {
    const readingId = searchParams.get("reading");
    if (readingId && plan?.entries) {
      const entry = plan.entries.find((e) => e._id === readingId);
      if (entry) {
        setViewingReadingId(entry._id);
      }
    }
  }, [searchParams, plan?.entries]);

  // Load existing reflections into the form when they're fetched
  useEffect(() => {
    if (!myReflections) return;

    const newResponses: Record<string, Record<number, string>> = {};
    const newVisibility: Record<string, Record<number, "private" | "group">> = {};

    for (const reflection of myReflections) {
      if (reflection.entryId && reflection.questionIndex !== undefined) {
        if (!newResponses[reflection.entryId]) {
          newResponses[reflection.entryId] = {};
        }
        if (!newVisibility[reflection.entryId]) {
          newVisibility[reflection.entryId] = {};
        }
        newResponses[reflection.entryId][reflection.questionIndex] = reflection.content;
        newVisibility[reflection.entryId][reflection.questionIndex] = reflection.visibility as "private" | "group";
      }
    }

    setReflectionResponses(newResponses);
    setReflectionVisibility(newVisibility);
  }, [myReflections]);

  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) {
      toast.error("Your browser doesn't support notifications");
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === "granted") {
        setNotificationsEnabled(true);
        toast.success("Notifications enabled!");
        // Send a test notification
        new Notification("Read Reflect React", {
          body: "You'll now receive reminders for your reading plans",
          icon: "https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk",
        });
      } else {
        toast.error("Notification permission denied");
      }
    } catch (error) {
      toast.error("Failed to enable notifications");
    }
  };

  const toggleNotifications = async () => {
    if (!notificationsEnabled) {
      await requestNotificationPermission();
    } else {
      toast.info("To disable notifications, please do so in your browser settings");
    }
  };

  const handleJoinPlan = async () => {
    if (!planId) return;
    setIsJoining(true);
    try {
      await joinPlan({ planId: planId as Id<"readingPlans"> });
      toast.success("Successfully joined plan!");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to join plan");
    } finally {
      setIsJoining(false);
    }
  };

  const handleLeavePlan = async () => {
    if (!planId) return;
    if (!confirm("Are you sure you want to leave this plan?")) {
      return;
    }
    setIsLeaving(true);
    try {
      await leavePlan({ planId: planId as Id<"readingPlans"> });
      toast.success("Left plan successfully");
      navigate("/plans");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to leave plan");
    } finally {
      setIsLeaving(false);
    }
  };

  const handleToggleEntry = async (entryOrder: number, isCompleted: boolean) => {
    if (!planId) return;
    setTogglingEntry(entryOrder);
    try {
      if (isCompleted) {
        await markIncomplete({
          planId: planId as Id<"readingPlans">,
          entryOrder,
        });
        toast.success("Marked as incomplete");
      } else {
        await markComplete({
          planId: planId as Id<"readingPlans">,
          entryOrder,
        });
        toast.success("Completed!");
      }
    } catch {
      toast.error("Failed to update progress");
    } finally {
      setTogglingEntry(null);
    }
  };

  const handleOpenEditDialog = () => {
    if (!plan) return;
    setEditForm({
      title: plan.title,
      description: plan.description || "",
      visibility: plan.visibility,
      scheduleType: plan.scheduleType,
      color: plan.color || "#8B4513",
      startDate: plan.startDate || "",
      endDate: plan.endDate || "",
      labels: plan.labels || [],
      reminderEnabled: plan.reminderEnabled || false,
      reflectionPrompts: plan.reflectionPrompts || [],
      customWeeklySchedule: plan.customWeeklySchedule || [],
      resourceMaterials: plan.resourceMaterials || [],
    });
    setNewPrompt("");
    setNewLabel("");
    setNewResourceTitle("");
    setNewResourceUrl("");
    setEditDialogOpen(true);
  };

  const handleUpdatePlan = async () => {
    if (!planId) return;
    setIsUpdating(true);
    try {
      await updatePlan({
        planId: planId as Id<"readingPlans">,
        title: editForm.title,
        description: editForm.description || undefined,
        visibility: editForm.visibility,
        scheduleType: editForm.scheduleType,
        color: editForm.color,
        startDate: editForm.startDate || undefined,
        endDate: editForm.endDate || undefined,
        labels: editForm.labels.length > 0 ? editForm.labels : undefined,
        reminderEnabled: editForm.reminderEnabled,
        reflectionPrompts: editForm.reflectionPrompts.length > 0 ? editForm.reflectionPrompts : undefined,
        customWeeklySchedule: editForm.customWeeklySchedule.length > 0 ? editForm.customWeeklySchedule : undefined,
        resourceMaterials: editForm.resourceMaterials.length > 0 ? editForm.resourceMaterials : undefined,
      });
      toast.success("Plan updated successfully");
      setEditDialogOpen(false);
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to update plan");
      }
    } finally {
      setIsUpdating(false);
    }
  };

  const addPromptToEditForm = () => {
    if (newPrompt.trim() && !editForm.reflectionPrompts.includes(newPrompt.trim())) {
      setEditForm((prev) => ({
        ...prev,
        reflectionPrompts: [...prev.reflectionPrompts, newPrompt.trim()],
      }));
      setNewPrompt("");
    }
  };

  const removePromptFromEditForm = (index: number) => {
    setEditForm((prev) => ({
      ...prev,
      reflectionPrompts: prev.reflectionPrompts.filter((_, i) => i !== index),
    }));
  };

  const addLabelToEditForm = () => {
    if (newLabel.trim() && !editForm.labels.includes(newLabel.trim())) {
      setEditForm((prev) => ({
        ...prev,
        labels: [...prev.labels, newLabel.trim()],
      }));
      setNewLabel("");
    }
  };

  const removeLabelFromEditForm = (index: number) => {
    setEditForm((prev) => ({
      ...prev,
      labels: prev.labels.filter((_, i) => i !== index),
    }));
  };

  const addResourceToEditForm = () => {
    if (newResourceTitle.trim() && newResourceUrl.trim()) {
      setEditForm((prev) => ({
        ...prev,
        resourceMaterials: [...prev.resourceMaterials, { title: newResourceTitle.trim(), url: newResourceUrl.trim() }],
      }));
      setNewResourceTitle("");
      setNewResourceUrl("");
    }
  };

  const removeResourceFromEditForm = (index: number) => {
    setEditForm((prev) => ({
      ...prev,
      resourceMaterials: prev.resourceMaterials.filter((_, i) => i !== index),
    }));
  };

  const handleSaveReflection = async (entryId: Id<"planEntries">, promptIndex: number, questionText: string) => {
    if (!planId) return;
    const content = reflectionResponses[entryId]?.[promptIndex];
    if (!content || !content.trim()) {
      toast.error("Please write a reflection before saving");
      return;
    }

    const visibility = reflectionVisibility[entryId]?.[promptIndex] || "private";

    // If visibility is group, use the first group the user is a member of
    let groupId: Id<"groups"> | undefined;
    if (visibility === "group") {
      if (!myGroups || myGroups.length === 0) {
        toast.error("Please join a group to share reflections with a group");
        return;
      }
      groupId = myGroups[0]._id;
    }

    const saveKey = `${entryId}-${promptIndex}`;
    setSavingReflection(saveKey);
    try {
      await createReflection({
        planId: planId as Id<"readingPlans">,
        entryId,
        content: content.trim(),
        visibility,
        groupId,
        questionIndex: promptIndex,
        questionText,
      });
      toast.success("Reflection saved!");
      // Keep the reflection text in the textarea after saving
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to save reflection");
      }
    } finally {
      setSavingReflection(null);
    }
  };

  const handleOpenEditReadingDialog = () => {
    setSelectedEntryId(null);
    setEditReadingForm({
      title: "",
      description: "",
      scheduledDate: "",
      bibleReferences: [],
      externalLinks: [],
      reflectionPrompts: [],
    });
    setNewBibleRef("");
    setNewExternalLink("");
    setNewReadingPrompt("");
    setEditReadingDialogOpen(true);
  };

  const handleSelectEntry = (entryId: Id<"planEntries">) => {
    const entry = plan?.entries.find((e) => e._id === entryId);
    if (!entry) return;
    
    setSelectedEntryId(entryId);
    setEditReadingForm({
      title: entry.title,
      description: entry.description || "",
      scheduledDate: entry.scheduledDate || "",
      bibleReferences: entry.bibleReferences || [],
      externalLinks: entry.externalLinks || [],
      reflectionPrompts: entry.reflectionPrompts || [],
    });
  };

  const handleUpdateReading = async () => {
    if (!selectedEntryId) {
      toast.error("Please select a reading to edit");
      return;
    }

    setIsUpdatingReading(true);
    try {
      await updateEntry({
        entryId: selectedEntryId,
        title: editReadingForm.title,
        description: editReadingForm.description || undefined,
        scheduledDate: editReadingForm.scheduledDate || undefined,
        bibleReferences: editReadingForm.bibleReferences.length > 0 ? editReadingForm.bibleReferences : undefined,
        externalLinks: editReadingForm.externalLinks.length > 0 ? editReadingForm.externalLinks : undefined,
        reflectionPrompts: editReadingForm.reflectionPrompts.length > 0 ? editReadingForm.reflectionPrompts : undefined,
      });
      toast.success("Reading updated successfully");
      setEditReadingDialogOpen(false);
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to update reading");
      }
    } finally {
      setIsUpdatingReading(false);
    }
  };

  const addBibleRefToEditReadingForm = () => {
    if (newBibleRef.trim() && !editReadingForm.bibleReferences.includes(newBibleRef.trim())) {
      setEditReadingForm((prev) => ({
        ...prev,
        bibleReferences: [...prev.bibleReferences, newBibleRef.trim()],
      }));
      setNewBibleRef("");
    }
  };

  const removeBibleRefFromEditReadingForm = (index: number) => {
    setEditReadingForm((prev) => ({
      ...prev,
      bibleReferences: prev.bibleReferences.filter((_, i) => i !== index),
    }));
  };

  const addExternalLinkToEditReadingForm = () => {
    if (newExternalLink.trim() && !editReadingForm.externalLinks.includes(newExternalLink.trim())) {
      setEditReadingForm((prev) => ({
        ...prev,
        externalLinks: [...prev.externalLinks, newExternalLink.trim()],
      }));
      setNewExternalLink("");
    }
  };

  const removeExternalLinkFromEditReadingForm = (index: number) => {
    setEditReadingForm((prev) => ({
      ...prev,
      externalLinks: prev.externalLinks.filter((_, i) => i !== index),
    }));
  };

  const addReadingPromptToEditReadingForm = () => {
    if (newReadingPrompt.trim() && !editReadingForm.reflectionPrompts.includes(newReadingPrompt.trim())) {
      setEditReadingForm((prev) => ({
        ...prev,
        reflectionPrompts: [...prev.reflectionPrompts, newReadingPrompt.trim()],
      }));
      setNewReadingPrompt("");
    }
  };

  const removeReadingPromptFromEditReadingForm = (index: number) => {
    setEditReadingForm((prev) => ({
      ...prev,
      reflectionPrompts: prev.reflectionPrompts.filter((_, i) => i !== index),
    }));
  };

  if (!planId) {
    return <div>Invalid plan ID</div>;
  }

  if (plan === undefined) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-pulse text-muted-foreground">Loading plan...</div>
      </div>
    );
  }

  if (plan === null) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground mb-4">Plan not found</p>
        <Link to="/plans">
          <Button>Back to Plans</Button>
        </Link>
      </div>
    );
  }

  const isEnrolled = plan.userMembership !== null;
  const completedEntries = plan.userMembership?.completedEntries || [];
  const progress = plan.userMembership?.progress || 0;

  // If viewing a specific reading, show only that reading
  const viewingReading = viewingReadingId 
    ? plan.entries.find(e => e._id === viewingReadingId)
    : null;

  if (viewingReading) {
    const isCompleted = completedEntries.includes(viewingReading.order);
    const isToggling = togglingEntry === viewingReading.order;
    
    // Get date information
    let dateHeader = null;
    if (viewingReading.scheduledDate) {
      const [year, month, day] = viewingReading.scheduledDate.split("-").map(Number);
      const date = new Date(year, month - 1, day);
      const dayOfWeek = date.toLocaleDateString("en-US", { weekday: "long" });
      const displayDate = date.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      });
      dateHeader = `${dayOfWeek}, ${displayDate}`;
    }

    return (
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Back button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Button 
            variant="ghost" 
            size="sm" 
            className="gap-2 mb-4"
            onClick={() => setViewingReadingId(null)}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to All Readings
          </Button>

          <Card>
            <div
              className="h-2 rounded-t-xl"
              style={{ backgroundColor: plan.color || "#8B4513" }}
            />
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary">
                  {plan.title}
                </Badge>
              </div>
              {dateHeader && (
                <div className="flex items-center gap-2 text-muted-foreground mb-2">
                  <Calendar className="h-4 w-4" />
                  <span className="text-sm">{dateHeader}</span>
                </div>
              )}
              <CardTitle className="text-2xl sm:text-3xl">{viewingReading.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isEnrolled && (
                  <button
                    onClick={() => handleToggleEntry(viewingReading.order, isCompleted)}
                    disabled={isToggling}
                    className="flex items-center gap-2 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors w-full"
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="h-6 w-6 text-primary" />
                    ) : (
                      <Circle className="h-6 w-6 text-muted-foreground" />
                    )}
                    <span className="text-sm font-medium">
                      {isCompleted ? "Completed" : "Mark as Complete"}
                    </span>
                  </button>
                )}

                {viewingReading.description && (
                  <div className="prose prose-sm max-w-none">
                    <ReactMarkdown
                      components={{
                        a: ({ node, ...props }) => (
                          <a
                            {...props}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-primary hover:underline"
                          />
                        ),
                      }}
                    >
                      {viewingReading.description}
                    </ReactMarkdown>
                  </div>
                )}

                {viewingReading.bibleReferences && viewingReading.bibleReferences.length > 0 && (
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-2">Bible References</h4>
                    <div className="flex flex-wrap gap-2">
                      {viewingReading.bibleReferences.map((ref) => (
                        <a
                          key={ref}
                          href={`https://www.bible.com/search/bible?q=${encodeURIComponent(ref)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-3 py-2 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                        >
                          <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-4 w-4 object-contain" />
                          {ref}
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {viewingReading.externalLinks && viewingReading.externalLinks.length > 0 && (
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-2">Additional Resources</h4>
                    <div className="flex flex-wrap gap-2">
                      {viewingReading.externalLinks.map((link, linkIndex) => (
                        <a
                          key={linkIndex}
                          href={link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-3 py-2 rounded-md border border-border hover:bg-muted/50 transition-colors text-sm"
                        >
                          <LinkIcon className="h-3 w-3" />
                          Link {linkIndex + 1}
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {(() => {
                  // Combine plan-level and entry-specific reflection prompts
                  const planPrompts = plan.reflectionPrompts || [];
                  const entryPrompts = viewingReading.reflectionPrompts || [];
                  const allPrompts = [
                    ...planPrompts.map((p, idx) => ({ text: p, index: idx, source: 'plan' as const })),
                    ...entryPrompts.map((p, idx) => ({ text: p, index: planPrompts.length + idx, source: 'entry' as const }))
                  ];
                  
                  if (allPrompts.length === 0) return null;
                  
                  return (
                    <div className="space-y-4">
                      <h4 className="text-sm font-semibold text-foreground">Reflection Questions</h4>
                      {allPrompts.map((prompt) => (
                        <div key={prompt.index} className="p-4 rounded-lg bg-primary/5 border border-primary/10 space-y-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h5 className="text-sm font-semibold text-foreground">
                                Question {prompt.index + 1}
                              </h5>
                              <Badge variant={prompt.source === 'plan' ? 'default' : 'secondary'} className="text-xs h-5">
                                {prompt.source === 'plan' ? 'All Readings' : 'This Reading'}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {prompt.text}
                            </p>
                          </div>
                          {isEnrolled && (
                            <div className="space-y-2">
                              <h6 className="text-sm font-semibold text-foreground">
                                Reflect and React
                              </h6>
                              <p className="text-xs text-muted-foreground">
                                Write your personal thoughts and action steps
                              </p>
                              <Textarea
                                placeholder="What is this reading calling you to do? Write your reflections here..."
                                value={reflectionResponses[viewingReading._id]?.[prompt.index] || ""}
                                onChange={(e) =>
                                  setReflectionResponses((prev) => ({
                                    ...prev,
                                    [viewingReading._id]: {
                                      ...(prev[viewingReading._id] || {}),
                                      [prompt.index]: e.target.value,
                                    },
                                  }))
                                }
                                rows={4}
                                className="resize-none"
                              />
                              <div className="flex items-center gap-2">
                                <Label htmlFor={`visibility-${viewingReading._id}-${prompt.index}`} className="text-xs">
                                  Visibility:
                                </Label>
                                <Select
                                  value={reflectionVisibility[viewingReading._id]?.[prompt.index] || "private"}
                                  onValueChange={(value: "private" | "group") => 
                                    setReflectionVisibility((prev) => ({
                                      ...prev,
                                      [viewingReading._id]: {
                                        ...(prev[viewingReading._id] || {}),
                                        [prompt.index]: value,
                                      },
                                    }))
                                  }
                                >
                                  <SelectTrigger id={`visibility-${viewingReading._id}-${prompt.index}`} className="h-8 w-[140px]">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="private">Private</SelectItem>
                                    <SelectItem value="group">Group</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <Button
                                size="sm"
                                onClick={() => handleSaveReflection(viewingReading._id, prompt.index, prompt.text)}
                                disabled={savingReflection === `${viewingReading._id}-${prompt.index}`}
                                className="gap-2"
                              >
                                <Send className="h-3 w-3" />
                                {savingReflection === `${viewingReading._id}-${prompt.index}` ? "Saving..." : "Save Reflection"}
                              </Button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to="/plans">
          <Button variant="ghost" size="sm" className="gap-2 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Plans
          </Button>
        </Link>

        <Card>
          <div
            className="h-2 rounded-t-xl"
            style={{ backgroundColor: plan.color || "#8B4513" }}
          />
          <CardHeader>
            <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary">
                    {scheduleTypeLabels[plan.scheduleType]}
                  </Badge>
                  <Badge variant={plan.visibility === "public" ? "default" : "secondary"}>
                    {plan.visibility === "public" ? "Public" : "Private"}
                  </Badge>
                  {plan.status === "pending_approval" && (
                    <Badge variant="secondary">Pending Approval</Badge>
                  )}
                </div>
                <CardTitle className="text-2xl sm:text-3xl">{plan.title}</CardTitle>
                {plan.description && (
                  <p className="text-muted-foreground mt-2">{plan.description}</p>
                )}
                <div className="flex flex-wrap gap-3 text-sm text-muted-foreground mt-3">
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    <span>Created by {plan.ownerName}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-4 w-4 object-contain" />
                    <span>{plan.entries.length} readings</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    <span>{plan.membersCount} members</span>
                  </div>
                </div>
                {plan.labels && plan.labels.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {plan.labels.map((label) => (
                      <Badge key={label} variant="secondary">
                        {label}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-2">
                {!isEnrolled ? (
                  <Button onClick={handleJoinPlan} disabled={isJoining} className="gap-2">
                    <UserPlus className="h-4 w-4" />
                    {isJoining ? "Joining..." : "Join Plan"}
                  </Button>
                ) : !plan.isOwner ? (
                  <Button
                    variant="secondary"
                    onClick={handleLeavePlan}
                    disabled={isLeaving}
                    className="gap-2"
                  >
                    <UserMinus className="h-4 w-4" />
                    {isLeaving ? "Leaving..." : "Leave Plan"}
                  </Button>
                ) : null}
                {plan.isOwner && (
                  <Button variant="secondary" className="gap-2" onClick={handleOpenEditDialog}>
                    <Edit className="h-4 w-4" />
                    Edit Plan
                  </Button>
                )}
              </div>
            </div>

            {isEnrolled && (
              <div className="mt-6 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Your Progress</span>
                  <span className="font-medium text-foreground">{progress}%</span>
                </div>
                <Progress value={progress} className="h-3" />
                <p className="text-sm text-muted-foreground">
                  {completedEntries.length} of {plan.entries.length} readings completed
                </p>
              </div>
            )}
          </CardHeader>
        </Card>
      </motion.div>

      {/* Custom Weekly Schedule */}
      {plan.customWeeklySchedule && plan.customWeeklySchedule.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Weekly Schedule</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
                {plan.customWeeklySchedule.map((day) => (
                  <div
                    key={day.day}
                    className="p-3 rounded-lg border border-border bg-muted/30"
                  >
                    <div className="font-medium text-foreground">
                      {weekDayLabels[day.day]}
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      {dayTypeLabels[day.type]}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Resource Materials */}
      {plan.resourceMaterials && plan.resourceMaterials.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Resource Materials</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {plan.resourceMaterials.map((resource, index) => (
                  <div
                    key={index}
                    className="flex items-start justify-between p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {resource.title}
                      </p>
                      <a
                        href={resource.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-primary hover:underline inline-flex items-center gap-1 mt-1 truncate"
                      >
                        {resource.url}
                        <ExternalLink className="h-3 w-3 flex-shrink-0" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Readings List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Readings</CardTitle>
              {plan.isOwner && (
                <Button variant="secondary" size="sm" onClick={handleOpenEditReadingDialog}>
                  Edit Reading
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {plan.entries.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                No readings have been added yet
              </div>
            ) : (
              <div className="space-y-6">
                {(() => {
                  // Group entries by scheduled date
                  const entriesByDate: Record<string, typeof plan.entries> = {};
                  const unscheduledEntries: typeof plan.entries = [];

                  plan.entries.forEach((entry) => {
                    if (entry.scheduledDate) {
                      // Use the date string directly as key to avoid timezone issues
                      const dateKey = entry.scheduledDate;
                      if (!entriesByDate[dateKey]) {
                        entriesByDate[dateKey] = [];
                      }
                      entriesByDate[dateKey].push(entry);
                    } else {
                      unscheduledEntries.push(entry);
                    }
                  });

                  // Sort date groups chronologically
                  const sortedDates = Object.keys(entriesByDate).sort((a, b) => {
                    return a.localeCompare(b);
                  });

                  return (
                    <>
                      {sortedDates.map((dateKey) => {
                        const dateEntries = entriesByDate[dateKey];
                        // Parse date in local timezone (YYYY-MM-DD format)
                        const [year, month, day] = dateKey.split("-").map(Number);
                        const date = new Date(year, month - 1, day);
                        const dayOfWeek = date.toLocaleDateString("en-US", {
                          weekday: "long",
                        });
                        const displayDate = date.toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        });

                        return (
                          <div key={dateKey} className="space-y-3">
                            {/* Date Header */}
                            <div className="flex items-center gap-3">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-5 w-5 text-primary" />
                                <h3 className="font-semibold text-lg text-foreground">
                                  {dayOfWeek}, {displayDate}
                                </h3>
                              </div>
                              <Separator className="flex-1" />
                            </div>

                            {/* Entries for this date */}
                            <div className="space-y-3 pl-4">
                              {dateEntries.map((entry) => {
                                const isCompleted = completedEntries.includes(entry.order);
                                const isToggling = togglingEntry === entry.order;

                                return (
                                  <div
                                    key={entry._id}
                                    className="flex items-start gap-3 p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors cursor-pointer"
                                    onClick={() => setViewingReadingId(entry._id)}
                                  >
                                    {isEnrolled && (
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleToggleEntry(entry.order, isCompleted);
                                        }}
                                        disabled={isToggling}
                                        className="flex-shrink-0 mt-0.5"
                                      >
                                        {isCompleted ? (
                                          <CheckCircle2 className="h-6 w-6 text-primary" />
                                        ) : (
                                          <Circle className="h-6 w-6 text-muted-foreground hover:text-foreground transition-colors" />
                                        )}
                                      </button>
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-start justify-between gap-2">
                                        <div className="flex-1">
                                          <h4 className="font-medium text-foreground">
                                            {entry.title}
                                          </h4>
                                          {entry.description && (
                                            <div className="text-sm text-muted-foreground mt-1 prose prose-sm max-w-none">
                                              <ReactMarkdown
                                                components={{
                                                  a: ({ node, ...props }) => (
                                                    <a
                                                      {...props}
                                                      target="_blank"
                                                      rel="noopener noreferrer"
                                                      className="text-primary hover:underline"
                                                    />
                                                  ),
                                                }}
                                              >
                                                {entry.description}
                                              </ReactMarkdown>
                                            </div>
                                          )}
                                          {entry.bibleReferences &&
                                            entry.bibleReferences.length > 0 && (
                                              <div className="flex flex-wrap gap-2 mt-2">
                                                {entry.bibleReferences.map((ref) => (
                                                  <a
                                                    key={ref}
                                                    href={`https://www.bible.com/search/bible?q=${encodeURIComponent(ref)}`}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-primary/10 text-primary text-sm hover:bg-primary/20 transition-colors"
                                                  >
                                                    <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-3 w-3 object-contain" />
                                                    {ref}
                                                  </a>
                                                ))}
                                              </div>
                                            )}
                                          {entry.externalLinks &&
                                            entry.externalLinks.length > 0 && (
                                              <div className="flex flex-wrap gap-2 mt-2">
                                                {entry.externalLinks.map((link, linkIndex) => (
                                                  <a
                                                    key={linkIndex}
                                                    href={link}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="flex items-center gap-1 text-sm text-primary hover:underline"
                                                  >
                                                    <LinkIcon className="h-3 w-3" />
                                                    Link
                                                  </a>
                                                ))}
                                              </div>
                                            )}
                                          {(() => {
                                            // Combine plan-level and entry-specific reflection prompts
                                            const planPrompts = plan.reflectionPrompts || [];
                                            const entryPrompts = entry.reflectionPrompts || [];
                                            const allPrompts = [
                                              ...planPrompts.map((p, idx) => ({ text: p, index: idx, source: 'plan' as const })),
                                              ...entryPrompts.map((p, idx) => ({ text: p, index: planPrompts.length + idx, source: 'entry' as const }))
                                            ];
                                            
                                            if (allPrompts.length === 0) return null;
                                            
                                            return (
                                              <div className="mt-4 space-y-3">
                                                {allPrompts.map((prompt) => (
                                                  <div key={prompt.index} className="p-4 rounded-lg bg-primary/5 border border-primary/10 space-y-3">
                                                    <div>
                                                      <div className="flex items-center gap-2 mb-1">
                                                        <h5 className="text-sm font-semibold text-foreground">
                                                          Reflection Question {prompt.index + 1}
                                                        </h5>
                                                        <Badge variant={prompt.source === 'plan' ? 'default' : 'secondary'} className="text-xs h-5">
                                                          {prompt.source === 'plan' ? 'All Readings' : 'This Reading'}
                                                        </Badge>
                                                      </div>
                                                      <p className="text-sm text-muted-foreground">
                                                        {prompt.text}
                                                      </p>
                                                    </div>
                                                    {isEnrolled && (
                                                      <div className="space-y-2">
                                                        <h6 className="text-sm font-semibold text-foreground">
                                                          Reflect and React
                                                        </h6>
                                                        <p className="text-xs text-muted-foreground">
                                                          Write your personal thoughts and action steps
                                                        </p>
                                                        <Textarea
                                                          placeholder="What is this reading calling you to do? Write your reflections here..."
                                                          value={reflectionResponses[entry._id]?.[prompt.index] || ""}
                                                          onChange={(e) =>
                                                            setReflectionResponses((prev) => ({
                                                              ...prev,
                                                              [entry._id]: {
                                                                ...(prev[entry._id] || {}),
                                                                [prompt.index]: e.target.value,
                                                              },
                                                            }))
                                                          }
                                                          rows={4}
                                                          className="resize-none"
                                                        />
                                                        <div className="flex items-center gap-2">
                                                          <Label htmlFor={`visibility-${entry._id}-${prompt.index}`} className="text-xs">
                                                            Visibility:
                                                          </Label>
                                                          <Select
                                                            value={reflectionVisibility[entry._id]?.[prompt.index] || "private"}
                                                            onValueChange={(value: "private" | "group") => 
                                                              setReflectionVisibility((prev) => ({
                                                                ...prev,
                                                                [entry._id]: {
                                                                  ...(prev[entry._id] || {}),
                                                                  [prompt.index]: value,
                                                                },
                                                              }))
                                                            }
                                                          >
                                                            <SelectTrigger id={`visibility-${entry._id}-${prompt.index}`} className="h-8 w-[140px]">
                                                              <SelectValue />
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                              <SelectItem value="private">Private</SelectItem>
                                                              <SelectItem value="group">Group</SelectItem>
                                                            </SelectContent>
                                                          </Select>
                                                        </div>
                                                        <Button
                                                          size="sm"
                                                          onClick={() => handleSaveReflection(entry._id, prompt.index, prompt.text)}
                                                          disabled={savingReflection === `${entry._id}-${prompt.index}`}
                                                          className="gap-2"
                                                        >
                                                          <Send className="h-3 w-3" />
                                                          {savingReflection === `${entry._id}-${prompt.index}` ? "Saving..." : "Save Reflection"}
                                                        </Button>
                                                      </div>
                                                    )}
                                                  </div>
                                                ))}
                                              </div>
                                            );
                                          })()}
                                        </div>
                                        {plan.isOwner && (
                                          <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8 flex-shrink-0"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              toast.info("Coming soon in a future update!");
                                            }}
                                          >
                                            <Trash2 className="h-4 w-4" />
                                          </Button>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}

                      {/* Unscheduled entries */}
                      {unscheduledEntries.length > 0 && (
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <h3 className="font-semibold text-lg text-foreground">
                              Unscheduled
                            </h3>
                            <Separator className="flex-1" />
                          </div>
                          <div className="space-y-3 pl-4">
                            {unscheduledEntries.map((entry) => {
                              const isCompleted = completedEntries.includes(entry.order);
                              const isToggling = togglingEntry === entry.order;

                              return (
                                <div
                                  key={entry._id}
                                  className="flex items-start gap-3 p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                                >
                                  {isEnrolled && (
                                    <button
                                      onClick={() =>
                                        handleToggleEntry(entry.order, isCompleted)
                                      }
                                      disabled={isToggling}
                                      className="flex-shrink-0 mt-0.5"
                                    >
                                      {isCompleted ? (
                                        <CheckCircle2 className="h-6 w-6 text-primary" />
                                      ) : (
                                        <Circle className="h-6 w-6 text-muted-foreground hover:text-foreground transition-colors" />
                                      )}
                                    </button>
                                  )}
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-2">
                                      <div className="flex-1">
                                        <h4 className="font-medium text-foreground">
                                          {entry.title}
                                        </h4>
                                        {entry.description && (
                                          <div className="text-sm text-muted-foreground mt-1 prose prose-sm max-w-none">
                                            <ReactMarkdown
                                              components={{
                                                a: ({ node, ...props }) => (
                                                  <a
                                                    {...props}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="text-primary hover:underline"
                                                  />
                                                ),
                                              }}
                                            >
                                              {entry.description}
                                            </ReactMarkdown>
                                          </div>
                                        )}
                                        {entry.bibleReferences &&
                                          entry.bibleReferences.length > 0 && (
                                            <div className="flex flex-wrap gap-2 mt-2">
                                              {entry.bibleReferences.map((ref) => (
                                                <a
                                                  key={ref}
                                                  href={`https://www.bible.com/search/bible?q=${encodeURIComponent(ref)}`}
                                                  target="_blank"
                                                  rel="noopener noreferrer"
                                                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-primary/10 text-primary text-sm hover:bg-primary/20 transition-colors"
                                                >
                                                  <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-3 w-3 object-contain" />
                                                  {ref}
                                                </a>
                                              ))}
                                            </div>
                                          )}
                                        {entry.externalLinks &&
                                          entry.externalLinks.length > 0 && (
                                            <div className="flex flex-wrap gap-2 mt-2">
                                              {entry.externalLinks.map((link, linkIndex) => (
                                                <a
                                                  key={linkIndex}
                                                  href={link}
                                                  target="_blank"
                                                  rel="noopener noreferrer"
                                                  className="flex items-center gap-1 text-sm text-primary hover:underline"
                                                >
                                                  <LinkIcon className="h-3 w-3" />
                                                  Link
                                                </a>
                                              ))}
                                            </div>
                                          )}
                                        {(() => {
                                          // Combine plan-level and entry-specific reflection prompts
                                          const planPrompts = plan.reflectionPrompts || [];
                                          const entryPrompts = entry.reflectionPrompts || [];
                                          const allPrompts = [
                                            ...planPrompts.map((p, idx) => ({ text: p, index: idx, source: 'plan' as const })),
                                            ...entryPrompts.map((p, idx) => ({ text: p, index: planPrompts.length + idx, source: 'entry' as const }))
                                          ];
                                          
                                          if (allPrompts.length === 0) return null;
                                          
                                          return (
                                            <div className="mt-4 space-y-3">
                                              {allPrompts.map((prompt) => (
                                                <div key={prompt.index} className="p-4 rounded-lg bg-primary/5 border border-primary/10 space-y-3">
                                                  <div>
                                                    <div className="flex items-center gap-2 mb-1">
                                                      <h5 className="text-sm font-semibold text-foreground">
                                                        Reflection Question {prompt.index + 1}
                                                      </h5>
                                                      <Badge variant={prompt.source === 'plan' ? 'default' : 'secondary'} className="text-xs h-5">
                                                        {prompt.source === 'plan' ? 'All Readings' : 'This Reading'}
                                                      </Badge>
                                                    </div>
                                                    <p className="text-sm text-muted-foreground">
                                                      {prompt.text}
                                                    </p>
                                                  </div>
                                                  {isEnrolled && (
                                                    <div className="space-y-2">
                                                      <h6 className="text-sm font-semibold text-foreground">
                                                        Reflect and React
                                                      </h6>
                                                      <p className="text-xs text-muted-foreground">
                                                        Write your personal thoughts and action steps
                                                      </p>
                                                      <Textarea
                                                        placeholder="What is this reading calling you to do? Write your reflections here..."
                                                        value={reflectionResponses[entry._id]?.[prompt.index] || ""}
                                                        onChange={(e) =>
                                                          setReflectionResponses((prev) => ({
                                                            ...prev,
                                                            [entry._id]: {
                                                              ...(prev[entry._id] || {}),
                                                              [prompt.index]: e.target.value,
                                                            },
                                                          }))
                                                        }
                                                        rows={4}
                                                        className="resize-none"
                                                      />
                                                      <div className="flex items-center gap-2">
                                                        <Label htmlFor={`visibility-unscheduled-${entry._id}-${prompt.index}`} className="text-xs">
                                                          Visibility:
                                                        </Label>
                                                        <Select
                                                          value={reflectionVisibility[entry._id]?.[prompt.index] || "private"}
                                                          onValueChange={(value: "private" | "group") => 
                                                            setReflectionVisibility((prev) => ({
                                                              ...prev,
                                                              [entry._id]: {
                                                                ...(prev[entry._id] || {}),
                                                                [prompt.index]: value,
                                                              },
                                                            }))
                                                          }
                                                        >
                                                          <SelectTrigger id={`visibility-unscheduled-${entry._id}-${prompt.index}`} className="h-8 w-[140px]">
                                                            <SelectValue />
                                                          </SelectTrigger>
                                                          <SelectContent>
                                                            <SelectItem value="private">Private</SelectItem>
                                                            <SelectItem value="group">Group</SelectItem>
                                                          </SelectContent>
                                                        </Select>
                                                      </div>
                                                      <Button
                                                        size="sm"
                                                        onClick={() => handleSaveReflection(entry._id, prompt.index, prompt.text)}
                                                        disabled={savingReflection === `${entry._id}-${prompt.index}`}
                                                        className="gap-2"
                                                      >
                                                        <Send className="h-3 w-3" />
                                                        {savingReflection === `${entry._id}-${prompt.index}` ? "Saving..." : "Save Reflection"}
                                                      </Button>
                                                    </div>
                                                  )}
                                                </div>
                                              ))}
                                            </div>
                                          );
                                        })()}
                                      </div>
                                      {plan.isOwner && (
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-8 w-8 flex-shrink-0"
                                          onClick={() =>
                                            toast.info("Coming soon in a future update!")
                                          }
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Edit Plan Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Plan</DialogTitle>
            <DialogDescription>
              Update your reading plan details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">Title</Label>
              <Input
                id="edit-title"
                value={editForm.title}
                onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                placeholder="Enter plan title"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                placeholder="Enter plan description"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-schedule">Schedule Type</Label>
              <Select
                value={editForm.scheduleType}
                onValueChange={(value) =>
                  setEditForm({ ...editForm, scheduleType: value as typeof editForm.scheduleType })
                }
              >
                <SelectTrigger id="edit-schedule">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-visibility">Visibility</Label>
              <Select
                value={editForm.visibility}
                onValueChange={(value) =>
                  setEditForm({ ...editForm, visibility: value as typeof editForm.visibility })
                }
              >
                <SelectTrigger id="edit-visibility">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="private">Private</SelectItem>
                  <SelectItem value="public">Public</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Public plans require admin approval before becoming visible to others
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-color">Color</Label>
              <div className="flex gap-2">
                <Input
                  id="edit-color"
                  type="color"
                  value={editForm.color}
                  onChange={(e) => setEditForm({ ...editForm, color: e.target.value })}
                  className="w-16 h-10"
                />
                <Input
                  value={editForm.color}
                  onChange={(e) => setEditForm({ ...editForm, color: e.target.value })}
                  placeholder="#8B4513"
                  className="flex-1"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Reflection Questions</Label>
              <p className="text-sm text-muted-foreground">
                These questions will guide participants' reflections
              </p>
              <div className="flex gap-2">
                <Textarea
                  placeholder="Add a reflection question..."
                  value={newPrompt}
                  onChange={(e) => setNewPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      addPromptToEditForm();
                    }
                  }}
                  rows={2}
                  className="resize-none"
                />
                <Button type="button" onClick={addPromptToEditForm} size="icon">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {editForm.reflectionPrompts.length > 0 && (
                <div className="space-y-2 mt-2 max-h-[200px] overflow-y-auto pr-2">
                  {editForm.reflectionPrompts.map((prompt, index) => (
                    <div
                      key={index}
                      className="flex items-start justify-between p-2 border rounded-lg bg-muted/30 gap-2"
                    >
                      <p className="text-sm flex-1">{prompt}</p>
                      <button
                        type="button"
                        onClick={() => removePromptFromEditForm(index)}
                        className="hover:text-destructive flex-shrink-0"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label>Start & End Dates</Label>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Input
                    type="date"
                    value={editForm.startDate}
                    onChange={(e) => setEditForm({ ...editForm, startDate: e.target.value })}
                    placeholder="Start date"
                  />
                </div>
                <div>
                  <Input
                    type="date"
                    value={editForm.endDate}
                    onChange={(e) => setEditForm({ ...editForm, endDate: e.target.value })}
                    placeholder="End date"
                  />
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Labels</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Add a label..."
                  value={newLabel}
                  onChange={(e) => setNewLabel(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addLabelToEditForm();
                    }
                  }}
                />
                <Button type="button" onClick={addLabelToEditForm} size="icon">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {editForm.labels.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {editForm.labels.map((label, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-1 px-2 py-1 border rounded-md bg-muted/30"
                    >
                      <span className="text-sm">{label}</span>
                      <button
                        type="button"
                        onClick={() => removeLabelFromEditForm(index)}
                        className="hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label>Resource Materials</Label>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  placeholder="Resource title"
                  value={newResourceTitle}
                  onChange={(e) => setNewResourceTitle(e.target.value)}
                />
                <div className="flex gap-1">
                  <Input
                    placeholder="URL"
                    value={newResourceUrl}
                    onChange={(e) => setNewResourceUrl(e.target.value)}
                  />
                  <Button type="button" onClick={addResourceToEditForm} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              {editForm.resourceMaterials.length > 0 && (
                <div className="space-y-2 mt-2 max-h-[150px] overflow-y-auto pr-2">
                  {editForm.resourceMaterials.map((resource, index) => (
                    <div
                      key={index}
                      className="flex items-start justify-between p-2 border rounded-lg bg-muted/30 gap-2"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{resource.title}</p>
                        <p className="text-xs text-muted-foreground truncate">{resource.url}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeResourceFromEditForm(index)}
                        className="hover:text-destructive flex-shrink-0"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="space-y-4 border-t pt-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="edit-reminder">Enable Reminders</Label>
                  <p className="text-xs text-muted-foreground">
                    Get notifications for your reading schedule
                  </p>
                </div>
                <Switch
                  id="edit-reminder"
                  checked={editForm.reminderEnabled}
                  onCheckedChange={(checked) =>
                    setEditForm({ ...editForm, reminderEnabled: checked })
                  }
                />
              </div>
              {notificationsSupported && (
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Bell className="h-4 w-4" />
                      <Label htmlFor="push-notifications">Push Notifications</Label>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {notificationsEnabled 
                        ? "Browser notifications are enabled" 
                        : "Enable browser notifications for reminders"}
                    </p>
                  </div>
                  <Switch
                    id="push-notifications"
                    checked={notificationsEnabled}
                    onCheckedChange={toggleNotifications}
                  />
                </div>
              )}
              {!notificationsSupported && (
                <p className="text-xs text-muted-foreground">
                  Push notifications are not supported in your browser
                </p>
              )}
            </div>
            <div className="flex gap-2 justify-end pt-4">
              <Button
                variant="outline"
                onClick={() => setEditDialogOpen(false)}
                disabled={isUpdating}
              >
                Cancel
              </Button>
              <Button onClick={handleUpdatePlan} disabled={isUpdating}>
                {isUpdating ? "Updating..." : "Update Plan"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Reading Dialog */}
      <Dialog open={editReadingDialogOpen} onOpenChange={setEditReadingDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Reading</DialogTitle>
            <DialogDescription>
              Select a reading to edit its details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Reading Selection */}
            {!selectedEntryId && (
              <div className="space-y-2">
                <Label>Select a Reading to Edit</Label>
                <div className="max-h-[400px] overflow-y-auto space-y-2 border rounded-lg p-2">
                  {plan?.entries.map((entry) => (
                    <button
                      key={entry._id}
                      onClick={() => handleSelectEntry(entry._id)}
                      className="w-full text-left p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-foreground truncate">
                            {entry.title}
                          </h4>
                          {entry.scheduledDate && (
                            <p className="text-sm text-muted-foreground mt-1">
                              {new Date(entry.scheduledDate + "T00:00:00").toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </p>
                          )}
                        </div>
                        <Edit className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Edit Form */}
            {selectedEntryId && (
              <>
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Editing: {editReadingForm.title}</h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedEntryId(null)}
                  >
                    Choose Different Reading
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="reading-title">Title</Label>
                    <Input
                      id="reading-title"
                      value={editReadingForm.title}
                      onChange={(e) =>
                        setEditReadingForm({ ...editReadingForm, title: e.target.value })
                      }
                      placeholder="Reading title"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reading-description">Description</Label>
                    <Textarea
                      id="reading-description"
                      value={editReadingForm.description}
                      onChange={(e) =>
                        setEditReadingForm({ ...editReadingForm, description: e.target.value })
                      }
                      placeholder="Reading description (supports markdown)"
                      rows={4}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reading-date">Scheduled Date</Label>
                    <Input
                      id="reading-date"
                      type="date"
                      value={editReadingForm.scheduledDate}
                      onChange={(e) =>
                        setEditReadingForm({ ...editReadingForm, scheduledDate: e.target.value })
                      }
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Bible References</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="e.g., Matthew 5:1-10"
                        value={newBibleRef}
                        onChange={(e) => setNewBibleRef(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            addBibleRefToEditReadingForm();
                          }
                        }}
                      />
                      <Button type="button" onClick={addBibleRefToEditReadingForm} size="icon">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    {editReadingForm.bibleReferences.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-2">
                        {editReadingForm.bibleReferences.map((ref, index) => (
                          <div
                            key={index}
                            className="flex items-center gap-1 px-2 py-1 border rounded-md bg-muted/30"
                          >
                            <span className="text-sm">{ref}</span>
                            <button
                              type="button"
                              onClick={() => removeBibleRefFromEditReadingForm(index)}
                              className="hover:text-destructive"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>External Links</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="https://example.com"
                        value={newExternalLink}
                        onChange={(e) => setNewExternalLink(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            addExternalLinkToEditReadingForm();
                          }
                        }}
                      />
                      <Button type="button" onClick={addExternalLinkToEditReadingForm} size="icon">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    {editReadingForm.externalLinks.length > 0 && (
                      <div className="space-y-2 mt-2">
                        {editReadingForm.externalLinks.map((link, index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-2 border rounded-lg bg-muted/30"
                          >
                            <a
                              href={link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm text-primary hover:underline truncate flex-1"
                            >
                              {link}
                            </a>
                            <button
                              type="button"
                              onClick={() => removeExternalLinkFromEditReadingForm(index)}
                              className="hover:text-destructive flex-shrink-0 ml-2"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Reflection Questions for This Reading</Label>
                    <p className="text-xs text-muted-foreground">
                      These questions will only appear for this specific reading. Plan-level questions (labeled "All Readings") will also appear.
                    </p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="e.g., How does this passage apply to your life?"
                        value={newReadingPrompt}
                        onChange={(e) => setNewReadingPrompt(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            addReadingPromptToEditReadingForm();
                          }
                        }}
                      />
                      <Button type="button" onClick={addReadingPromptToEditReadingForm} size="icon">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    {editReadingForm.reflectionPrompts.length > 0 && (
                      <div className="space-y-2 mt-2 max-h-[200px] overflow-y-auto pr-2">
                        {editReadingForm.reflectionPrompts.map((prompt, index) => (
                          <div
                            key={index}
                            className="flex items-start justify-between p-2 border rounded-lg bg-muted/30 gap-2"
                          >
                            <p className="text-sm flex-1">{prompt}</p>
                            <button
                              type="button"
                              onClick={() => removeReadingPromptFromEditReadingForm(index)}
                              className="hover:text-destructive flex-shrink-0"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 justify-end pt-4">
                  <Button
                    variant="outline"
                    onClick={() => setEditReadingDialogOpen(false)}
                    disabled={isUpdatingReading}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleUpdateReading} disabled={isUpdatingReading}>
                    {isUpdatingReading ? "Updating..." : "Update Reading"}
                  </Button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function PlanDetail() {
  return (
    <AppLayout>
      <PlanDetailContent />
    </AppLayout>
  );
}
