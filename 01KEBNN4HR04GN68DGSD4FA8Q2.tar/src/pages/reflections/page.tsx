import { Link } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import {
  FileText,
  Heart,
  MessageCircle,
  Plus,
  Trash2,
  Edit,
  Calendar,
  Eye,
  EyeOff,
  Users,
  Archive,
  ArchiveRestore,
  Search,
  Filter,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import type { Id } from "@/convex/_generated/dataModel.d.ts";

type Visibility = "public" | "private" | "group";

function ReflectionsContent() {
  const reflections = useQuery(api.reflections.getMyReflections);
  const archivedReflections = useQuery(api.reflections.getArchivedReflections);
  const deleteReflection = useMutation(api.reflections.deleteReflection);
  const archiveReflection = useMutation(api.reflections.archiveReflection);
  const unarchiveReflection = useMutation(api.reflections.unarchiveReflection);
  const autoArchiveOldReflections = useMutation(api.reflections.autoArchiveOldReflections);
  const toggleLike = useMutation(api.reflections.toggleLike);
  const createReflection = useMutation(api.reflections.create);
  const updateReflection = useMutation(api.reflections.update);
  const myPlans = useQuery(api.readingPlans.getMyPlans);
  const myGroups = useQuery(api.groups.getMyGroups);

  const [isCreating, setIsCreating] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [togglingLike, setTogglingLike] = useState<string | null>(null);
  const [archivingId, setArchivingId] = useState<string | null>(null);
  const [showSearch, setShowSearch] = useState(false);
  const [activeTab, setActiveTab] = useState<"active" | "archived">("active");
  const [editingReflection, setEditingReflection] = useState<{
    id: Id<"reflections">;
    content: string;
    visibility: Visibility;
  } | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [searchDateFrom, setSearchDateFrom] = useState("");
  const [searchDateTo, setSearchDateTo] = useState("");
  const [searchPlanId, setSearchPlanId] = useState("");
  const [searchBibleRef, setSearchBibleRef] = useState("");

  const searchResults = useQuery(
    api.reflections.searchReflections,
    showSearch && (searchQuery || searchDateFrom || searchDateTo || searchPlanId || searchBibleRef)
      ? {
          searchQuery: searchQuery || undefined,
          startDate: searchDateFrom || undefined,
          endDate: searchDateTo || undefined,
          planId: searchPlanId ? (searchPlanId as Id<"readingPlans">) : undefined,
          includeArchived: activeTab === "archived",
        }
      : "skip"
  );

  const [formData, setFormData] = useState({
    planId: "",
    content: "",
    visibility: "public" as Visibility,
    groupId: "",
  });

  // Auto-archive old reflections on mount
  useEffect(() => {
    autoArchiveOldReflections().catch(() => {
      // Silent fail - this is a background task
    });
  }, [autoArchiveOldReflections]);

  const handleArchive = async (reflectionId: Id<"reflections">) => {
    setArchivingId(reflectionId);
    try {
      await archiveReflection({ reflectionId });
      toast.success("Reflection archived");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to archive reflection");
    } finally {
      setArchivingId(null);
    }
  };

  const handleUnarchive = async (reflectionId: Id<"reflections">) => {
    setArchivingId(reflectionId);
    try {
      await unarchiveReflection({ reflectionId });
      toast.success("Reflection restored");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to restore reflection");
    } finally {
      setArchivingId(null);
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
    setSearchDateFrom("");
    setSearchDateTo("");
    setSearchPlanId("");
    setSearchBibleRef("");
  };

  const hasActiveFilters = searchQuery || searchDateFrom || searchDateTo || searchPlanId || searchBibleRef;

  const handleCreateReflection = async () => {
    if (!formData.content.trim() || !formData.planId) {
      toast.error("Please select a plan and write your reflection");
      return;
    }

    if (formData.visibility === "group" && !formData.groupId) {
      toast.error("Please select a group");
      return;
    }

    setIsCreating(true);
    try {
      await createReflection({
        planId: formData.planId as Id<"readingPlans">,
        content: formData.content,
        visibility: formData.visibility,
        groupId: formData.groupId ? (formData.groupId as Id<"groups">) : undefined,
      });
      toast.success("Reflection created successfully");
      setFormData({ planId: "", content: "", visibility: "public", groupId: "" });
      setIsDialogOpen(false);
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to create reflection");
    } finally {
      setIsCreating(false);
    }
  };

  const handleDelete = async (reflectionId: Id<"reflections">) => {
    if (!confirm("Are you sure you want to delete this reflection?")) {
      return;
    }
    setDeletingId(reflectionId);
    try {
      await deleteReflection({ reflectionId });
      toast.success("Reflection deleted");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to delete reflection");
    } finally {
      setDeletingId(null);
    }
  };

  const handleToggleLike = async (reflectionId: Id<"reflections">) => {
    setTogglingLike(reflectionId);
    try {
      await toggleLike({ reflectionId });
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to like reflection");
    } finally {
      setTogglingLike(null);
    }
  };

  const handleEditClick = (reflection: typeof displayReflections[0]) => {
    setEditingReflection({
      id: reflection._id,
      content: reflection.content,
      visibility: reflection.visibility,
    });
  };

  const handleUpdateReflection = async () => {
    if (!editingReflection || !editingReflection.content.trim()) {
      toast.error("Please write your reflection");
      return;
    }

    setIsEditing(true);
    try {
      await updateReflection({
        reflectionId: editingReflection.id,
        content: editingReflection.content,
        visibility: editingReflection.visibility,
      });
      toast.success("Reflection updated successfully");
      setEditingReflection(null);
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to update reflection");
    } finally {
      setIsEditing(false);
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (reflections === undefined || archivedReflections === undefined) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-pulse text-muted-foreground">Loading reflections...</div>
      </div>
    );
  }

  const visibilityIcons = {
    public: Eye,
    private: EyeOff,
    group: Users,
  };

  const visibilityLabels = {
    public: "Public",
    private: "Private",
    group: "Group",
  };

  // Determine which data to display
  const displayReflections = hasActiveFilters && searchResults
    ? searchResults
    : activeTab === "active"
      ? reflections
      : archivedReflections;

  const renderReflectionCard = (reflection: typeof displayReflections[0], isArchived: boolean) => {
    const VisibilityIcon = visibilityIcons[reflection.visibility];
    return (
      <Card key={reflection._id}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-3 flex-1 min-w-0">
              <Avatar className="h-10 w-10 flex-shrink-0">
                <AvatarImage src={reflection.authorAvatar ?? undefined} />
                <AvatarFallback>{getInitials(reflection.authorName)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground">{reflection.authorName}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                  <span>{new Date(reflection._creationTime).toLocaleDateString()}</span>
                  <span>•</span>
                  <Badge variant="secondary" className="text-xs gap-1">
                    <VisibilityIcon className="h-3 w-3" />
                    {visibilityLabels[reflection.visibility]}
                  </Badge>
                  {isArchived && (
                    <>
                      <span>•</span>
                      <Badge variant="outline" className="text-xs gap-1">
                        <Archive className="h-3 w-3" />
                        Archived
                      </Badge>
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-1 flex-shrink-0">
              {!isArchived && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handleArchive(reflection._id)}
                  disabled={archivingId === reflection._id}
                  title="Archive reflection"
                >
                  <Archive className="h-4 w-4" />
                </Button>
              )}
              {isArchived && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => handleUnarchive(reflection._id)}
                  disabled={archivingId === reflection._id}
                  title="Restore reflection"
                >
                  <ArchiveRestore className="h-4 w-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => handleEditClick(reflection)}
                title="Edit reflection"
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive"
                onClick={() => handleDelete(reflection._id)}
                disabled={deletingId === reflection._id}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-2 text-sm">
            <Link
              to={`/plans/${reflection.planId}`}
              className="flex items-center gap-1 text-primary hover:underline"
            >
              <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-4 w-4 object-contain" />
              {reflection.planTitle}
            </Link>
            {reflection.entryTitle && (
              <>
                <span className="text-muted-foreground">•</span>
                <span className="text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {reflection.entryTitle}
                  {reflection.entryScheduledDate && (
                    <span className="text-xs">
                      ({new Date(reflection.entryScheduledDate).toLocaleDateString()})
                    </span>
                  )}
                </span>
              </>
            )}
          </div>

          {reflection.questionText && (
            <div className="bg-muted/50 p-3 rounded-lg border-l-4 border-primary/40">
              <p className="text-sm font-medium text-muted-foreground">Reflection Question:</p>
              <p className="text-sm text-foreground mt-1">{reflection.questionText}</p>
            </div>
          )}

          <p className="text-foreground whitespace-pre-wrap">{reflection.content}</p>

          <div className="flex items-center gap-4 pt-2 border-t border-border">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2"
              onClick={() => handleToggleLike(reflection._id)}
              disabled={togglingLike === reflection._id}
            >
              <Heart
                className={`h-4 w-4 ${reflection.isLikedByUser ? "fill-primary text-primary" : ""}`}
              />
              <span>{reflection.likeCount}</span>
            </Button>
            <Button variant="ghost" size="sm" className="gap-2">
              <MessageCircle className="h-4 w-4" />
              <span>{reflection.commentCount}</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">My Reflections</h1>
          <p className="text-muted-foreground mt-1">
            Document your thoughts and insights from your reading journey
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={showSearch ? "secondary" : "ghost"}
            size="icon"
            onClick={() => setShowSearch(!showSearch)}
            title={showSearch ? "Hide search" : "Show search"}
          >
            {showSearch ? <X className="h-4 w-4" /> : <Search className="h-4 w-4" />}
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                New Reflection
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Reflection</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Reading Plan</Label>
                  <Select
                    value={formData.planId}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, planId: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a reading plan..." />
                    </SelectTrigger>
                    <SelectContent>
                      {myPlans?.map((plan) => (
                        <SelectItem key={plan._id} value={plan._id}>
                          {plan.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Your Reflection</Label>
                  <Textarea
                    placeholder="Share your thoughts, insights, or questions..."
                    value={formData.content}
                    onChange={(e) => setFormData((prev) => ({ ...prev, content: e.target.value }))}
                    rows={6}
                    className="resize-none"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Visibility</Label>
                  <Select
                    value={formData.visibility}
                    onValueChange={(value: Visibility) =>
                      setFormData((prev) => ({ ...prev, visibility: value, groupId: "" }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">
                        <div className="flex flex-col items-start">
                          <span className="font-medium">Public</span>
                          <span className="text-xs text-muted-foreground">
                            Anyone can see this reflection
                          </span>
                        </div>
                      </SelectItem>
                      <SelectItem value="private">
                        <div className="flex flex-col items-start">
                          <span className="font-medium">Private</span>
                          <span className="text-xs text-muted-foreground">Only you can see this</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="group">
                        <div className="flex flex-col items-start">
                          <span className="font-medium">Group</span>
                          <span className="text-xs text-muted-foreground">
                            Share with a specific group
                          </span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.visibility === "group" && (
                  <div className="space-y-2">
                    <Label>Select Group</Label>
                    <Select
                      value={formData.groupId}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, groupId: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a group..." />
                      </SelectTrigger>
                      <SelectContent>
                        {myGroups?.map((group) => (
                          <SelectItem key={group._id} value={group._id}>
                            {group.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="flex justify-end gap-2 pt-2">
                  <Button variant="secondary" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateReflection} disabled={isCreating}>
                    {isCreating ? "Creating..." : "Create Reflection"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </motion.div>

      {/* Edit Reflection Dialog */}
      <Dialog open={!!editingReflection} onOpenChange={(open) => !open && setEditingReflection(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Reflection</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Your Reflection</Label>
              <Textarea
                placeholder="Share your thoughts, insights, or questions..."
                value={editingReflection?.content || ""}
                onChange={(e) =>
                  setEditingReflection((prev) =>
                    prev ? { ...prev, content: e.target.value } : null
                  )
                }
                rows={6}
                className="resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label>Visibility</Label>
              <Select
                value={editingReflection?.visibility || "public"}
                onValueChange={(value: Visibility) =>
                  setEditingReflection((prev) =>
                    prev ? { ...prev, visibility: value } : null
                  )
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">
                    <div className="flex flex-col items-start">
                      <span className="font-medium">Public</span>
                      <span className="text-xs text-muted-foreground">
                        Anyone can see this reflection
                      </span>
                    </div>
                  </SelectItem>
                  <SelectItem value="private">
                    <div className="flex flex-col items-start">
                      <span className="font-medium">Private</span>
                      <span className="text-xs text-muted-foreground">Only you can see this</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="group">
                    <div className="flex flex-col items-start">
                      <span className="font-medium">Group</span>
                      <span className="text-xs text-muted-foreground">
                        Share with a specific group
                      </span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="secondary" onClick={() => setEditingReflection(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateReflection} disabled={isEditing}>
                {isEditing ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Search UI */}
      {showSearch && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <h3 className="font-semibold text-foreground">Search & Filter</h3>
              </div>
              {hasActiveFilters && (
                <Button variant="ghost" size="sm" onClick={clearSearch}>
                  Clear all
                </Button>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Keyword Search</Label>
                <Input
                  placeholder="Search in title, content, or Bible reference..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Reading Plan</Label>
                <Select value={searchPlanId} onValueChange={setSearchPlanId}>
                  <SelectTrigger>
                    <SelectValue placeholder="All plans" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All plans</SelectItem>
                    {myPlans?.map((plan) => (
                      <SelectItem key={plan._id} value={plan._id}>
                        {plan.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>From Date</Label>
                <Input
                  type="date"
                  value={searchDateFrom}
                  onChange={(e) => setSearchDateFrom(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>To Date</Label>
                <Input
                  type="date"
                  value={searchDateTo}
                  onChange={(e) => setSearchDateTo(e.target.value)}
                />
              </div>
            </div>
            {hasActiveFilters && (
              <div className="mt-4 pt-4 border-t border-border">
                <p className="text-sm text-muted-foreground">
                  {searchResults === undefined ? (
                    "Searching..."
                  ) : (
                    <>Found {searchResults.length} reflection{searchResults.length !== 1 ? "s" : ""}</>
                  )}
                </p>
              </div>
            )}
          </Card>
        </motion.div>
      )}

      {/* Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "active" | "archived")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="active">
              Active ({reflections.length})
            </TabsTrigger>
            <TabsTrigger value="archived">
              Archived ({archivedReflections.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="mt-6">
            {displayReflections.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <FileText />
                  </EmptyMedia>
                  <EmptyTitle>
                    {hasActiveFilters ? "No reflections found" : "No reflections yet"}
                  </EmptyTitle>
                  <EmptyDescription>
                    {hasActiveFilters
                      ? "Try adjusting your search filters"
                      : "Start documenting your reading journey by creating your first reflection"}
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  {hasActiveFilters ? (
                    <Button size="sm" variant="secondary" onClick={clearSearch}>
                      Clear filters
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => setIsDialogOpen(true)}>
                      Create Reflection
                    </Button>
                  )}
                </EmptyContent>
              </Empty>
            ) : (
              <div className="space-y-4">
                {displayReflections.map((reflection) =>
                  renderReflectionCard(reflection, false)
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="archived" className="mt-6">
            {displayReflections.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <Archive />
                  </EmptyMedia>
                  <EmptyTitle>No archived reflections</EmptyTitle>
                  <EmptyDescription>
                    Reflections are automatically archived after 14 days or you can manually archive them
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            ) : (
              <div className="space-y-4">
                {displayReflections.map((reflection) =>
                  renderReflectionCard(reflection, true)
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}

export default function Reflections() {
  return (
    <AppLayout>
      <ReflectionsContent />
    </AppLayout>
  );
}
