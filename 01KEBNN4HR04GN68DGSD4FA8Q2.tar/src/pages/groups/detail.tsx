import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Users,
  UserPlus,
  UserMinus,
  Edit,
  Trash2,
  Crown,
  Shield,
  UserCircle,
  Share2,
  FileText,
  Heart,
  MessageCircle,
  Send,
  Link2,
  Copy,
  Check,
  Mail,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { ScrollArea } from "@/components/ui/scroll-area.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { toast } from "sonner";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { useState, useRef, useEffect } from "react";
import { ConvexError } from "convex/values";

const roleIcons = {
  owner: Crown,
  admin: Shield,
  member: UserCircle,
};

const roleLabels = {
  owner: "Owner",
  admin: "Admin",
  member: "Member",
};

function GroupDetailContent() {
  const { groupId } = useParams();
  const navigate = useNavigate();
  const group = useQuery(
    api.groups.getGroupById,
    groupId ? { groupId: groupId as Id<"groups"> } : "skip"
  );
  const joinGroup = useMutation(api.groups.join);
  const leaveGroup = useMutation(api.groups.leave);
  const deleteGroup = useMutation(api.groups.deleteGroup);
  const joinPlan = useMutation(api.readingPlans.joinPlan);
  const updateGroup = useMutation(api.groups.update);
  const sharePlan = useMutation(api.groups.sharePlan);
  const myPlans = useQuery(api.readingPlans.getMyPlans);

  // Landing page content for invite wording
  const landingContent = useQuery(api.landingPage.getContent);

  // Reflections
  const reflections = useQuery(
    api.reflections.getReflectionsByGroup,
    groupId ? { groupId: groupId as Id<"groups"> } : "skip"
  );
  const toggleLike = useMutation(api.reflections.toggleLike);

  // Messages
  const messages = useQuery(
    api.groupMessages.getGroupMessages,
    groupId ? { groupId: groupId as Id<"groups"> } : "skip"
  );
  const sendMessage = useMutation(api.groupMessages.send);

  const [isJoining, setIsJoining] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [joiningPlan, setJoiningPlan] = useState<string | null>(null);
  const [togglingLike, setTogglingLike] = useState<string | null>(null);
  const [messageContent, setMessageContent] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editForm, setEditForm] = useState({
    name: "",
    description: "",
    visibility: "" as "public" | "private",
  });
  const [isUpdating, setIsUpdating] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [selectedPlanId, setSelectedPlanId] = useState<Id<"readingPlans"> | null>(null);
  const [isSharing, setIsSharing] = useState(false);
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [inviteCopied, setInviteCopied] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleJoinGroup = async () => {
    if (!groupId) return;
    setIsJoining(true);
    try {
      await joinGroup({ groupId: groupId as Id<"groups"> });
      toast.success("Successfully joined group!");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to join group");
    } finally {
      setIsJoining(false);
    }
  };

  const handleLeaveGroup = async () => {
    if (!groupId) return;
    if (!confirm("Are you sure you want to leave this group?")) {
      return;
    }
    setIsLeaving(true);
    try {
      await leaveGroup({ groupId: groupId as Id<"groups"> });
      toast.success("Left group successfully");
      navigate("/groups");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to leave group");
    } finally {
      setIsLeaving(false);
    }
  };

  const handleDeleteGroup = async () => {
    if (!groupId) return;
    if (
      !confirm(
        "Are you sure you want to delete this group? This action cannot be undone."
      )
    ) {
      return;
    }
    setIsDeleting(true);
    try {
      await deleteGroup({ groupId: groupId as Id<"groups"> });
      toast.success("Group deleted successfully");
      navigate("/groups");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to delete group");
    } finally {
      setIsDeleting(false);
    }
  };

  const handleJoinPlan = async (planId: Id<"readingPlans">) => {
    setJoiningPlan(planId);
    try {
      await joinPlan({ planId });
      toast.success("Joined plan successfully!");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to join plan");
    } finally {
      setJoiningPlan(null);
    }
  };

  const handleToggleLike = async (reflectionId: Id<"reflections">) => {
    setTogglingLike(reflectionId);
    try {
      await toggleLike({ reflectionId });
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to like reflection");
    } finally {
      setTogglingLike(null);
    }
  };

  const handleSendMessage = async () => {
    if (!groupId || !messageContent.trim()) return;

    setIsSending(true);
    try {
      await sendMessage({
        groupId: groupId as Id<"groups">,
        content: messageContent,
      });
      setMessageContent("");
    } catch (error) {
      const err = error as { data?: { message?: string } };
      toast.error(err.data?.message || "Failed to send message");
    } finally {
      setIsSending(false);
    }
  };

  const handleOpenEditDialog = () => {
    if (!group) return;
    setEditForm({
      name: group.name,
      description: group.description || "",
      visibility: group.visibility,
    });
    setEditDialogOpen(true);
  };

  const handleUpdateGroup = async () => {
    if (!groupId) return;
    setIsUpdating(true);
    try {
      await updateGroup({
        groupId: groupId as Id<"groups">,
        name: editForm.name,
        description: editForm.description || undefined,
        visibility: editForm.visibility,
      });
      toast.success("Group updated successfully");
      setEditDialogOpen(false);
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to update group");
      }
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSharePlan = async () => {
    if (!groupId || !selectedPlanId) return;
    setIsSharing(true);
    try {
      await sharePlan({
        groupId: groupId as Id<"groups">,
        planId: selectedPlanId,
      });
      toast.success("Plan shared with group successfully!");
      setShareDialogOpen(false);
      setSelectedPlanId(null);
    } catch (error) {
      if (error instanceof ConvexError) {
        const { message } = error.data as { code: string; message: string };
        toast.error(message);
      } else {
        toast.error("Failed to share plan");
      }
    } finally {
      setIsSharing(false);
    }
  };

  const handleCopyInviteLink = () => {
    const inviteLink = `${window.location.origin}/groups/${groupId}`;
    navigator.clipboard.writeText(inviteLink);
    setInviteCopied(true);
    toast.success("Invite link copied to clipboard!");
    setTimeout(() => setInviteCopied(false), 2000);
  };

  const handleEmailInvite = () => {
    if (!group) return;
    const inviteLink = `${window.location.origin}/groups/${groupId}`;
    const logoUrl = "https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk";
    const subject = encodeURIComponent(`Join ${group.name} on Read Reflect React`);
    const body = encodeURIComponent(
      `Hi,

I'd like to invite you to join our group "${group.name}" on Read Reflect React.

Click the link below to join:
${inviteLink}

Looking forward to reading together!

---
Read Reflect React - Seeking to Honor the Creator
${logoUrl}`
    );
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  if (!groupId) {
    return <div>Invalid group ID</div>;
  }

  if (group === undefined) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-pulse text-muted-foreground">Loading group...</div>
      </div>
    );
  }

  if (group === null) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground mb-4">Group not found</p>
        <Link to="/groups">
          <Button>Back to Groups</Button>
        </Link>
      </div>
    );
  }

  const isMember = group.userRole !== null;
  const isOwner = group.userRole === "owner";
  const isAdmin = group.userRole === "owner" || group.userRole === "admin";

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to="/groups">
          <Button variant="ghost" size="sm" className="gap-2 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to Groups
          </Button>
        </Link>

        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant={group.visibility === "public" ? "default" : "secondary"}>
                    {group.visibility === "public" ? "Public" : "Private"}
                  </Badge>
                  {isMember && group.userRole && (
                    <Badge variant="secondary">
                      {roleLabels[group.userRole]}
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-2xl sm:text-3xl">{group.name}</CardTitle>
                {group.description && (
                  <p className="text-muted-foreground mt-2">{group.description}</p>
                )}
                <div className="flex flex-wrap gap-3 text-sm text-muted-foreground mt-3">
                  <div className="flex items-center gap-1">
                    <Users className="h-4 w-4" />
                    <span>
                      {group.memberCount} {group.memberCount === 1 ? "member" : "members"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-4 w-4 object-contain" />
                    <span>
                      {group.plans.length} {group.plans.length === 1 ? "plan" : "plans"}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                {!isMember ? (
                  <Button onClick={handleJoinGroup} disabled={isJoining} className="gap-2">
                    <UserPlus className="h-4 w-4" />
                    {isJoining ? "Joining..." : "Join Group"}
                  </Button>
                ) : (
                  <>
                    {!isOwner && (
                      <Button
                        variant="secondary"
                        onClick={handleLeaveGroup}
                        disabled={isLeaving}
                        className="gap-2"
                      >
                        <UserMinus className="h-4 w-4" />
                        {isLeaving ? "Leaving..." : "Leave Group"}
                      </Button>
                    )}
                    {isAdmin && (
                      <Button
                        variant="secondary"
                        className="gap-2"
                        onClick={handleOpenEditDialog}
                      >
                        <Edit className="h-4 w-4" />
                        Edit Group
                      </Button>
                    )}
                    {isOwner && (
                      <Button
                        variant="destructive"
                        onClick={handleDeleteGroup}
                        disabled={isDeleting}
                        className="gap-2"
                      >
                        <Trash2 className="h-4 w-4" />
                        {isDeleting ? "Deleting..." : "Delete Group"}
                      </Button>
                    )}
                  </>
                )}
              </div>
            </div>
          </CardHeader>
        </Card>
      </motion.div>

      {/* Members */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Members ({group.members.length})
              </CardTitle>
              {isMember && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setInviteDialogOpen(true)}
                  className="gap-2"
                >
                  <Link2 className="h-4 w-4" />
                  Share Invite
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2">
              {group.members.map((member) => {
                const RoleIcon = roleIcons[member.role];
                return (
                  <div
                    key={member._id}
                    className="flex items-center gap-3 p-3 rounded-lg border border-border"
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={member.avatarUrl ?? undefined} />
                      <AvatarFallback>{getInitials(member.name)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">{member.name}</p>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <RoleIcon className="h-3 w-3" />
                        <span>{roleLabels[member.role]}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Shared Plans */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-5 w-5 object-contain" />
                Shared Reading Plans ({group.plans.length})
              </CardTitle>
              {isMember && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setShareDialogOpen(true)}
                  className="gap-2"
                >
                  <Share2 className="h-4 w-4" />
                  Share Plan
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {group.plans.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                No plans shared with this group yet
              </div>
            ) : (
              <div className="space-y-3">
                {group.plans.map((plan) => (
                  <div
                    key={plan._id}
                    className="flex items-start gap-3 p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <Link to={`/plans/${plan._id}`}>
                        <h4 className="font-medium text-foreground hover:text-primary transition-colors">
                          {plan.title}
                        </h4>
                      </Link>
                      {plan.description && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {plan.description}
                        </p>
                      )}
                      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                        <span>Shared by {plan.sharedByName}</span>
                        <Separator orientation="vertical" className="h-3" />
                        <Badge variant="secondary" className="text-xs">
                          {plan.visibility === "public" ? "Public" : "Private"}
                        </Badge>
                      </div>
                    </div>
                    {isMember && !plan.isUserMember && (
                      <Button
                        size="sm"
                        onClick={() => handleJoinPlan(plan._id)}
                        disabled={joiningPlan === plan._id}
                        className="flex-shrink-0"
                      >
                        {joiningPlan === plan._id ? "Joining..." : "Join Plan"}
                      </Button>
                    )}
                    {plan.isUserMember && (
                      <Badge variant="default" className="flex-shrink-0">
                        Joined
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Group Reflections */}
      {isMember && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Group Reflections ({reflections?.length || 0})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!reflections || reflections.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  No reflections shared with this group yet
                </div>
              ) : (
                <div className="space-y-4">
                  {reflections.map((reflection) => (
                    <div
                      key={reflection._id}
                      className="p-4 rounded-lg border border-border space-y-3"
                    >
                      <div className="flex items-start gap-3">
                        <Avatar className="h-8 w-8 flex-shrink-0">
                          <AvatarImage src={reflection.authorAvatar ?? undefined} />
                          <AvatarFallback>{getInitials(reflection.authorName)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-foreground text-sm">
                              {reflection.authorName}
                            </p>
                            <span className="text-xs text-muted-foreground">
                              {new Date(reflection._creationTime).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {reflection.planTitle}
                            {reflection.entryTitle && ` • ${reflection.entryTitle}`}
                          </p>
                        </div>
                      </div>
                      <p className="text-foreground text-sm whitespace-pre-wrap">
                        {reflection.content}
                      </p>
                      <div className="flex items-center gap-4 pt-2 border-t border-border">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="gap-2 h-8"
                          onClick={() => handleToggleLike(reflection._id)}
                          disabled={togglingLike === reflection._id}
                        >
                          <Heart
                            className={`h-4 w-4 ${reflection.isLikedByUser ? "fill-primary text-primary" : ""}`}
                          />
                          <span className="text-xs">{reflection.likeCount}</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="gap-2 h-8">
                          <MessageCircle className="h-4 w-4" />
                          <span className="text-xs">{reflection.commentCount}</span>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Group Chat */}
      {isMember && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-primary" />
                Group Chat
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[400px] px-6">
                {!messages || messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No messages yet. Start the conversation!
                  </div>
                ) : (
                  <div className="space-y-4 py-4">
                    {messages.map((message) => (
                      <div key={message._id} className="flex gap-3">
                        <Avatar className="h-8 w-8 flex-shrink-0">
                          <AvatarImage src={message.authorAvatar ?? undefined} />
                          <AvatarFallback>{getInitials(message.authorName)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-foreground text-sm">
                              {message.authorName}
                            </p>
                            <span className="text-xs text-muted-foreground">
                              {new Date(message._creationTime).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                          <p className="text-sm text-foreground mt-1 whitespace-pre-wrap">
                            {message.content}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>
              <div className="p-4 border-t border-border">
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Type a message..."
                    value={messageContent}
                    onChange={(e) => setMessageContent(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    rows={2}
                    className="resize-none"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={isSending || !messageContent.trim()}
                    size="icon"
                    className="h-auto"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Edit Group Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Group</DialogTitle>
            <DialogDescription>
              Update your group details
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Group Name</Label>
              <Input
                id="edit-name"
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                placeholder="Enter group name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                placeholder="Enter group description"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-visibility">Visibility</Label>
              <Select
                value={editForm.visibility}
                onValueChange={(value) =>
                  setEditForm({ ...editForm, visibility: value as typeof editForm.visibility })
                }
              >
                <SelectTrigger id="edit-visibility">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="public">Public</SelectItem>
                  <SelectItem value="private">Private</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2 justify-end pt-4">
              <Button
                variant="outline"
                onClick={() => setEditDialogOpen(false)}
                disabled={isUpdating}
              >
                Cancel
              </Button>
              <Button onClick={handleUpdateGroup} disabled={isUpdating}>
                {isUpdating ? "Updating..." : "Update Group"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Plan Dialog */}
      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Share Reading Plan</DialogTitle>
            <DialogDescription>
              Select a reading plan to share with this group
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {!myPlans || myPlans.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>You don't have any reading plans yet.</p>
                <Link to="/plans/create">
                  <Button className="mt-4" size="sm">
                    Create a Plan
                  </Button>
                </Link>
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Label>Select a plan</Label>
                  <Select
                    value={selectedPlanId || ""}
                    onValueChange={(value) => setSelectedPlanId(value as Id<"readingPlans">)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a reading plan..." />
                    </SelectTrigger>
                    <SelectContent>
                      {myPlans.map((plan) => (
                        <SelectItem key={plan._id} value={plan._id}>
                          {plan.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2 justify-end pt-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShareDialogOpen(false);
                      setSelectedPlanId(null);
                    }}
                    disabled={isSharing}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSharePlan}
                    disabled={isSharing || !selectedPlanId}
                  >
                    {isSharing ? "Sharing..." : "Share Plan"}
                  </Button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Invite Link Dialog */}
      <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{landingContent?.inviteDialogTitle || "Invite People to Group"}</DialogTitle>
            <DialogDescription>
              {landingContent?.inviteDialogDescription || "Share this link with anyone you want to invite to"} {group.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Invite Link</Label>
              <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-muted/50">
                <a
                  href={`${window.location.origin}/groups/${groupId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 text-primary hover:underline font-medium truncate"
                >
                  {group.name}
                </a>
                <Button
                  size="icon"
                  variant="secondary"
                  onClick={handleCopyInviteLink}
                  className="flex-shrink-0"
                  title="Copy link"
                >
                  {inviteCopied ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
                <Button
                  size="icon"
                  variant="secondary"
                  onClick={handleEmailInvite}
                  className="flex-shrink-0"
                  title="Send via email"
                >
                  <Mail className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                {landingContent?.inviteDialogHelpText || "Anyone with this link can view and join this group"}
                {group.visibility === "private" && " (even though it's private)"}
              </p>
            </div>
            <div className="flex justify-end pt-4">
              <Button onClick={() => setInviteDialogOpen(false)}>
                Done
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function GroupDetail() {
  return (
    <AppLayout>
      <GroupDetailContent />
    </AppLayout>
  );
}
