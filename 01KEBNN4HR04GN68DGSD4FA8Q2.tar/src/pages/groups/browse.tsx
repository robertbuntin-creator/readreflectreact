import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import { ArrowLeft, Users, Search } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
} from "@/components/ui/empty.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { useState } from "react";

function BrowseGroupsContent() {
  const groups = useQuery(api.groups.getPublicGroups);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredGroups = groups?.filter((group) =>
    group.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (groups === undefined) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-pulse text-muted-foreground">Loading groups...</div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to="/groups">
          <Button variant="ghost" size="sm" className="gap-2 mb-4">
            <ArrowLeft className="h-4 w-4" />
            Back to My Groups
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            Browse Public Groups
          </h1>
          <p className="text-muted-foreground mt-1">
            Discover and join reading communities
          </p>
        </div>
      </motion.div>

      {/* Search */}
      {groups.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search public groups..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
        </motion.div>
      )}

      {/* Groups Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {filteredGroups && filteredGroups.length === 0 && searchQuery && (
          <div className="text-center py-12 text-muted-foreground">
            No groups found matching "{searchQuery}"
          </div>
        )}

        {filteredGroups && filteredGroups.length === 0 && !searchQuery && (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Users />
              </EmptyMedia>
              <EmptyTitle>No public groups yet</EmptyTitle>
              <EmptyDescription>
                Be the first to create a public group and build a community
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        )}

        {filteredGroups && filteredGroups.length > 0 && (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredGroups.map((group) => (
              <Link key={group._id} to={`/groups/${group._id}`}>
                <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-semibold text-lg text-foreground line-clamp-2 flex-1">
                        {group.name}
                      </h3>
                      {group.isMember && (
                        <Badge variant="default" className="flex-shrink-0">
                          Joined
                        </Badge>
                      )}
                    </div>
                    {group.description && (
                      <p className="text-sm text-muted-foreground mt-2 line-clamp-3">
                        {group.description}
                      </p>
                    )}
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        <span>
                          {group.memberCount} {group.memberCount === 1 ? "member" : "members"}
                        </span>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mt-2">
                      Created by {group.ownerName}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
}

export default function BrowseGroups() {
  return (
    <AppLayout>
      <BrowseGroupsContent />
    </AppLayout>
  );
}
