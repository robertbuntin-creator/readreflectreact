import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import { Plus, Users, Search, Crown, Shield, UserCircle } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { useState } from "react";

const roleIcons = {
  owner: Crown,
  admin: Shield,
  member: UserCircle,
};

const roleLabels = {
  owner: "Owner",
  admin: "Admin",
  member: "Member",
};

function MyGroupsContent() {
  const groups = useQuery(api.groups.getMyGroups);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredGroups = groups?.filter((group) =>
    group.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (groups === undefined) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-pulse text-muted-foreground">Loading groups...</div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">My Groups</h1>
          <p className="text-muted-foreground mt-1">
            Connect with others and share reading plans
          </p>
        </div>
        <div className="flex gap-2">
          <Link to="/groups/browse">
            <Button variant="secondary" className="gap-2">
              <Search className="h-4 w-4" />
              Browse Groups
            </Button>
          </Link>
          <Link to="/groups/create">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Create Group
            </Button>
          </Link>
        </div>
      </motion.div>

      {/* Search */}
      {groups.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search your groups..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
        </motion.div>
      )}

      {/* Groups List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {filteredGroups && filteredGroups.length === 0 && searchQuery && (
          <div className="text-center py-12 text-muted-foreground">
            No groups found matching "{searchQuery}"
          </div>
        )}

        {filteredGroups && filteredGroups.length === 0 && !searchQuery && (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Users />
              </EmptyMedia>
              <EmptyTitle>No groups yet</EmptyTitle>
              <EmptyDescription>
                Create a group or browse public groups to get started
              </EmptyDescription>
            </EmptyHeader>
            <EmptyContent>
              <div className="flex gap-2">
                <Link to="/groups/browse">
                  <Button variant="secondary" size="sm">
                    Browse Groups
                  </Button>
                </Link>
                <Link to="/groups/create">
                  <Button size="sm">Create Group</Button>
                </Link>
              </div>
            </EmptyContent>
          </Empty>
        )}

        {filteredGroups && filteredGroups.length > 0 && (
          <div className="grid gap-4 md:grid-cols-2">
            {filteredGroups.map((group) => {
              const RoleIcon = roleIcons[group.role];
              return (
                <Link key={group._id} to={`/groups/${group._id}`}>
                  <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-lg text-foreground truncate">
                            {group.name}
                          </h3>
                          {group.description && (
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                              {group.description}
                            </p>
                          )}
                        </div>
                        <Badge
                          variant={group.role === "owner" ? "default" : "secondary"}
                          className="flex-shrink-0"
                        >
                          <RoleIcon className="h-3 w-3 mr-1" />
                          {roleLabels[group.role]}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Users className="h-4 w-4" />
                          <span>
                            {group.memberCount} {group.memberCount === 1 ? "member" : "members"}
                          </span>
                        </div>
                        <Badge variant={group.visibility === "public" ? "default" : "secondary"}>
                          {group.visibility === "public" ? "Public" : "Private"}
                        </Badge>
                      </div>
                      <div className="text-xs text-muted-foreground mt-2">
                        Created by {group.ownerName}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </motion.div>
    </div>
  );
}

export default function MyGroups() {
  return (
    <AppLayout>
      <MyGroupsContent />
    </AppLayout>
  );
}
