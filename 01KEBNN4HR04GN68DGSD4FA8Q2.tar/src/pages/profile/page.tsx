import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { motion } from "motion/react";
import {
  Camera,
  Edit2,
  Save,
  X,
  Target,
  Heart,
  Mail,
  Palette,
  Crop as CropIcon,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog.tsx";
import { Slider } from "@/components/ui/slider.tsx";
import AppLayout from "@/components/layout/app-layout.tsx";
import { toast } from "sonner";
import ReactCrop, { type Crop } from "react-image-crop";
import "react-image-crop/dist/ReactCrop.css";

const colorProfiles = [
  {
    id: "mocha-mousse",
    name: "Mocha Mousse",
    description: "Rich brown tones with coffee-inspired warmth",
    primary: "#8B4513",
    secondary: "#D2691E",
    accent: "#F5DEB3",
  },
  {
    id: "sky-stream",
    name: "Sky Stream",
    description: "Classic blue with clean minimal interface",
    primary: "#1E90FF",
    secondary: "#87CEEB",
    accent: "#B0E0E6",
  },
  {
    id: "nature",
    name: "Nature",
    description: "Organic greens and browns from nature",
    primary: "#228B22",
    secondary: "#8FBC8F",
    accent: "#F0E68C",
  },
  {
    id: "catppuccin",
    name: "Catppuccin",
    description: "Pastel terminal theme with soothing tones",
    primary: "#CBA6F7",
    secondary: "#F5C2E7",
    accent: "#FAB387",
  },
  {
    id: "sunset-horizon",
    name: "Sunset Horizon",
    description: "Golden hour warmth meets sunset oranges",
    primary: "#FF6347",
    secondary: "#FFD700",
    accent: "#FFA07A",
  },
  {
    id: "ocean-breeze",
    name: "Ocean Breeze",
    description: "Cool ocean blues with aqua",
    primary: "#20B2AA",
    secondary: "#00CED1",
    accent: "#AFEEEE",
  },
];

const genres = [
  "Fiction",
  "Non-Fiction",
  "Spirituality",
  "Self-Help",
  "Biography",
  "History",
  "Science",
  "Philosophy",
  "Poetry",
  "Business",
  "Psychology",
  "Technology",
];

function ProfileContent() {
  const currentUser = useQuery(api.users.getCurrentUser);
  const updateProfile = useMutation(api.users.updateProfile);
  const generateUploadUrl = useMutation(api.users.generateUploadUrl);
  const updateAvatar = useMutation(api.users.updateAvatar);
  const updateColorProfile = useMutation(api.users.updateColorProfile);

  const [isEditing, setIsEditing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedColorProfile, setSelectedColorProfile] = useState<string | null>(null);
  const [showCropDialog, setShowCropDialog] = useState(false);
  const [imageToCrop, setImageToCrop] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [crop, setCrop] = useState<Crop>({
    unit: "%",
    width: 90,
    height: 90,
    x: 5,
    y: 5,
  });
  const [completedCrop, setCompletedCrop] = useState<Crop | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    bio: "",
    readingGoal: "",
    favoriteGenres: [] as string[],
  });

  // Set initial color profile from user data
  useEffect(() => {
    if (currentUser?.colorProfile && !selectedColorProfile) {
      setSelectedColorProfile(currentUser.colorProfile);
    }
  }, [currentUser, selectedColorProfile]);

  const startEditing = () => {
    setFormData({
      name: currentUser?.name || "",
      bio: currentUser?.bio || "",
      readingGoal: currentUser?.readingGoal || "",
      favoriteGenres: currentUser?.favoriteGenres || [],
    });
    setIsEditing(true);
  };

  const cancelEditing = () => {
    setIsEditing(false);
  };

  const toggleGenre = (genre: string) => {
    setFormData((prev) => ({
      ...prev,
      favoriteGenres: prev.favoriteGenres.includes(genre)
        ? prev.favoriteGenres.filter((g) => g !== genre)
        : [...prev.favoriteGenres, genre],
    }));
  };

  const handleSave = async () => {
    if (!formData.name.trim()) {
      toast.error("Name is required");
      return;
    }

    setIsSaving(true);
    try {
      await updateProfile({
        name: formData.name,
        bio: formData.bio || undefined,
        readingGoal: formData.readingGoal || undefined,
        favoriteGenres:
          formData.favoriteGenres.length > 0 ? formData.favoriteGenres : undefined,
      });
      toast.success("Profile updated successfully");
      setIsEditing(false);
    } catch {
      toast.error("Failed to update profile");
    } finally {
      setIsSaving(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be less than 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setImageToCrop(reader.result as string);
      setZoom(1); // Reset zoom when new image is loaded
      setShowCropDialog(true);
    };
    reader.readAsDataURL(file);

    // Reset file input
    e.target.value = "";
  };

  const getCroppedImg = async (): Promise<Blob | null> => {
    if (!imageRef.current || !completedCrop) return null;

    const image = imageRef.current;
    const canvas = document.createElement("canvas");
    
    // Account for zoom when calculating crop dimensions
    const scaleX = (image.naturalWidth / image.width) / zoom;
    const scaleY = (image.naturalHeight / image.height) / zoom;
    const ctx = canvas.getContext("2d");

    if (!ctx) return null;

    const pixelRatio = window.devicePixelRatio;
    canvas.width = completedCrop.width * scaleX * pixelRatio;
    canvas.height = completedCrop.height * scaleY * pixelRatio;

    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    ctx.imageSmoothingQuality = "high";

    ctx.drawImage(
      image,
      completedCrop.x * scaleX,
      completedCrop.y * scaleY,
      completedCrop.width * scaleX,
      completedCrop.height * scaleY,
      0,
      0,
      completedCrop.width * scaleX,
      completedCrop.height * scaleY
    );

    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        resolve(blob);
      }, "image/jpeg", 0.9);
    });
  };

  const handleCropComplete = async () => {
    if (!completedCrop || !imageRef.current) {
      toast.error("Please select a crop area");
      return;
    }

    setIsUploading(true);
    try {
      const croppedBlob = await getCroppedImg();
      if (!croppedBlob) {
        throw new Error("Failed to crop image");
      }

      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": "image/jpeg" },
        body: croppedBlob,
      });
      const { storageId } = await result.json();
      await updateAvatar({ storageId });
      toast.success("Profile picture updated");
      setShowCropDialog(false);
      setImageToCrop(null);
    } catch {
      toast.error("Failed to upload image");
    } finally {
      setIsUploading(false);
    }
  };

  const handleColorProfileChange = async (profileId: string) => {
    try {
      await updateColorProfile({ colorProfile: profileId });
      setSelectedColorProfile(profileId);
      toast.success("Color profile updated! Refresh to see changes.");
    } catch {
      toast.error("Failed to update color profile");
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (!currentUser) {
    return null;
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center justify-between"
      >
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
          My Profile
        </h1>
        {!isEditing ? (
          <Button onClick={startEditing} className="gap-2">
            <Edit2 className="h-4 w-4" />
            Edit Profile
          </Button>
        ) : (
          <div className="flex gap-2">
            <Button variant="ghost" onClick={cancelEditing}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isSaving}>
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? "Saving..." : "Save"}
            </Button>
          </div>
        )}
      </motion.div>

      {/* Profile Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-6 items-start">
              {/* Avatar */}
              <div className="relative group">
                <Avatar className="h-24 w-24 sm:h-32 sm:w-32 border-4 border-background shadow-lg">
                  <AvatarImage src={currentUser.avatarUrl ?? undefined} />
                  <AvatarFallback className="text-2xl sm:text-3xl">
                    {getInitials(currentUser.name)}
                  </AvatarFallback>
                </Avatar>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Camera className="h-6 w-6 text-white" />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileSelect}
                />
                {isUploading && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full">
                    <div className="animate-spin h-6 w-6 border-2 border-white border-t-transparent rounded-full" />
                  </div>
                )}
              </div>

              {/* Basic Info */}
              <div className="flex-1 space-y-4 w-full">
                {isEditing ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="name">Display Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, name: e.target.value }))
                        }
                        placeholder="Your name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        value={formData.bio}
                        onChange={(e) =>
                          setFormData((prev) => ({ ...prev, bio: e.target.value }))
                        }
                        placeholder="Tell others about yourself..."
                        rows={3}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <h2 className="text-2xl font-bold text-foreground">
                        {currentUser.name || "Anonymous Reader"}
                      </h2>
                      {currentUser.email && (
                        <p className="text-muted-foreground flex items-center gap-2 mt-1">
                          <Mail className="h-4 w-4" />
                          {currentUser.email}
                        </p>
                      )}
                    </div>
                    {currentUser.bio && (
                      <p className="text-foreground">{currentUser.bio}</p>
                    )}
                    {!currentUser.bio && (
                      <p className="text-muted-foreground italic">No bio added yet</p>
                    )}
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Reading Goal */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              Reading Goal
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <div className="space-y-2">
                <Input
                  value={formData.readingGoal}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      readingGoal: e.target.value,
                    }))
                  }
                  placeholder="What's your reading goal?"
                />
              </div>
            ) : currentUser.readingGoal ? (
              <p className="text-foreground">{currentUser.readingGoal}</p>
            ) : (
              <p className="text-muted-foreground italic">No reading goal set</p>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Favorite Genres */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-primary" />
              Favorite Genres
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <div className="flex flex-wrap gap-2">
                {genres.map((genre) => (
                  <button
                    key={genre}
                    onClick={() => toggleGenre(genre)}
                    className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                      formData.favoriteGenres.includes(genre)
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    }`}
                  >
                    {genre}
                  </button>
                ))}
              </div>
            ) : currentUser.favoriteGenres && currentUser.favoriteGenres.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {currentUser.favoriteGenres.map((genre) => (
                  <Badge key={genre} variant="secondary">
                    {genre}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground italic">No favorite genres selected</p>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Account Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" />
              Color Profile
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Choose a color theme that reflects your style. The theme will be applied across your entire experience.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {colorProfiles.map((profile) => (
                  <button
                    key={profile.id}
                    onClick={() => handleColorProfileChange(profile.id)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedColorProfile === profile.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex gap-1 mt-1">
                        <div
                          className="w-4 h-4 rounded-full border border-border"
                          style={{ backgroundColor: profile.primary }}
                        />
                        <div
                          className="w-4 h-4 rounded-full border border-border"
                          style={{ backgroundColor: profile.secondary }}
                        />
                        <div
                          className="w-4 h-4 rounded-full border border-border"
                          style={{ backgroundColor: profile.accent }}
                        />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-foreground mb-1">
                          {profile.name}
                        </h4>
                        <p className="text-xs text-muted-foreground">
                          {profile.description}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Account Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <img src="https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk" alt="Read Reflect React" className="h-5 w-5 object-contain" />
              Account
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-muted-foreground">Role</span>
              <Badge variant={currentUser.role === "admin" ? "default" : "secondary"}>
                {currentUser.role === "admin" ? "Admin" : "Member"}
              </Badge>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-muted-foreground">Member since</span>
              <span className="text-foreground">
                {new Date(currentUser._creationTime).toLocaleDateString()}
              </span>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Image Crop Dialog */}
      <Dialog open={showCropDialog} onOpenChange={setShowCropDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CropIcon className="h-5 w-5" />
              Adjust Profile Picture
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {/* Zoom Controls */}
            <div className="space-y-2 px-1">
              <Label className="text-sm font-medium flex items-center justify-between">
                <span>Zoom</span>
                <span className="text-muted-foreground font-normal">{Math.round(zoom * 100)}%</span>
              </Label>
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 flex-shrink-0"
                  onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
                  disabled={zoom <= 0.5}
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Slider
                  value={[zoom]}
                  onValueChange={(value) => setZoom(value[0])}
                  min={0.5}
                  max={3}
                  step={0.1}
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 flex-shrink-0"
                  onClick={() => setZoom(Math.min(3, zoom + 0.1))}
                  disabled={zoom >= 3}
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Crop Area */}
            {imageToCrop && (
              <div className="flex items-center justify-center overflow-auto max-h-[50vh] bg-muted/20 rounded-lg">
                <ReactCrop
                  crop={crop}
                  onChange={(c) => setCrop(c)}
                  onComplete={(c) => setCompletedCrop(c)}
                  aspect={1}
                  circularCrop
                >
                  <img
                    ref={imageRef}
                    src={imageToCrop}
                    alt="Crop preview"
                    style={{
                      transform: `scale(${zoom})`,
                      transformOrigin: "center",
                    }}
                    className="max-w-full h-auto"
                  />
                </ReactCrop>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => {
                setShowCropDialog(false);
                setImageToCrop(null);
                setZoom(1);
              }}
              disabled={isUploading}
            >
              Cancel
            </Button>
            <Button onClick={handleCropComplete} disabled={isUploading}>
              {isUploading ? "Uploading..." : "Save Profile Picture"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function Profile() {
  return (
    <AppLayout>
      <ProfileContent />
    </AppLayout>
  );
}
