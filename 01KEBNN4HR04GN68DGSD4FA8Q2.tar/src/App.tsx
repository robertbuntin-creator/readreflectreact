import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import AuthCallback from "./pages/auth/Callback.tsx";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import Dashboard from "./pages/dashboard/page.tsx";
import Onboarding from "./pages/onboarding/page.tsx";
import Profile from "./pages/profile/page.tsx";
import MyPlans from "./pages/plans/page.tsx";
import BrowsePlans from "./pages/plans/browse.tsx";
import StartReadingPlan from "./pages/plans/start.tsx";
import CreatePlan from "./pages/plans/create.tsx";
import PlanDetail from "./pages/plans/detail.tsx";
import MyGroups from "./pages/groups/page.tsx";
import BrowseGroups from "./pages/groups/browse.tsx";
import CreateGroup from "./pages/groups/create.tsx";
import GroupDetail from "./pages/groups/detail.tsx";
import Reflections from "./pages/reflections/page.tsx";
import Feedback from "./pages/feedback/page.tsx";
import Admin from "./pages/admin/page.tsx";

export default function App() {
  return (
    <DefaultProviders>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/plans" element={<MyPlans />} />
          <Route path="/plans/browse" element={<BrowsePlans />} />
          <Route path="/plans/start" element={<StartReadingPlan />} />
          <Route path="/plans/create" element={<CreatePlan />} />
          <Route path="/plans/:planId" element={<PlanDetail />} />
          <Route path="/groups" element={<MyGroups />} />
          <Route path="/groups/browse" element={<BrowseGroups />} />
          <Route path="/groups/create" element={<CreateGroup />} />
          <Route path="/groups/:groupId" element={<GroupDetail />} />
          <Route path="/reflections" element={<Reflections />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/admin" element={<Admin />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </DefaultProviders>
  );
}
