import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    avatarStorageId: v.optional(v.id("_storage")),
    bio: v.optional(v.string()),
    readingGoal: v.optional(v.string()),
    favoriteGenres: v.optional(v.array(v.string())),
    isOnboarded: v.optional(v.boolean()),
    role: v.optional(v.union(v.literal("user"), v.literal("admin"))),
    colorProfile: v.optional(v.string()),
  }).index("by_token", ["tokenIdentifier"]),

  readingPlans: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    ownerId: v.id("users"),
    status: v.union(
      v.literal("draft"),
      v.literal("pending_approval"),
      v.literal("published"),
      v.literal("archived")
    ),
    visibility: v.union(v.literal("public"), v.literal("private")),
    scheduleType: v.union(
      v.literal("daily"),
      v.literal("weekly"),
      v.literal("custom")
    ),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    color: v.optional(v.string()),
    labels: v.optional(v.array(v.string())),
    reminderEnabled: v.optional(v.boolean()),
    reflectionPrompts: v.optional(v.array(v.string())),
    customWeeklySchedule: v.optional(
      v.array(
        v.object({
          day: v.union(
            v.literal("monday"),
            v.literal("tuesday"),
            v.literal("wednesday"),
            v.literal("thursday"),
            v.literal("friday"),
            v.literal("saturday"),
            v.literal("sunday")
          ),
          type: v.union(
            v.literal("reading"),
            v.literal("meeting"),
            v.literal("sabbath")
          ),
        })
      )
    ),
    resourceMaterials: v.optional(
      v.array(
        v.object({
          title: v.string(),
          url: v.string(),
        })
      )
    ),
  })
    .index("by_owner", ["ownerId"])
    .index("by_status", ["status"]),

  planEntries: defineTable({
    planId: v.id("readingPlans"),
    title: v.string(),
    description: v.optional(v.string()),
    content: v.optional(v.string()),
    order: v.number(),
    scheduledDate: v.optional(v.string()),
    externalLinks: v.optional(v.array(v.string())),
    bibleReferences: v.optional(v.array(v.string())),
    reflectionPrompts: v.optional(v.array(v.string())),
  }).index("by_plan", ["planId"]),

  planMembers: defineTable({
    userId: v.id("users"),
    planId: v.id("readingPlans"),
    progress: v.number(), // percentage 0-100
    currentEntryOrder: v.optional(v.number()),
    completedEntries: v.optional(v.array(v.number())),
  })
    .index("by_user", ["userId"])
    .index("by_plan", ["planId"])
    .index("by_user_and_plan", ["userId", "planId"]),

  groups: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    ownerId: v.id("users"),
    visibility: v.union(v.literal("public"), v.literal("private")),
    coverImageStorageId: v.optional(v.id("_storage")),
    memberCount: v.number(),
  }).index("by_owner", ["ownerId"]),

  groupMembers: defineTable({
    groupId: v.id("groups"),
    userId: v.id("users"),
    role: v.union(v.literal("owner"), v.literal("admin"), v.literal("member")),
  })
    .index("by_group", ["groupId"])
    .index("by_user", ["userId"])
    .index("by_group_and_user", ["groupId", "userId"]),

  groupPlans: defineTable({
    groupId: v.id("groups"),
    planId: v.id("readingPlans"),
    sharedById: v.id("users"),
  })
    .index("by_group", ["groupId"])
    .index("by_plan", ["planId"])
    .index("by_group_and_plan", ["groupId", "planId"]),

  reflections: defineTable({
    userId: v.id("users"),
    planId: v.id("readingPlans"),
    entryId: v.optional(v.id("planEntries")),
    content: v.string(),
    visibility: v.union(v.literal("public"), v.literal("private"), v.literal("group")),
    groupId: v.optional(v.id("groups")),
    likeCount: v.number(),
    commentCount: v.number(),
    questionIndex: v.optional(v.number()),
    questionText: v.optional(v.string()),
    isArchived: v.optional(v.boolean()),
    archivedAt: v.optional(v.number()),
  })
    .index("by_user", ["userId"])
    .index("by_plan", ["planId"])
    .index("by_entry", ["entryId"])
    .index("by_group", ["groupId"])
    .index("by_user_and_archived", ["userId", "isArchived"]),

  reflectionLikes: defineTable({
    reflectionId: v.id("reflections"),
    userId: v.id("users"),
  })
    .index("by_reflection", ["reflectionId"])
    .index("by_user", ["userId"])
    .index("by_reflection_and_user", ["reflectionId", "userId"]),

  reflectionComments: defineTable({
    reflectionId: v.id("reflections"),
    userId: v.id("users"),
    content: v.string(),
  })
    .index("by_reflection", ["reflectionId"])
    .index("by_user", ["userId"]),

  groupMessages: defineTable({
    groupId: v.id("groups"),
    userId: v.id("users"),
    content: v.string(),
  })
    .index("by_group", ["groupId"])
    .index("by_user", ["userId"]),

  mediaFiles: defineTable({
    storageId: v.id("_storage"),
    filename: v.string(),
    fileType: v.string(), // image/png, image/jpeg, etc
    fileSize: v.number(), // in bytes
    category: v.union(
      v.literal("icon"),
      v.literal("background"),
      v.literal("image"),
      v.literal("other")
    ),
    uploadedById: v.id("users"),
    description: v.optional(v.string()),
  })
    .index("by_category", ["category"])
    .index("by_uploader", ["uploadedById"]),

  landingPageContent: defineTable({
    // Landing Page
    heroTitle: v.string(),
    heroSubtitle: v.string(),
    heroDescription: v.string(),
    featuresTitle: v.string(),
    featuresDescription: v.string(),
    howItWorksTitle: v.string(),
    howItWorksDescription: v.string(),
    missionTitle: v.string(),
    missionParagraph1: v.string(),
    missionParagraph2: v.string(),
    ctaTitle: v.string(),
    ctaDescription: v.string(),
    logoUrl: v.optional(v.string()),
    heroImageUrl: v.optional(v.string()),
    missionImageUrl: v.optional(v.string()),
    inviteDialogTitle: v.optional(v.string()),
    inviteDialogDescription: v.optional(v.string()),
    inviteDialogHelpText: v.optional(v.string()),
    // Dashboard
    dashboardWelcome: v.optional(v.string()),
    dashboardSubtitle: v.optional(v.string()),
    // My Plans
    myPlansTitle: v.optional(v.string()),
    myPlansEmptyTitle: v.optional(v.string()),
    myPlansEmptyDescription: v.optional(v.string()),
    myPlansCreateButton: v.optional(v.string()),
    myPlansBrowseButton: v.optional(v.string()),
    // Browse Plans
    browsePlansTitle: v.optional(v.string()),
    browsePlansDescription: v.optional(v.string()),
    // Start Reading Plan
    startPlanTitle: v.optional(v.string()),
    startPlanDescription: v.optional(v.string()),
    startPlanBrowseTitle: v.optional(v.string()),
    startPlanBrowseDescription: v.optional(v.string()),
    startPlanBrowseBullet1: v.optional(v.string()),
    startPlanBrowseBullet2: v.optional(v.string()),
    startPlanBrowseBullet3: v.optional(v.string()),
    startPlanBrowseButton: v.optional(v.string()),
    startPlanCreateTitle: v.optional(v.string()),
    startPlanCreateDescription: v.optional(v.string()),
    startPlanCreateBullet1: v.optional(v.string()),
    startPlanCreateBullet2: v.optional(v.string()),
    startPlanCreateBullet3: v.optional(v.string()),
    startPlanCreateButton: v.optional(v.string()),
    startPlanTipTitle: v.optional(v.string()),
    startPlanTipDescription: v.optional(v.string()),
    // Create Plan
    createPlanTitle: v.optional(v.string()),
    createPlanDescription: v.optional(v.string()),
    // Groups
    myGroupsTitle: v.optional(v.string()),
    myGroupsEmptyTitle: v.optional(v.string()),
    myGroupsEmptyDescription: v.optional(v.string()),
    // Browse Groups
    browseGroupsTitle: v.optional(v.string()),
    browseGroupsDescription: v.optional(v.string()),
    // Profile
    profileTitle: v.optional(v.string()),
    profileDescription: v.optional(v.string()),
    // Reflections
    reflectionsTitle: v.optional(v.string()),
    reflectionsEmptyTitle: v.optional(v.string()),
    reflectionsEmptyDescription: v.optional(v.string()),
    // Feedback
    feedbackTitle: v.optional(v.string()),
    feedbackDescription: v.optional(v.string()),
  }),

  feedback: defineTable({
    userId: v.id("users"),
    type: v.union(v.literal("bug"), v.literal("feature"), v.literal("feedback")),
    title: v.string(),
    description: v.string(),
    status: v.union(
      v.literal("new"),
      v.literal("in_progress"),
      v.literal("resolved"),
      v.literal("closed")
    ),
    priority: v.optional(
      v.union(v.literal("low"), v.literal("medium"), v.literal("high"))
    ),
  })
    .index("by_user", ["userId"])
    .index("by_status", ["status"])
    .index("by_type", ["type"]),
});
