import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel.d.ts";
import { ConvexError } from "convex/values";

// Send a message to a group
export const send = mutation({
  args: {
    groupId: v.id("groups"),
    content: v.string(),
  },
  handler: async (ctx, args): Promise<Id<"groupMessages">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    // Check if user is a member of the group
    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", user._id)
      )
      .unique();

    if (!membership) {
      throw new ConvexError({
        message: "Must be a group member to send messages",
        code: "FORBIDDEN",
      });
    }

    const messageId = await ctx.db.insert("groupMessages", {
      groupId: args.groupId,
      userId: user._id,
      content: args.content,
    });

    return messageId;
  },
});

// Delete a message
export const deleteMessage = mutation({
  args: { messageId: v.id("groupMessages") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const message = await ctx.db.get(args.messageId);
    if (!message) {
      throw new ConvexError({
        message: "Message not found",
        code: "NOT_FOUND",
      });
    }

    // Check if user is the author or group admin
    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", message.groupId).eq("userId", user._id)
      )
      .unique();

    if (
      !membership ||
      (message.userId !== user._id &&
        membership.role !== "owner" &&
        membership.role !== "admin")
    ) {
      throw new ConvexError({
        message: "Only the author or group admins can delete messages",
        code: "FORBIDDEN",
      });
    }

    await ctx.db.delete(args.messageId);
  },
});

// Get messages for a group
export const getGroupMessages = query({
  args: { groupId: v.id("groups") },
  handler: async (
    ctx,
    args
  ): Promise<
    Array<
      Doc<"groupMessages"> & {
        authorName: string;
        authorAvatar: string | null;
        isAuthor: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    // Check if user is a member
    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", user._id)
      )
      .unique();

    if (!membership) {
      return [];
    }

    const messages = await ctx.db
      .query("groupMessages")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .order("asc")
      .collect();

    return await Promise.all(
      messages.map(async (message) => {
        const author = await ctx.db.get(message.userId);
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        return {
          ...message,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          isAuthor: message.userId === user._id,
        };
      })
    );
  },
});

// Get recent messages from all of user's groups for dashboard
export const getAllGroupChats = query({
  args: {},
  handler: async (
    ctx
  ): Promise<Array<{
    groupId: Id<"groups">;
    groupName: string;
    messages: Array<
      Doc<"groupMessages"> & {
        authorName: string;
        authorAvatar: string | null;
        isAuthor: boolean;
      }
    >;
  }>> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    // Get user's groups
    const memberships = await ctx.db
      .query("groupMembers")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    if (memberships.length === 0) {
      return [];
    }

    // Get messages for each group
    const groupChats = await Promise.all(
      memberships.map(async (membership) => {
        const group = await ctx.db.get(membership.groupId);
        if (!group) return null;

        // Get recent messages from this group
        const messages = await ctx.db
          .query("groupMessages")
          .withIndex("by_group", (q) => q.eq("groupId", membership.groupId))
          .order("desc")
          .take(10);

        const messagesWithAuthors = await Promise.all(
          messages.map(async (message) => {
            const author = await ctx.db.get(message.userId);
            const authorAvatar = author?.avatarStorageId
              ? await ctx.storage.getUrl(author.avatarStorageId)
              : null;

            return {
              ...message,
              authorName: author?.name || "Anonymous",
              authorAvatar,
              isAuthor: message.userId === user._id,
            };
          })
        );

        return {
          groupId: group._id,
          groupName: group.name,
          messages: messagesWithAuthors.reverse(),
        };
      })
    );

    // Filter out null values and return
    return groupChats.filter((chat) => chat !== null) as Array<{
      groupId: Id<"groups">;
      groupName: string;
      messages: Array<
        Doc<"groupMessages"> & {
          authorName: string;
          authorAvatar: string | null;
          isAuthor: boolean;
        }
      >;
    }>;
  },
});
