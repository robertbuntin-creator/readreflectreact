import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";
import { ConvexError } from "convex/values";

// Submit new feedback
export const submitFeedback = mutation({
  args: {
    type: v.union(v.literal("bug"), v.literal("feature"), v.literal("feedback")),
    title: v.string(),
    description: v.string(),
  },
  handler: async (ctx, args): Promise<Id<"feedback">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "You must be logged in to submit feedback",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const feedbackId = await ctx.db.insert("feedback", {
      userId: user._id,
      type: args.type,
      title: args.title,
      description: args.description,
      status: "new",
    });

    return feedbackId;
  },
});

// Get user's own feedback
export const getMyFeedback = query({
  args: {},
  handler: async (ctx): Promise<{
    _id: Id<"feedback">;
    _creationTime: number;
    type: "bug" | "feature" | "feedback";
    title: string;
    description: string;
    status: "new" | "in_progress" | "resolved" | "closed";
    priority?: "low" | "medium" | "high";
  }[]> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      return [];
    }

    const feedback = await ctx.db
      .query("feedback")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .collect();

    return feedback.map((f) => ({
      _id: f._id,
      _creationTime: f._creationTime,
      type: f.type,
      title: f.title,
      description: f.description,
      status: f.status,
      priority: f.priority,
    }));
  },
});
