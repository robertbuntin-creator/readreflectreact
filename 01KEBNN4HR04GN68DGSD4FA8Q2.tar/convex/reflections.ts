import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel.d.ts";
import { ConvexError } from "convex/values";

// Create a reflection
export const create = mutation({
  args: {
    planId: v.id("readingPlans"),
    entryId: v.optional(v.id("planEntries")),
    content: v.string(),
    visibility: v.union(v.literal("public"), v.literal("private"), v.literal("group")),
    groupId: v.optional(v.id("groups")),
    questionIndex: v.optional(v.number()),
    questionText: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"reflections">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    // Validate plan exists
    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        message: "Plan not found",
        code: "NOT_FOUND",
      });
    }

    // Validate entry exists if provided
    if (args.entryId) {
      const entry = await ctx.db.get(args.entryId);
      if (!entry) {
        throw new ConvexError({
          message: "Entry not found",
          code: "NOT_FOUND",
        });
      }
    }

    // Validate group if visibility is group
    if (args.visibility === "group" && args.groupId) {
      const group = await ctx.db.get(args.groupId);
      if (!group) {
        throw new ConvexError({
          message: "Group not found",
          code: "NOT_FOUND",
        });
      }

      // Check if user is member of group
      const membership = await ctx.db
        .query("groupMembers")
        .withIndex("by_group_and_user", (q) =>
          q.eq("groupId", args.groupId!).eq("userId", user._id)
        )
        .unique();

      if (!membership) {
        throw new ConvexError({
          message: "Must be a group member to share reflections with the group",
          code: "FORBIDDEN",
        });
      }
    }

    const reflectionId = await ctx.db.insert("reflections", {
      userId: user._id,
      planId: args.planId,
      entryId: args.entryId,
      content: args.content,
      visibility: args.visibility,
      groupId: args.groupId,
      likeCount: 0,
      commentCount: 0,
      questionIndex: args.questionIndex,
      questionText: args.questionText,
    });

    // Auto-complete reading if all questions are answered
    if (args.entryId !== undefined && args.questionIndex !== undefined) {
      const totalPrompts = plan.reflectionPrompts?.length || 0;
      
      if (totalPrompts > 0) {
        // Get all reflections for this entry by this user
        const userReflections = await ctx.db
          .query("reflections")
          .withIndex("by_entry", (q) => q.eq("entryId", args.entryId!))
          .filter((q) => q.eq(q.field("userId"), user._id))
          .collect();

        // Count unique question indices answered
        const answeredIndices = new Set(
          userReflections
            .map((r) => r.questionIndex)
            .filter((idx): idx is number => idx !== undefined)
        );

        // If all questions are answered, mark entry as complete
        if (answeredIndices.size >= totalPrompts) {
          const entry = await ctx.db.get(args.entryId);
          if (entry) {
            const membership = await ctx.db
              .query("planMembers")
              .withIndex("by_user_and_plan", (q) =>
                q.eq("userId", user._id).eq("planId", args.planId)
              )
              .unique();

            if (membership) {
              const completedEntries = membership.completedEntries || [];
              if (!completedEntries.includes(entry.order)) {
                completedEntries.push(entry.order);

                // Calculate progress
                const totalEntries = await ctx.db
                  .query("planEntries")
                  .withIndex("by_plan", (q) => q.eq("planId", args.planId))
                  .collect();

                const progress =
                  totalEntries.length > 0
                    ? Math.round((completedEntries.length / totalEntries.length) * 100)
                    : 0;

                await ctx.db.patch(membership._id, {
                  completedEntries,
                  progress,
                  currentEntryOrder: entry.order,
                });
              }
            }
          }
        }
      }
    }

    return reflectionId;
  },
});

// Update a reflection
export const update = mutation({
  args: {
    reflectionId: v.id("reflections"),
    content: v.optional(v.string()),
    visibility: v.optional(v.union(v.literal("public"), v.literal("private"), v.literal("group"))),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const reflection = await ctx.db.get(args.reflectionId);
    if (!reflection) {
      throw new ConvexError({
        message: "Reflection not found",
        code: "NOT_FOUND",
      });
    }

    if (reflection.userId !== user._id) {
      throw new ConvexError({
        message: "Only the author can update this reflection",
        code: "FORBIDDEN",
      });
    }

    const updates: Partial<Doc<"reflections">> = {};
    if (args.content !== undefined) updates.content = args.content;
    if (args.visibility !== undefined) updates.visibility = args.visibility;

    await ctx.db.patch(args.reflectionId, updates);
  },
});

// Archive a reflection (soft delete)
export const archiveReflection = mutation({
  args: { reflectionId: v.id("reflections") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const reflection = await ctx.db.get(args.reflectionId);
    if (!reflection) {
      throw new ConvexError({
        message: "Reflection not found",
        code: "NOT_FOUND",
      });
    }

    if (reflection.userId !== user._id) {
      throw new ConvexError({
        message: "Only the author can archive this reflection",
        code: "FORBIDDEN",
      });
    }

    // Archive the reflection (soft delete)
    await ctx.db.patch(args.reflectionId, {
      isArchived: true,
      archivedAt: Date.now(),
    });
  },
});

// Unarchive a reflection
export const unarchiveReflection = mutation({
  args: { reflectionId: v.id("reflections") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const reflection = await ctx.db.get(args.reflectionId);
    if (!reflection) {
      throw new ConvexError({
        message: "Reflection not found",
        code: "NOT_FOUND",
      });
    }

    if (reflection.userId !== user._id) {
      throw new ConvexError({
        message: "Only the author can unarchive this reflection",
        code: "FORBIDDEN",
      });
    }

    // Unarchive the reflection
    await ctx.db.patch(args.reflectionId, {
      isArchived: false,
      archivedAt: undefined,
    });
  },
});

// Delete a reflection (kept for backward compatibility, but archives instead)
export const deleteReflection = mutation({
  args: { reflectionId: v.id("reflections") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const reflection = await ctx.db.get(args.reflectionId);
    if (!reflection) {
      throw new ConvexError({
        message: "Reflection not found",
        code: "NOT_FOUND",
      });
    }

    if (reflection.userId !== user._id) {
      throw new ConvexError({
        message: "Only the author can delete this reflection",
        code: "FORBIDDEN",
      });
    }

    // Archive the reflection (soft delete)
    await ctx.db.patch(args.reflectionId, {
      isArchived: true,
      archivedAt: Date.now(),
    });
  },
});

// Toggle like on a reflection
export const toggleLike = mutation({
  args: { reflectionId: v.id("reflections") },
  handler: async (ctx, args): Promise<boolean> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const reflection = await ctx.db.get(args.reflectionId);
    if (!reflection) {
      throw new ConvexError({
        message: "Reflection not found",
        code: "NOT_FOUND",
      });
    }

    // Check if already liked
    const existingLike = await ctx.db
      .query("reflectionLikes")
      .withIndex("by_reflection_and_user", (q) =>
        q.eq("reflectionId", args.reflectionId).eq("userId", user._id)
      )
      .unique();

    if (existingLike) {
      // Unlike
      await ctx.db.delete(existingLike._id);
      await ctx.db.patch(args.reflectionId, {
        likeCount: Math.max(0, reflection.likeCount - 1),
      });
      return false;
    } else {
      // Like
      await ctx.db.insert("reflectionLikes", {
        reflectionId: args.reflectionId,
        userId: user._id,
      });
      await ctx.db.patch(args.reflectionId, {
        likeCount: reflection.likeCount + 1,
      });
      return true;
    }
  },
});

// Add a comment to a reflection
export const addComment = mutation({
  args: {
    reflectionId: v.id("reflections"),
    content: v.string(),
  },
  handler: async (ctx, args): Promise<Id<"reflectionComments">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const reflection = await ctx.db.get(args.reflectionId);
    if (!reflection) {
      throw new ConvexError({
        message: "Reflection not found",
        code: "NOT_FOUND",
      });
    }

    const commentId = await ctx.db.insert("reflectionComments", {
      reflectionId: args.reflectionId,
      userId: user._id,
      content: args.content,
    });

    // Update comment count
    await ctx.db.patch(args.reflectionId, {
      commentCount: reflection.commentCount + 1,
    });

    return commentId;
  },
});

// Delete a comment
export const deleteComment = mutation({
  args: { commentId: v.id("reflectionComments") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const comment = await ctx.db.get(args.commentId);
    if (!comment) {
      throw new ConvexError({
        message: "Comment not found",
        code: "NOT_FOUND",
      });
    }

    if (comment.userId !== user._id) {
      throw new ConvexError({
        message: "Only the author can delete this comment",
        code: "FORBIDDEN",
      });
    }

    const reflection = await ctx.db.get(comment.reflectionId);
    if (reflection) {
      await ctx.db.patch(comment.reflectionId, {
        commentCount: Math.max(0, reflection.commentCount - 1),
      });
    }

    await ctx.db.delete(args.commentId);
  },
});

// Get reflections for current user (non-archived only)
export const getMyReflections = query({
  args: {},
  handler: async (
    ctx
  ): Promise<
    Array<
      Doc<"reflections"> & {
        authorName: string;
        authorAvatar: string | null;
        planTitle: string;
        entryTitle: string | null;
        entryScheduledDate: string | null;
        isLikedByUser: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    const reflections = await ctx.db
      .query("reflections")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .filter((q) => q.neq(q.field("isArchived"), true))
      .collect();

    return await Promise.all(
      reflections.map(async (reflection) => {
        const author = await ctx.db.get(reflection.userId);
        const plan = await ctx.db.get(reflection.planId);
        const entry = reflection.entryId ? await ctx.db.get(reflection.entryId) : null;
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        const isLiked = !!(await ctx.db
          .query("reflectionLikes")
          .withIndex("by_reflection_and_user", (q) =>
            q.eq("reflectionId", reflection._id).eq("userId", user._id)
          )
          .unique());

        return {
          ...reflection,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          planTitle: plan?.title || "Unknown Plan",
          entryTitle: entry?.title || null,
          entryScheduledDate: entry?.scheduledDate || null,
          isLikedByUser: isLiked,
        };
      })
    );
  },
});

// Get reflections for a plan
export const getReflectionsByPlan = query({
  args: { planId: v.id("readingPlans") },
  handler: async (
    ctx,
    args
  ): Promise<
    Array<
      Doc<"reflections"> & {
        authorName: string;
        authorAvatar: string | null;
        entryTitle: string | null;
        isLikedByUser: boolean;
        isAuthor: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    const currentUser = identity
      ? await ctx.db
          .query("users")
          .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
          .unique()
      : null;

    const reflections = await ctx.db
      .query("reflections")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .order("desc")
      .collect();

    // Filter by visibility
    const visibleReflections = reflections.filter((reflection) => {
      if (reflection.visibility === "public") return true;
      if (currentUser && reflection.userId === currentUser._id) return true;
      if (reflection.visibility === "private") return false;
      // TODO: Check group membership for group visibility
      return false;
    });

    return await Promise.all(
      visibleReflections.map(async (reflection) => {
        const author = await ctx.db.get(reflection.userId);
        const entry = reflection.entryId ? await ctx.db.get(reflection.entryId) : null;
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        const isLiked = currentUser
          ? !!(await ctx.db
              .query("reflectionLikes")
              .withIndex("by_reflection_and_user", (q) =>
                q.eq("reflectionId", reflection._id).eq("userId", currentUser._id)
              )
              .unique())
          : false;

        return {
          ...reflection,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          entryTitle: entry?.title || null,
          isLikedByUser: isLiked,
          isAuthor: currentUser ? reflection.userId === currentUser._id : false,
        };
      })
    );
  },
});

// Get comments for a reflection
export const getComments = query({
  args: { reflectionId: v.id("reflections") },
  handler: async (
    ctx,
    args
  ): Promise<
    Array<
      Doc<"reflectionComments"> & {
        authorName: string;
        authorAvatar: string | null;
        isAuthor: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    const currentUser = identity
      ? await ctx.db
          .query("users")
          .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
          .unique()
      : null;

    const comments = await ctx.db
      .query("reflectionComments")
      .withIndex("by_reflection", (q) => q.eq("reflectionId", args.reflectionId))
      .order("asc")
      .collect();

    return await Promise.all(
      comments.map(async (comment) => {
        const author = await ctx.db.get(comment.userId);
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        return {
          ...comment,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          isAuthor: currentUser ? comment.userId === currentUser._id : false,
        };
      })
    );
  },
});

// Get reflections for a group
export const getReflectionsByGroup = query({
  args: { groupId: v.id("groups") },
  handler: async (
    ctx,
    args
  ): Promise<
    Array<
      Doc<"reflections"> & {
        authorName: string;
        authorAvatar: string | null;
        planTitle: string;
        entryTitle: string | null;
        isLikedByUser: boolean;
        isAuthor: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    const currentUser = identity
      ? await ctx.db
          .query("users")
          .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
          .unique()
      : null;

    if (!currentUser) {
      return [];
    }

    // Check if user is a member of the group
    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", currentUser._id)
      )
      .unique();

    if (!membership) {
      return [];
    }

    const reflections = await ctx.db
      .query("reflections")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .order("desc")
      .collect();

    return await Promise.all(
      reflections.map(async (reflection) => {
        const author = await ctx.db.get(reflection.userId);
        const plan = await ctx.db.get(reflection.planId);
        const entry = reflection.entryId ? await ctx.db.get(reflection.entryId) : null;
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        const isLiked = !!(await ctx.db
          .query("reflectionLikes")
          .withIndex("by_reflection_and_user", (q) =>
            q.eq("reflectionId", reflection._id).eq("userId", currentUser._id)
          )
          .unique());

        return {
          ...reflection,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          planTitle: plan?.title || "Unknown Plan",
          entryTitle: entry?.title || null,
          isLikedByUser: isLiked,
          isAuthor: reflection.userId === currentUser._id,
        };
      })
    );
  },
});

// Get reflections for a specific entry by the current user
export const getReflectionsByEntry = query({
  args: { 
    entryId: v.id("planEntries"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    // Get user's reflections for this entry
    const reflections = await ctx.db
      .query("reflections")
      .withIndex("by_entry", (q) => q.eq("entryId", args.entryId))
      .filter((q) => q.eq(q.field("userId"), user._id))
      .order("desc")
      .collect();

    return reflections;
  },
});

// Get all reflections for a plan by the current user
export const getMyReflectionsByPlan = query({
  args: {
    planId: v.id("readingPlans"),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    // Get user's reflections for this plan
    const reflections = await ctx.db
      .query("reflections")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .filter((q) => q.eq(q.field("userId"), user._id))
      .order("desc")
      .collect();

    return reflections;
  },
});

// Get recent reflections for current user (last 7 days, auto-archive after 14 days)
export const getRecentReflections = query({
  args: {},
  handler: async (ctx): Promise<
    Array<
      Doc<"reflections"> & {
        authorName: string;
        authorAvatar: string | null;
        planTitle: string;
        entryTitle: string | null;
        entryScheduledDate: string | null;
        isLikedByUser: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    // Get reflections from last 7 days
    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const fourteenDaysAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
    
    const reflections = await ctx.db
      .query("reflections")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .filter((q) => 
        q.and(
          q.gte(q.field("_creationTime"), sevenDaysAgo),
          q.neq(q.field("isArchived"), true)
        )
      )
      .take(20);

    return await Promise.all(
      reflections.map(async (reflection) => {
        const author = await ctx.db.get(reflection.userId);
        const plan = await ctx.db.get(reflection.planId);
        const entry = reflection.entryId ? await ctx.db.get(reflection.entryId) : null;
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        const isLiked = !!(await ctx.db
          .query("reflectionLikes")
          .withIndex("by_reflection_and_user", (q) =>
            q.eq("reflectionId", reflection._id).eq("userId", user._id)
          )
          .unique());

        return {
          ...reflection,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          planTitle: plan?.title || "Unknown Plan",
          entryTitle: entry?.title || null,
          entryScheduledDate: entry?.scheduledDate || null,
          isLikedByUser: isLiked,
        };
      })
    );
  },
});

// Get archived reflections for current user
export const getArchivedReflections = query({
  args: {},
  handler: async (
    ctx
  ): Promise<
    Array<
      Doc<"reflections"> & {
        authorName: string;
        authorAvatar: string | null;
        planTitle: string;
        entryTitle: string | null;
        entryScheduledDate: string | null;
        isLikedByUser: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    const reflections = await ctx.db
      .query("reflections")
      .withIndex("by_user_and_archived", (q) => q.eq("userId", user._id).eq("isArchived", true))
      .order("desc")
      .collect();

    return await Promise.all(
      reflections.map(async (reflection) => {
        const author = await ctx.db.get(reflection.userId);
        const plan = await ctx.db.get(reflection.planId);
        const entry = reflection.entryId ? await ctx.db.get(reflection.entryId) : null;
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        const isLiked = !!(await ctx.db
          .query("reflectionLikes")
          .withIndex("by_reflection_and_user", (q) =>
            q.eq("reflectionId", reflection._id).eq("userId", user._id)
          )
          .unique());

        return {
          ...reflection,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          planTitle: plan?.title || "Unknown Plan",
          entryTitle: entry?.title || null,
          entryScheduledDate: entry?.scheduledDate || null,
          isLikedByUser: isLiked,
        };
      })
    );
  },
});

// Search reflections with filters
export const searchReflections = query({
  args: {
    searchQuery: v.optional(v.string()),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    planId: v.optional(v.id("readingPlans")),
    includeArchived: v.optional(v.boolean()),
  },
  handler: async (ctx, args): Promise<
    Array<
      Doc<"reflections"> & {
        authorName: string;
        authorAvatar: string | null;
        planTitle: string;
        entryTitle: string | null;
        entryScheduledDate: string | null;
        bibleReferences: string[];
        isLikedByUser: boolean;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    // Get all user's reflections
    let reflections = await ctx.db
      .query("reflections")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .collect();

    // Filter by archived status
    if (!args.includeArchived) {
      reflections = reflections.filter((r) => !r.isArchived);
    }

    // Filter by plan
    if (args.planId) {
      reflections = reflections.filter((r) => r.planId === args.planId);
    }

    // Filter by date range
    if (args.startDate) {
      const startTime = new Date(args.startDate).getTime();
      reflections = reflections.filter((r) => r._creationTime >= startTime);
    }
    if (args.endDate) {
      const endTime = new Date(args.endDate).getTime() + 24 * 60 * 60 * 1000; // End of day
      reflections = reflections.filter((r) => r._creationTime <= endTime);
    }

    // Build results with full info
    let results = await Promise.all(
      reflections.map(async (reflection) => {
        const author = await ctx.db.get(reflection.userId);
        const plan = await ctx.db.get(reflection.planId);
        const entry = reflection.entryId ? await ctx.db.get(reflection.entryId) : null;
        const authorAvatar = author?.avatarStorageId
          ? await ctx.storage.getUrl(author.avatarStorageId)
          : null;

        const isLiked = !!(await ctx.db
          .query("reflectionLikes")
          .withIndex("by_reflection_and_user", (q) =>
            q.eq("reflectionId", reflection._id).eq("userId", user._id)
          )
          .unique());

        return {
          ...reflection,
          authorName: author?.name || "Anonymous",
          authorAvatar,
          planTitle: plan?.title || "Unknown Plan",
          entryTitle: entry?.title || null,
          entryScheduledDate: entry?.scheduledDate || null,
          bibleReferences: entry?.bibleReferences || [],
          isLikedByUser: isLiked,
        };
      })
    );

    // Filter by search query (content, title, bible reference, or question text)
    if (args.searchQuery && args.searchQuery.trim()) {
      const query = args.searchQuery.toLowerCase();
      results = results.filter((r) => {
        const contentMatch = r.content.toLowerCase().includes(query);
        const titleMatch = r.entryTitle?.toLowerCase().includes(query);
        const planTitleMatch = r.planTitle.toLowerCase().includes(query);
        const questionMatch = r.questionText?.toLowerCase().includes(query);
        const bibleMatch = r.bibleReferences.some((ref) => ref.toLowerCase().includes(query));
        return contentMatch || titleMatch || planTitleMatch || questionMatch || bibleMatch;
      });
    }

    return results;
  },
});

// Auto-archive reflections older than 14 days (called periodically)
export const autoArchiveOldReflections = mutation({
  args: {},
  handler: async (ctx): Promise<number> => {
    const fourteenDaysAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;

    // Get all non-archived reflections older than 14 days
    const oldReflections = await ctx.db
      .query("reflections")
      .filter((q) =>
        q.and(
          q.lt(q.field("_creationTime"), fourteenDaysAgo),
          q.neq(q.field("isArchived"), true)
        )
      )
      .collect();

    // Archive them
    for (const reflection of oldReflections) {
      await ctx.db.patch(reflection._id, {
        isArchived: true,
        archivedAt: Date.now(),
      });
    }

    return oldReflections.length;
  },
});
