import { ConvexError, v } from "convex/values";
import { mutation, query, type QueryCtx, type MutationCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel.d.ts";

// Helper to check if user is admin
async function requireAdmin(ctx: QueryCtx | MutationCtx): Promise<Doc<"users">> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) {
    throw new ConvexError({
      code: "UNAUTHENTICATED",
      message: "User not logged in",
    });
  }

  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();

  if (!user || user.role !== "admin") {
    throw new ConvexError({
      code: "FORBIDDEN",
      message: "Admin access required",
    });
  }

  return user;
}

// Platform Analytics
export const getPlatformStats = query({
  args: {},
  handler: async (ctx): Promise<{
    totalUsers: number;
    totalPlans: number;
    totalGroups: number;
    totalReflections: number;
    activeUsers: number;
    publishedPlans: number;
  }> => {
    await requireAdmin(ctx);

    try {
      // Get counts with limits to avoid timeouts
      const allUsers = await ctx.db.query("users").take(10000);
      const allPlans = await ctx.db.query("readingPlans").take(10000);
      const allGroups = await ctx.db.query("groups").take(10000);
      const allReflections = await ctx.db.query("reflections").take(10000);

      // Count active users (defensive check)
      const activeUsers = allUsers.filter((u) => u.isOnboarded === true).length;
      
      // Count published plans (defensive check)
      const publishedPlans = allPlans.filter((p) => p.status && p.status === "published").length;

      return {
        totalUsers: allUsers.length,
        totalPlans: allPlans.length,
        totalGroups: allGroups.length,
        totalReflections: allReflections.length,
        activeUsers,
        publishedPlans,
      };
    } catch (error) {
      console.error("Error in getPlatformStats:", error);
      throw new ConvexError({
        code: "EXTERNAL_SERVICE_ERROR",
        message: "Failed to fetch platform statistics",
      });
    }
  },
});

// User Management
export const getAllUsers = query({
  args: {},
  handler: async (ctx): Promise<Array<{
    _id: Id<"users">;
    _creationTime: number;
    name?: string;
    email?: string;
    role?: "user" | "admin";
    isOnboarded?: boolean;
    avatarUrl: string | null;
    planCount: number;
    groupCount: number;
    reflectionCount: number;
  }>> => {
    await requireAdmin(ctx);

    const users = await ctx.db.query("users").order("desc").collect();
    const allPlans = await ctx.db.query("readingPlans").collect();
    const allGroupMembers = await ctx.db.query("groupMembers").collect();
    const allReflections = await ctx.db.query("reflections").collect();

    return await Promise.all(
      users.map(async (user) => {
        let avatarUrl: string | null = null;
        if (user.avatarStorageId) {
          avatarUrl = await ctx.storage.getUrl(user.avatarStorageId);
        }

        const planCount = allPlans.filter((p) => p.ownerId === user._id).length;
        const groupCount = allGroupMembers.filter((gm) => gm.userId === user._id).length;
        const reflectionCount = allReflections.filter((r) => r.userId === user._id).length;

        return {
          _id: user._id,
          _creationTime: user._creationTime,
          name: user.name,
          email: user.email,
          role: user.role,
          isOnboarded: user.isOnboarded,
          avatarUrl,
          planCount,
          groupCount,
          reflectionCount,
        };
      })
    );
  },
});

export const updateUserRole = mutation({
  args: {
    userId: v.id("users"),
    role: v.union(v.literal("user"), v.literal("admin")),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    await ctx.db.patch(args.userId, {
      role: args.role,
    });

    return args.userId;
  },
});

export const deleteUser = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    // Delete user's avatar if exists
    const user = await ctx.db.get(args.userId);
    if (user?.avatarStorageId) {
      await ctx.storage.delete(user.avatarStorageId);
    }

    // Delete user's plans
    const userPlans = await ctx.db
      .query("readingPlans")
      .withIndex("by_owner", (q) => q.eq("ownerId", args.userId))
      .collect();
    for (const plan of userPlans) {
      await ctx.db.delete(plan._id);
    }

    // Delete user's reflections
    const userReflections = await ctx.db
      .query("reflections")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .collect();
    for (const reflection of userReflections) {
      await ctx.db.delete(reflection._id);
    }

    // Delete user
    await ctx.db.delete(args.userId);

    return args.userId;
  },
});

// Plan Management
export const getAllPlans = query({
  args: {},
  handler: async (ctx): Promise<Array<{
    _id: Id<"readingPlans">;
    _creationTime: number;
    title: string;
    description?: string;
    status: "draft" | "pending_approval" | "published" | "archived";
    visibility: "public" | "private";
    owner: {
      _id: Id<"users">;
      name?: string;
      email?: string;
    } | null;
    memberCount: number;
    entryCount: number;
  }>> => {
    await requireAdmin(ctx);

    const plans = await ctx.db.query("readingPlans").order("desc").collect();
    const allMembers = await ctx.db.query("planMembers").collect();
    const allEntries = await ctx.db.query("planEntries").collect();

    return await Promise.all(
      plans.map(async (plan) => {
        const owner = await ctx.db.get(plan.ownerId);
        const memberCount = allMembers.filter((m) => m.planId === plan._id).length;
        const entryCount = allEntries.filter((e) => e.planId === plan._id).length;

        return {
          _id: plan._id,
          _creationTime: plan._creationTime,
          title: plan.title,
          description: plan.description,
          status: plan.status,
          visibility: plan.visibility,
          owner: owner
            ? {
                _id: owner._id,
                name: owner.name,
                email: owner.email,
              }
            : null,
          memberCount,
          entryCount,
        };
      })
    );
  },
});

export const updatePlanStatus = mutation({
  args: {
    planId: v.id("readingPlans"),
    status: v.union(
      v.literal("draft"),
      v.literal("pending_approval"),
      v.literal("published"),
      v.literal("archived")
    ),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    await ctx.db.patch(args.planId, {
      status: args.status,
    });

    return args.planId;
  },
});

export const deletePlan = mutation({
  args: { planId: v.id("readingPlans") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    // Delete plan entries
    const entries = await ctx.db
      .query("planEntries")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();
    for (const entry of entries) {
      await ctx.db.delete(entry._id);
    }

    // Delete plan members
    const members = await ctx.db
      .query("planMembers")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();
    for (const member of members) {
      await ctx.db.delete(member._id);
    }

    // Delete plan
    await ctx.db.delete(args.planId);

    return args.planId;
  },
});

// Group Management
export const getAllGroups = query({
  args: {},
  handler: async (ctx): Promise<Array<{
    _id: Id<"groups">;
    _creationTime: number;
    name: string;
    description?: string;
    visibility: "public" | "private";
    memberCount: number;
    owner: {
      _id: Id<"users">;
      name?: string;
      email?: string;
    } | null;
    coverImageUrl: string | null;
    planCount: number;
    reflectionCount: number;
  }>> => {
    await requireAdmin(ctx);

    const groups = await ctx.db.query("groups").order("desc").collect();
    const allGroupPlans = await ctx.db.query("groupPlans").collect();
    const allReflections = await ctx.db.query("reflections").collect();

    return await Promise.all(
      groups.map(async (group) => {
        const owner = await ctx.db.get(group.ownerId);
        let coverImageUrl: string | null = null;
        if (group.coverImageStorageId) {
          coverImageUrl = await ctx.storage.getUrl(group.coverImageStorageId);
        }

        const planCount = allGroupPlans.filter((gp) => gp.groupId === group._id).length;
        const reflectionCount = allReflections.filter((r) => r.groupId === group._id).length;

        return {
          _id: group._id,
          _creationTime: group._creationTime,
          name: group.name,
          description: group.description,
          visibility: group.visibility,
          memberCount: group.memberCount,
          owner: owner
            ? {
                _id: owner._id,
                name: owner.name,
                email: owner.email,
              }
            : null,
          coverImageUrl,
          planCount,
          reflectionCount,
        };
      })
    );
  },
});

export const deleteGroup = mutation({
  args: { groupId: v.id("groups") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    const group = await ctx.db.get(args.groupId);

    // Delete cover image if exists
    if (group?.coverImageStorageId) {
      await ctx.storage.delete(group.coverImageStorageId);
    }

    // Delete group members
    const members = await ctx.db
      .query("groupMembers")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .collect();
    for (const member of members) {
      await ctx.db.delete(member._id);
    }

    // Delete group plans
    const groupPlans = await ctx.db
      .query("groupPlans")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .collect();
    for (const gp of groupPlans) {
      await ctx.db.delete(gp._id);
    }

    // Delete group messages
    const messages = await ctx.db
      .query("groupMessages")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .collect();
    for (const msg of messages) {
      await ctx.db.delete(msg._id);
    }

    // Delete group
    await ctx.db.delete(args.groupId);

    return args.groupId;
  },
});

// Reflection Moderation
export const getAllReflections = query({
  args: {},
  handler: async (ctx): Promise<Array<{
    _id: Id<"reflections">;
    _creationTime: number;
    content: string;
    visibility: "public" | "private" | "group";
    likeCount: number;
    commentCount: number;
    author: {
      _id: Id<"users">;
      name?: string;
      email?: string;
    } | null;
    plan: {
      _id: Id<"readingPlans">;
      title: string;
    } | null;
    group: {
      _id: Id<"groups">;
      name: string;
    } | null;
  }>> => {
    await requireAdmin(ctx);

    const reflections = await ctx.db.query("reflections").order("desc").take(100);

    return await Promise.all(
      reflections.map(async (reflection) => {
        const author = await ctx.db.get(reflection.userId);
        const plan = await ctx.db.get(reflection.planId);
        let group = null;
        if (reflection.groupId) {
          group = await ctx.db.get(reflection.groupId);
        }

        return {
          _id: reflection._id,
          _creationTime: reflection._creationTime,
          content: reflection.content,
          visibility: reflection.visibility,
          likeCount: reflection.likeCount,
          commentCount: reflection.commentCount,
          author: author
            ? {
                _id: author._id,
                name: author.name,
                email: author.email,
              }
            : null,
          plan: plan
            ? {
                _id: plan._id,
                title: plan.title,
              }
            : null,
          group: group
            ? {
                _id: group._id,
                name: group.name,
              }
            : null,
        };
      })
    );
  },
});

export const deleteReflection = mutation({
  args: { reflectionId: v.id("reflections") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    // Delete reflection likes
    const likes = await ctx.db
      .query("reflectionLikes")
      .withIndex("by_reflection", (q) => q.eq("reflectionId", args.reflectionId))
      .collect();
    for (const like of likes) {
      await ctx.db.delete(like._id);
    }

    // Delete reflection comments
    const comments = await ctx.db
      .query("reflectionComments")
      .withIndex("by_reflection", (q) => q.eq("reflectionId", args.reflectionId))
      .collect();
    for (const comment of comments) {
      await ctx.db.delete(comment._id);
    }

    // Delete reflection
    await ctx.db.delete(args.reflectionId);

    return args.reflectionId;
  },
});

// Media Management
export const generateMediaUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireAdmin(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

export const saveMediaFile = mutation({
  args: {
    storageId: v.id("_storage"),
    filename: v.string(),
    fileType: v.string(),
    fileSize: v.number(),
    category: v.union(
      v.literal("icon"),
      v.literal("background"),
      v.literal("image"),
      v.literal("other")
    ),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const admin = await requireAdmin(ctx);

    const mediaId = await ctx.db.insert("mediaFiles", {
      storageId: args.storageId,
      filename: args.filename,
      fileType: args.fileType,
      fileSize: args.fileSize,
      category: args.category,
      uploadedById: admin._id,
      description: args.description,
    });

    return mediaId;
  },
});

export const getAllMediaFiles = query({
  args: {},
  handler: async (ctx): Promise<Array<{
    _id: Id<"mediaFiles">;
    _creationTime: number;
    filename: string;
    fileType: string;
    fileSize: number;
    category: "icon" | "background" | "image" | "other";
    description?: string;
    uploader: {
      _id: Id<"users">;
      name?: string;
    } | null;
    url: string | null;
  }>> => {
    await requireAdmin(ctx);

    const files = await ctx.db.query("mediaFiles").order("desc").collect();

    return await Promise.all(
      files.map(async (file) => {
        const uploader = await ctx.db.get(file.uploadedById);
        const url = await ctx.storage.getUrl(file.storageId);

        return {
          _id: file._id,
          _creationTime: file._creationTime,
          filename: file.filename,
          fileType: file.fileType,
          fileSize: file.fileSize,
          category: file.category,
          description: file.description,
          uploader: uploader
            ? {
                _id: uploader._id,
                name: uploader.name,
              }
            : null,
          url,
        };
      })
    );
  },
});

export const deleteMediaFile = mutation({
  args: { mediaId: v.id("mediaFiles") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    const media = await ctx.db.get(args.mediaId);
    if (!media) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Media file not found",
      });
    }

    // Delete from storage
    await ctx.storage.delete(media.storageId);

    // Delete from database
    await ctx.db.delete(args.mediaId);

    return args.mediaId;
  },
});

// Feedback Management
export const getAllFeedback = query({
  args: {},
  handler: async (ctx): Promise<Array<{
    _id: Id<"feedback">;
    _creationTime: number;
    type: "bug" | "feature" | "feedback";
    title: string;
    description: string;
    status: "new" | "in_progress" | "resolved" | "closed";
    priority?: "low" | "medium" | "high";
    author: {
      _id: Id<"users">;
      name?: string;
      email?: string;
    } | null;
  }>> => {
    await requireAdmin(ctx);

    const feedback = await ctx.db.query("feedback").order("desc").collect();

    return await Promise.all(
      feedback.map(async (item) => {
        const author = await ctx.db.get(item.userId);

        return {
          _id: item._id,
          _creationTime: item._creationTime,
          type: item.type,
          title: item.title,
          description: item.description,
          status: item.status,
          priority: item.priority,
          author: author
            ? {
                _id: author._id,
                name: author.name,
                email: author.email,
              }
            : null,
        };
      })
    );
  },
});

export const updateFeedbackStatus = mutation({
  args: {
    feedbackId: v.id("feedback"),
    status: v.union(
      v.literal("new"),
      v.literal("in_progress"),
      v.literal("resolved"),
      v.literal("closed")
    ),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    await ctx.db.patch(args.feedbackId, {
      status: args.status,
    });

    return args.feedbackId;
  },
});

export const updateFeedbackPriority = mutation({
  args: {
    feedbackId: v.id("feedback"),
    priority: v.union(v.literal("low"), v.literal("medium"), v.literal("high")),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    await ctx.db.patch(args.feedbackId, {
      priority: args.priority,
    });

    return args.feedbackId;
  },
});

export const deleteFeedback = mutation({
  args: { feedbackId: v.id("feedback") },
  handler: async (ctx, args) => {
    await requireAdmin(ctx);

    await ctx.db.delete(args.feedbackId);

    return args.feedbackId;
  },
});
