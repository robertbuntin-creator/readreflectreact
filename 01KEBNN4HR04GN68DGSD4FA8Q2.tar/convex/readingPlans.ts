import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";

export const create = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    visibility: v.union(v.literal("public"), v.literal("private")),
    scheduleType: v.union(
      v.literal("daily"),
      v.literal("weekly"),
      v.literal("custom")
    ),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    color: v.optional(v.string()),
    labels: v.optional(v.array(v.string())),
    reminderEnabled: v.optional(v.boolean()),
    reflectionPrompts: v.optional(v.array(v.string())),
    customWeeklySchedule: v.optional(
      v.array(
        v.object({
          day: v.union(
            v.literal("monday"),
            v.literal("tuesday"),
            v.literal("wednesday"),
            v.literal("thursday"),
            v.literal("friday"),
            v.literal("saturday"),
            v.literal("sunday")
          ),
          type: v.union(
            v.literal("reading"),
            v.literal("meeting"),
            v.literal("sabbath")
          ),
        })
      )
    ),
    resourceMaterials: v.optional(
      v.array(
        v.object({
          title: v.string(),
          url: v.string(),
        })
      )
    ),
  },
  handler: async (ctx, args): Promise<Id<"readingPlans">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    // Public plans require admin approval unless created by admin
    const status =
      args.visibility === "public" && user.role !== "admin"
        ? "pending_approval"
        : "published";

    const planId = await ctx.db.insert("readingPlans", {
      title: args.title,
      description: args.description,
      ownerId: user._id,
      status: status,
      visibility: args.visibility,
      scheduleType: args.scheduleType,
      startDate: args.startDate,
      endDate: args.endDate,
      color: args.color,
      labels: args.labels,
      reminderEnabled: args.reminderEnabled,
      reflectionPrompts: args.reflectionPrompts,
      customWeeklySchedule: args.customWeeklySchedule,
      resourceMaterials: args.resourceMaterials,
    });

    // Auto-enroll creator in the plan
    await ctx.db.insert("planMembers", {
      userId: user._id,
      planId: planId,
      progress: 0,
      completedEntries: [],
    });

    return planId;
  },
});

export const update = mutation({
  args: {
    planId: v.id("readingPlans"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    visibility: v.optional(v.union(v.literal("public"), v.literal("private"))),
    scheduleType: v.optional(
      v.union(v.literal("daily"), v.literal("weekly"), v.literal("custom"))
    ),
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
    color: v.optional(v.string()),
    labels: v.optional(v.array(v.string())),
    reminderEnabled: v.optional(v.boolean()),
    reflectionPrompts: v.optional(v.array(v.string())),
    customWeeklySchedule: v.optional(
      v.array(
        v.object({
          day: v.union(
            v.literal("monday"),
            v.literal("tuesday"),
            v.literal("wednesday"),
            v.literal("thursday"),
            v.literal("friday"),
            v.literal("saturday"),
            v.literal("sunday")
          ),
          type: v.union(
            v.literal("reading"),
            v.literal("meeting"),
            v.literal("sabbath")
          ),
        })
      )
    ),
    resourceMaterials: v.optional(
      v.array(
        v.object({
          title: v.string(),
          url: v.string(),
        })
      )
    ),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Only owner or admin can edit
    if (plan.ownerId !== user._id && user.role !== "admin") {
      throw new ConvexError({
        code: "FORBIDDEN",
        message: "You don't have permission to edit this plan",
      });
    }

    // Handle visibility change (public plans require admin approval unless user is admin)
    const patchData: Record<string, unknown> = {
      ...(args.title !== undefined && { title: args.title }),
      ...(args.description !== undefined && { description: args.description }),
      ...(args.scheduleType !== undefined && { scheduleType: args.scheduleType }),
      ...(args.startDate !== undefined && { startDate: args.startDate }),
      ...(args.endDate !== undefined && { endDate: args.endDate }),
      ...(args.color !== undefined && { color: args.color }),
      ...(args.labels !== undefined && { labels: args.labels }),
      ...(args.reminderEnabled !== undefined && {
        reminderEnabled: args.reminderEnabled,
      }),
      ...(args.reflectionPrompts !== undefined && {
        reflectionPrompts: args.reflectionPrompts,
      }),
      ...(args.customWeeklySchedule !== undefined && {
        customWeeklySchedule: args.customWeeklySchedule,
      }),
      ...(args.resourceMaterials !== undefined && {
        resourceMaterials: args.resourceMaterials,
      }),
    };

    // Handle visibility and status updates
    if (args.visibility !== undefined) {
      patchData.visibility = args.visibility;
      // If changing to public and not admin, require approval
      if (args.visibility === "public" && user.role !== "admin") {
        patchData.status = "pending_approval";
      } else if (args.visibility === "public" && user.role === "admin") {
        patchData.status = "published";
      }
      // If changing to private, set to published
      if (args.visibility === "private") {
        patchData.status = "published";
      }
    }

    await ctx.db.patch(args.planId, patchData);
  },
});

export const deletePlan = mutation({
  args: {
    planId: v.id("readingPlans"),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Only owner or admin can delete
    if (plan.ownerId !== user._id && user.role !== "admin") {
      throw new ConvexError({
        code: "FORBIDDEN",
        message: "You don't have permission to delete this plan",
      });
    }

    // Delete all plan entries
    const entries = await ctx.db
      .query("planEntries")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();
    for (const entry of entries) {
      await ctx.db.delete(entry._id);
    }

    // Delete all plan members
    const members = await ctx.db
      .query("planMembers")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();
    for (const member of members) {
      await ctx.db.delete(member._id);
    }

    // Delete the plan
    await ctx.db.delete(args.planId);
  },
});

export const duplicate = mutation({
  args: {
    planId: v.id("readingPlans"),
    newTitle: v.string(),
  },
  handler: async (ctx, args): Promise<Id<"readingPlans">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Check if user already has a plan with this title
    const userPlans = await ctx.db
      .query("readingPlans")
      .withIndex("by_owner", (q) => q.eq("ownerId", user._id))
      .collect();
    
    const duplicateTitle = userPlans.find((p) => p.title === args.newTitle);
    if (duplicateTitle) {
      throw new ConvexError({
        code: "CONFLICT",
        message: "You already have a plan with this title. Please choose a different name.",
      });
    }

    // Create duplicate plan
    const newPlanId = await ctx.db.insert("readingPlans", {
      title: args.newTitle,
      description: plan.description,
      ownerId: user._id,
      status: "draft",
      visibility: "private",
      scheduleType: plan.scheduleType,
      startDate: plan.startDate,
      endDate: plan.endDate,
      color: plan.color,
      labels: plan.labels,
      reminderEnabled: plan.reminderEnabled,
      reflectionPrompts: plan.reflectionPrompts,
      customWeeklySchedule: plan.customWeeklySchedule,
      resourceMaterials: plan.resourceMaterials,
    });

    // Duplicate all entries
    const entries = await ctx.db
      .query("planEntries")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();
    for (const entry of entries) {
      await ctx.db.insert("planEntries", {
        planId: newPlanId,
        title: entry.title,
        description: entry.description,
        content: entry.content,
        order: entry.order,
        scheduledDate: entry.scheduledDate,
        externalLinks: entry.externalLinks,
        bibleReferences: entry.bibleReferences,
      });
    }

    // Enroll creator
    await ctx.db.insert("planMembers", {
      userId: user._id,
      planId: newPlanId,
      progress: 0,
      completedEntries: [],
    });

    return newPlanId;
  },
});

export const getMyPlans = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      return [];
    }

    // Get plans where user is enrolled
    const memberships = await ctx.db
      .query("planMembers")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const plans = await Promise.all(
      memberships.map(async (membership) => {
        const plan = await ctx.db.get(membership.planId);
        if (!plan) return null;

        const owner = await ctx.db.get(plan.ownerId);
        const entries = await ctx.db
          .query("planEntries")
          .withIndex("by_plan", (q) => q.eq("planId", plan._id))
          .collect();

        const membersCount = await ctx.db
          .query("planMembers")
          .withIndex("by_plan", (q) => q.eq("planId", plan._id))
          .collect();

        // Find today's or next available reading
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStr = today.toISOString().split("T")[0];

        // Sort entries by scheduled date
        const sortedEntries = entries
          .filter((e) => e.scheduledDate)
          .sort((a, b) => {
            const dateA = a.scheduledDate || "";
            const dateB = b.scheduledDate || "";
            return dateA.localeCompare(dateB);
          });

        // Find today's reading or next available
        let currentReading = sortedEntries.find((e) => e.scheduledDate === todayStr);
        if (!currentReading) {
          // Find next available reading (after today)
          currentReading = sortedEntries.find((e) => e.scheduledDate && e.scheduledDate > todayStr);
        }

        return {
          ...plan,
          ownerName: owner?.name || "Unknown",
          entriesCount: entries.length,
          membersCount: membersCount.length,
          userProgress: membership.progress,
          isOwner: plan.ownerId === user._id,
          currentReading: currentReading ? {
            _id: currentReading._id,
            title: currentReading.title,
            scheduledDate: currentReading.scheduledDate,
            bibleReferences: currentReading.bibleReferences,
          } : null,
        };
      })
    );

    return plans.filter((p) => p !== null);
  },
});

export const getPublicPlans = query({
  args: {},
  handler: async (ctx) => {
    const plans = await ctx.db
      .query("readingPlans")
      .withIndex("by_status", (q) => q.eq("status", "published"))
      .collect();

    const publicPlans = plans.filter((p) => p.visibility === "public");

    const plansWithDetails = await Promise.all(
      publicPlans.map(async (plan) => {
        const owner = await ctx.db.get(plan.ownerId);
        const entriesCount = await ctx.db
          .query("planEntries")
          .withIndex("by_plan", (q) => q.eq("planId", plan._id))
          .collect();

        const membersCount = await ctx.db
          .query("planMembers")
          .withIndex("by_plan", (q) => q.eq("planId", plan._id))
          .collect();

        return {
          ...plan,
          ownerName: owner?.name || "Unknown",
          entriesCount: entriesCount.length,
          membersCount: membersCount.length,
        };
      })
    );

    return plansWithDetails;
  },
});

export const getPlanById = query({
  args: { planId: v.id("readingPlans") },
  handler: async (ctx, args) => {
    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      return null;
    }

    const owner = await ctx.db.get(plan.ownerId);
    const entries = await ctx.db
      .query("planEntries")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();

    const members = await ctx.db
      .query("planMembers")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();

    // Get current user's membership if exists
    let userMembership = null;
    const identity = await ctx.auth.getUserIdentity();
    if (identity) {
      const user = await ctx.db
        .query("users")
        .withIndex("by_token", (q) =>
          q.eq("tokenIdentifier", identity.tokenIdentifier)
        )
        .unique();

      if (user) {
        userMembership = members.find((m) => m.userId === user._id) || null;
      }
    }

    return {
      ...plan,
      ownerName: owner?.name || "Unknown",
      entries: entries.sort((a, b) => a.order - b.order),
      membersCount: members.length,
      userMembership,
      isOwner: identity && owner?.tokenIdentifier === identity.tokenIdentifier,
    };
  },
});

export const joinPlan = mutation({
  args: {
    planId: v.id("readingPlans"),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Check if already enrolled
    const existing = await ctx.db
      .query("planMembers")
      .withIndex("by_user_and_plan", (q) =>
        q.eq("userId", user._id).eq("planId", args.planId)
      )
      .unique();

    if (existing) {
      throw new ConvexError({
        code: "CONFLICT",
        message: "Already enrolled in this plan",
      });
    }

    await ctx.db.insert("planMembers", {
      userId: user._id,
      planId: args.planId,
      progress: 0,
      completedEntries: [],
    });
  },
});

export const leavePlan = mutation({
  args: {
    planId: v.id("readingPlans"),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Cannot leave if owner
    if (plan.ownerId === user._id) {
      throw new ConvexError({
        code: "FORBIDDEN",
        message: "Plan owner cannot leave the plan",
      });
    }

    const membership = await ctx.db
      .query("planMembers")
      .withIndex("by_user_and_plan", (q) =>
        q.eq("userId", user._id).eq("planId", args.planId)
      )
      .unique();

    if (membership) {
      await ctx.db.delete(membership._id);
    }
  },
});
