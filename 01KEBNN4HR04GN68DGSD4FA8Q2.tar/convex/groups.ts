import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel.d.ts";
import { ConvexError } from "convex/values";

// Create a new group
export const create = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    visibility: v.union(v.literal("public"), v.literal("private")),
  },
  handler: async (ctx, args): Promise<Id<"groups">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    // Create the group
    const groupId = await ctx.db.insert("groups", {
      name: args.name,
      description: args.description,
      ownerId: user._id,
      visibility: args.visibility,
      memberCount: 1,
    });

    // Add owner as a member
    await ctx.db.insert("groupMembers", {
      groupId,
      userId: user._id,
      role: "owner",
    });

    return groupId;
  },
});

// Update group details
export const update = mutation({
  args: {
    groupId: v.id("groups"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    visibility: v.optional(v.union(v.literal("public"), v.literal("private"))),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const group = await ctx.db.get(args.groupId);
    if (!group) {
      throw new ConvexError({
        message: "Group not found",
        code: "NOT_FOUND",
      });
    }

    // Check if user is owner or admin
    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", user._id)
      )
      .unique();

    if (!membership || (membership.role !== "owner" && membership.role !== "admin")) {
      throw new ConvexError({
        message: "Only group admins can update group details",
        code: "FORBIDDEN",
      });
    }

    const updates: Partial<Doc<"groups">> = {};
    if (args.name !== undefined) updates.name = args.name;
    if (args.description !== undefined) updates.description = args.description;
    if (args.visibility !== undefined) updates.visibility = args.visibility;

    await ctx.db.patch(args.groupId, updates);
  },
});

// Delete a group
export const deleteGroup = mutation({
  args: { groupId: v.id("groups") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const group = await ctx.db.get(args.groupId);
    if (!group) {
      throw new ConvexError({
        message: "Group not found",
        code: "NOT_FOUND",
      });
    }

    if (group.ownerId !== user._id) {
      throw new ConvexError({
        message: "Only the group owner can delete the group",
        code: "FORBIDDEN",
      });
    }

    // Delete all group members
    const members = await ctx.db
      .query("groupMembers")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .collect();
    for (const member of members) {
      await ctx.db.delete(member._id);
    }

    // Delete all group plans
    const groupPlans = await ctx.db
      .query("groupPlans")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .collect();
    for (const groupPlan of groupPlans) {
      await ctx.db.delete(groupPlan._id);
    }

    // Delete the group
    await ctx.db.delete(args.groupId);
  },
});

// Join a group
export const join = mutation({
  args: { groupId: v.id("groups") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const group = await ctx.db.get(args.groupId);
    if (!group) {
      throw new ConvexError({
        message: "Group not found",
        code: "NOT_FOUND",
      });
    }

    // Check if already a member
    const existingMembership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", user._id)
      )
      .unique();

    if (existingMembership) {
      throw new ConvexError({
        message: "Already a member of this group",
        code: "CONFLICT",
      });
    }

    // Add user as member
    await ctx.db.insert("groupMembers", {
      groupId: args.groupId,
      userId: user._id,
      role: "member",
    });

    // Update member count
    await ctx.db.patch(args.groupId, {
      memberCount: group.memberCount + 1,
    });
  },
});

// Leave a group
export const leave = mutation({
  args: { groupId: v.id("groups") },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const group = await ctx.db.get(args.groupId);
    if (!group) {
      throw new ConvexError({
        message: "Group not found",
        code: "NOT_FOUND",
      });
    }

    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", user._id)
      )
      .unique();

    if (!membership) {
      throw new ConvexError({
        message: "Not a member of this group",
        code: "NOT_FOUND",
      });
    }

    if (membership.role === "owner") {
      throw new ConvexError({
        message: "Group owner cannot leave. Delete the group instead.",
        code: "FORBIDDEN",
      });
    }

    // Remove membership
    await ctx.db.delete(membership._id);

    // Update member count
    await ctx.db.patch(args.groupId, {
      memberCount: Math.max(0, group.memberCount - 1),
    });
  },
});

// Share a reading plan with a group
export const sharePlan = mutation({
  args: {
    groupId: v.id("groups"),
    planId: v.id("readingPlans"),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    // Check if user is a member of the group
    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", user._id)
      )
      .unique();

    if (!membership) {
      throw new ConvexError({
        message: "Must be a group member to share plans",
        code: "FORBIDDEN",
      });
    }

    // Check if plan exists
    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        message: "Plan not found",
        code: "NOT_FOUND",
      });
    }

    // Check if already shared
    const existingShare = await ctx.db
      .query("groupPlans")
      .withIndex("by_group_and_plan", (q) =>
        q.eq("groupId", args.groupId).eq("planId", args.planId)
      )
      .unique();

    if (existingShare) {
      throw new ConvexError({
        message: "Plan already shared with this group",
        code: "CONFLICT",
      });
    }

    // Share the plan
    await ctx.db.insert("groupPlans", {
      groupId: args.groupId,
      planId: args.planId,
      sharedById: user._id,
    });
  },
});

// Unshare a reading plan from a group
export const unsharePlan = mutation({
  args: {
    groupId: v.id("groups"),
    planId: v.id("readingPlans"),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        message: "User not logged in",
        code: "UNAUTHENTICATED",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      throw new ConvexError({
        message: "User not found",
        code: "NOT_FOUND",
      });
    }

    const groupPlan = await ctx.db
      .query("groupPlans")
      .withIndex("by_group_and_plan", (q) =>
        q.eq("groupId", args.groupId).eq("planId", args.planId)
      )
      .unique();

    if (!groupPlan) {
      throw new ConvexError({
        message: "Plan not shared with this group",
        code: "NOT_FOUND",
      });
    }

    // Check if user is group admin or the person who shared it
    const membership = await ctx.db
      .query("groupMembers")
      .withIndex("by_group_and_user", (q) =>
        q.eq("groupId", args.groupId).eq("userId", user._id)
      )
      .unique();

    if (
      !membership ||
      (membership.role !== "owner" &&
        membership.role !== "admin" &&
        groupPlan.sharedById !== user._id)
    ) {
      throw new ConvexError({
        message: "Only group admins or the person who shared can unshare",
        code: "FORBIDDEN",
      });
    }

    await ctx.db.delete(groupPlan._id);
  },
});

// Get user's groups
export const getMyGroups = query({
  args: {},
  handler: async (
    ctx
  ): Promise<
    Array<
      Doc<"groups"> & {
        role: "owner" | "admin" | "member";
        ownerName: string;
      }
    >
  > => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      return [];
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();

    if (!user) {
      return [];
    }

    const memberships = await ctx.db
      .query("groupMembers")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .collect();

    const groups = await Promise.all(
      memberships.map(async (membership) => {
        const group = await ctx.db.get(membership.groupId);
        if (!group) return null;

        const owner = await ctx.db.get(group.ownerId);
        return {
          ...group,
          role: membership.role,
          ownerName: owner?.name || "Unknown",
        };
      })
    );

    return groups.filter((g) => g !== null);
  },
});

// Get public groups
export const getPublicGroups = query({
  args: {},
  handler: async (
    ctx
  ): Promise<Array<Doc<"groups"> & { ownerName: string; isMember: boolean }>> => {
    const identity = await ctx.auth.getUserIdentity();
    const user = identity
      ? await ctx.db
          .query("users")
          .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
          .unique()
      : null;

    const groups = await ctx.db
      .query("groups")
      .filter((q) => q.eq(q.field("visibility"), "public"))
      .collect();

    return await Promise.all(
      groups.map(async (group) => {
        const owner = await ctx.db.get(group.ownerId);
        const isMember = user
          ? !!(await ctx.db
              .query("groupMembers")
              .withIndex("by_group_and_user", (q) =>
                q.eq("groupId", group._id).eq("userId", user._id)
              )
              .unique())
          : false;

        return {
          ...group,
          ownerName: owner?.name || "Unknown",
          isMember,
        };
      })
    );
  },
});

// Get group details
export const getGroupById = query({
  args: { groupId: v.id("groups") },
  handler: async (
    ctx,
    args
  ): Promise<
    | (Doc<"groups"> & {
        ownerName: string;
        userRole: "owner" | "admin" | "member" | null;
        members: Array<{
          _id: Id<"users">;
          name: string;
          role: "owner" | "admin" | "member";
          avatarUrl: string | null;
        }>;
        plans: Array<
          Doc<"readingPlans"> & {
            sharedByName: string;
            isUserMember: boolean;
          }
        >;
      })
    | null
  > => {
    const group = await ctx.db.get(args.groupId);
    if (!group) return null;

    const owner = await ctx.db.get(group.ownerId);
    const identity = await ctx.auth.getUserIdentity();
    const currentUser = identity
      ? await ctx.db
          .query("users")
          .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
          .unique()
      : null;

    const userMembership = currentUser
      ? await ctx.db
          .query("groupMembers")
          .withIndex("by_group_and_user", (q) =>
            q.eq("groupId", args.groupId).eq("userId", currentUser._id)
          )
          .unique()
      : null;

    // Get all members
    const memberships = await ctx.db
      .query("groupMembers")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .collect();

    const members = await Promise.all(
      memberships.map(async (membership) => {
        const member = await ctx.db.get(membership.userId);
        if (!member) return null;

        const avatarUrl = member.avatarStorageId
          ? await ctx.storage.getUrl(member.avatarStorageId)
          : null;

        return {
          _id: member._id,
          name: member.name || "Anonymous",
          role: membership.role,
          avatarUrl,
        };
      })
    );

    // Get shared plans
    const groupPlans = await ctx.db
      .query("groupPlans")
      .withIndex("by_group", (q) => q.eq("groupId", args.groupId))
      .collect();

    const plans = await Promise.all(
      groupPlans.map(async (groupPlan) => {
        const plan = await ctx.db.get(groupPlan.planId);
        if (!plan) return null;

        const sharedBy = await ctx.db.get(groupPlan.sharedById);
        const isUserMember = currentUser
          ? !!(await ctx.db
              .query("planMembers")
              .withIndex("by_user_and_plan", (q) =>
                q.eq("userId", currentUser._id).eq("planId", plan._id)
              )
              .unique())
          : false;

        return {
          ...plan,
          sharedByName: sharedBy?.name || "Unknown",
          isUserMember,
        };
      })
    );

    return {
      ...group,
      ownerName: owner?.name || "Unknown",
      userRole: userMembership?.role || null,
      members: members.filter((m) => m !== null),
      plans: plans.filter((p) => p !== null),
    };
  },
});
