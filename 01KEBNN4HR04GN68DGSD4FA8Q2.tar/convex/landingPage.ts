import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const getContent = query({
  args: {},
  handler: async (ctx) => {
    const content = await ctx.db.query("landingPageContent").first();
    
    // Return default content if none exists
    if (!content) {
      return {
        // Landing Page
        heroTitle: "Read Together. Grow Together.",
        heroSubtitle: "Build consistent reading habits",
        heroDescription: "A community-driven platform designed to help you build consistent reading habits, connect with like-minded readers, and transform how you engage with what you read.",
        featuresTitle: "Everything You Need to Read Better",
        featuresDescription: "Powerful tools designed to help you build lasting reading habits and connect with a supportive community.",
        howItWorksTitle: "How It Works",
        howItWorksDescription: "Get started in minutes and begin your journey to better reading habits.",
        missionTitle: "Our Mission",
        missionParagraph1: "We believe that consistent reading and meeting with others is a powerful habit for personal growth, spiritual development, and the joy of learning.",
        missionParagraph2: "Read Reflect React provides structure, community support, and tracking tools to help you stay accountable and connected. Highlight how readings inspire change, review commitments privately, or share them with groups.",
        ctaTitle: "Ready to Transform Your Reading?",
        ctaDescription: "Join thousands of readers who are building better habits, deeper understanding, and meaningful connections through Read Reflect React.",
        logoUrl: "https://cdn.hercules.app/file_WJmevcW9c0nbjU0hNZuMW2rk",
        heroImageUrl: "https://cdn.hercules.app/file_zeQ0h2yMdWHQm4HUHBntzgcy",
        missionImageUrl: "https://cdn.hercules.app/file_ICeWFA5jMtFvV2TMpvNstTbJ",
        inviteDialogTitle: "Invite People to Group",
        inviteDialogDescription: "Share this link with anyone you want to invite to",
        inviteDialogHelpText: "Anyone with this link can view and join this group",
        // Dashboard
        dashboardWelcome: "Welcome back",
        dashboardSubtitle: "Ready to dive into some reading?",
        // My Plans
        myPlansTitle: "My Reading Plans",
        myPlansEmptyTitle: "No reading plans yet",
        myPlansEmptyDescription: "Start your reading journey by creating or joining a plan",
        // Browse Plans
        browsePlansTitle: "Discover Reading Plans",
        browsePlansDescription: "Explore curated reading plans from our community",
        // Start Reading Plan
        startPlanTitle: "Start a Reading Plan",
        startPlanDescription: "Choose how you want to begin your reading journey",
        startPlanBrowseLabel: "Browse Existing Plans",
        startPlanCreateLabel: "Create Your Own Plan",
        // Create Plan
        createPlanTitle: "Create a Reading Plan",
        createPlanDescription: "Set up a structured reading schedule for yourself or your community",
        // Groups
        myGroupsTitle: "My Groups",
        myGroupsEmptyTitle: "No groups joined",
        myGroupsEmptyDescription: "Connect with other readers by joining a community group",
        // Browse Groups
        browseGroupsTitle: "Discover Groups",
        browseGroupsDescription: "Find communities of readers with shared interests",
        // Profile
        profileTitle: "My Profile",
        profileDescription: "Manage your account settings and preferences",
        // Reflections
        reflectionsTitle: "My Reflections",
        reflectionsEmptyTitle: "No reflections yet",
        reflectionsEmptyDescription: "Start reflecting on your reading journey",
        // Feedback
        feedbackTitle: "Send Feedback",
        feedbackDescription: "Help us improve by sharing your thoughts and ideas",
      };
    }
    
    return content;
  },
});

export const updateContent = mutation({
  args: {
    // Landing Page
    heroTitle: v.string(),
    heroSubtitle: v.string(),
    heroDescription: v.string(),
    featuresTitle: v.string(),
    featuresDescription: v.string(),
    howItWorksTitle: v.string(),
    howItWorksDescription: v.string(),
    missionTitle: v.string(),
    missionParagraph1: v.string(),
    missionParagraph2: v.string(),
    ctaTitle: v.string(),
    ctaDescription: v.string(),
    logoUrl: v.optional(v.string()),
    heroImageUrl: v.optional(v.string()),
    missionImageUrl: v.optional(v.string()),
    inviteDialogTitle: v.optional(v.string()),
    inviteDialogDescription: v.optional(v.string()),
    inviteDialogHelpText: v.optional(v.string()),
    // Dashboard
    dashboardWelcome: v.optional(v.string()),
    dashboardSubtitle: v.optional(v.string()),
    // My Plans
    myPlansTitle: v.optional(v.string()),
    myPlansEmptyTitle: v.optional(v.string()),
    myPlansEmptyDescription: v.optional(v.string()),
    myPlansCreateButton: v.optional(v.string()),
    myPlansBrowseButton: v.optional(v.string()),
    // Browse Plans
    browsePlansTitle: v.optional(v.string()),
    browsePlansDescription: v.optional(v.string()),
    // Start Reading Plan
    startPlanTitle: v.optional(v.string()),
    startPlanDescription: v.optional(v.string()),
    startPlanBrowseTitle: v.optional(v.string()),
    startPlanBrowseDescription: v.optional(v.string()),
    startPlanBrowseBullet1: v.optional(v.string()),
    startPlanBrowseBullet2: v.optional(v.string()),
    startPlanBrowseBullet3: v.optional(v.string()),
    startPlanBrowseButton: v.optional(v.string()),
    startPlanCreateTitle: v.optional(v.string()),
    startPlanCreateDescription: v.optional(v.string()),
    startPlanCreateBullet1: v.optional(v.string()),
    startPlanCreateBullet2: v.optional(v.string()),
    startPlanCreateBullet3: v.optional(v.string()),
    startPlanCreateButton: v.optional(v.string()),
    startPlanTipTitle: v.optional(v.string()),
    startPlanTipDescription: v.optional(v.string()),
    // Create Plan
    createPlanTitle: v.optional(v.string()),
    createPlanDescription: v.optional(v.string()),
    // Groups
    myGroupsTitle: v.optional(v.string()),
    myGroupsEmptyTitle: v.optional(v.string()),
    myGroupsEmptyDescription: v.optional(v.string()),
    // Browse Groups
    browseGroupsTitle: v.optional(v.string()),
    browseGroupsDescription: v.optional(v.string()),
    // Profile
    profileTitle: v.optional(v.string()),
    profileDescription: v.optional(v.string()),
    // Reflections
    reflectionsTitle: v.optional(v.string()),
    reflectionsEmptyTitle: v.optional(v.string()),
    reflectionsEmptyDescription: v.optional(v.string()),
    // Feedback
    feedbackTitle: v.optional(v.string()),
    feedbackDescription: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();

    if (!user || user.role !== "admin") {
      throw new ConvexError({
        code: "FORBIDDEN",
        message: "Only admins can update landing page content",
      });
    }

    // Check if content exists
    const existingContent = await ctx.db.query("landingPageContent").first();

    if (existingContent) {
      // Update existing content
      await ctx.db.patch(existingContent._id, args);
      return existingContent._id;
    } else {
      // Create new content
      const id = await ctx.db.insert("landingPageContent", args);
      return id;
    }
  },
});
