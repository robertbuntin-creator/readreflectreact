import { ConvexError, v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Id } from "./_generated/dataModel.d.ts";

export const create = mutation({
  args: {
    planId: v.id("readingPlans"),
    title: v.string(),
    description: v.optional(v.string()),
    content: v.optional(v.string()),
    order: v.number(),
    scheduledDate: v.optional(v.string()),
    externalLinks: v.optional(v.array(v.string())),
    bibleReferences: v.optional(v.array(v.string())),
    reflectionPrompts: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args): Promise<Id<"planEntries">> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const plan = await ctx.db.get(args.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Only owner or admin can add entries
    if (plan.ownerId !== user._id && user.role !== "admin") {
      throw new ConvexError({
        code: "FORBIDDEN",
        message: "You don't have permission to add entries to this plan",
      });
    }

    const entryId = await ctx.db.insert("planEntries", {
      planId: args.planId,
      title: args.title,
      description: args.description,
      content: args.content,
      order: args.order,
      scheduledDate: args.scheduledDate,
      externalLinks: args.externalLinks,
      bibleReferences: args.bibleReferences,
      reflectionPrompts: args.reflectionPrompts,
    });

    return entryId;
  },
});

export const update = mutation({
  args: {
    entryId: v.id("planEntries"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    content: v.optional(v.string()),
    order: v.optional(v.number()),
    scheduledDate: v.optional(v.string()),
    externalLinks: v.optional(v.array(v.string())),
    bibleReferences: v.optional(v.array(v.string())),
    reflectionPrompts: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const entry = await ctx.db.get(args.entryId);
    if (!entry) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Entry not found",
      });
    }

    const plan = await ctx.db.get(entry.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Only owner or admin can edit entries
    if (plan.ownerId !== user._id && user.role !== "admin") {
      throw new ConvexError({
        code: "FORBIDDEN",
        message: "You don't have permission to edit this entry",
      });
    }

    await ctx.db.patch(args.entryId, {
      ...(args.title !== undefined && { title: args.title }),
      ...(args.description !== undefined && { description: args.description }),
      ...(args.content !== undefined && { content: args.content }),
      ...(args.order !== undefined && { order: args.order }),
      ...(args.scheduledDate !== undefined && { scheduledDate: args.scheduledDate }),
      ...(args.externalLinks !== undefined && { externalLinks: args.externalLinks }),
      ...(args.bibleReferences !== undefined && {
        bibleReferences: args.bibleReferences,
      }),
      ...(args.reflectionPrompts !== undefined && {
        reflectionPrompts: args.reflectionPrompts,
      }),
    });
  },
});

export const deleteEntry = mutation({
  args: {
    entryId: v.id("planEntries"),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const entry = await ctx.db.get(args.entryId);
    if (!entry) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Entry not found",
      });
    }

    const plan = await ctx.db.get(entry.planId);
    if (!plan) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Plan not found",
      });
    }

    // Only owner or admin can delete entries
    if (plan.ownerId !== user._id && user.role !== "admin") {
      throw new ConvexError({
        code: "FORBIDDEN",
        message: "You don't have permission to delete this entry",
      });
    }

    await ctx.db.delete(args.entryId);
  },
});

export const getByPlan = query({
  args: { planId: v.id("readingPlans") },
  handler: async (ctx, args) => {
    const entries = await ctx.db
      .query("planEntries")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();

    return entries.sort((a, b) => a.order - b.order);
  },
});

export const markComplete = mutation({
  args: {
    planId: v.id("readingPlans"),
    entryOrder: v.number(),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const membership = await ctx.db
      .query("planMembers")
      .withIndex("by_user_and_plan", (q) =>
        q.eq("userId", user._id).eq("planId", args.planId)
      )
      .unique();

    if (!membership) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Not enrolled in this plan",
      });
    }

    const completedEntries = membership.completedEntries || [];
    if (!completedEntries.includes(args.entryOrder)) {
      completedEntries.push(args.entryOrder);
    }

    // Calculate progress
    const totalEntries = await ctx.db
      .query("planEntries")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();

    const progress =
      totalEntries.length > 0
        ? Math.round((completedEntries.length / totalEntries.length) * 100)
        : 0;

    await ctx.db.patch(membership._id, {
      completedEntries,
      progress,
      currentEntryOrder: args.entryOrder,
    });
  },
});

export const markIncomplete = mutation({
  args: {
    planId: v.id("readingPlans"),
    entryOrder: v.number(),
  },
  handler: async (ctx, args): Promise<void> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier)
      )
      .unique();

    if (!user) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "User not found",
      });
    }

    const membership = await ctx.db
      .query("planMembers")
      .withIndex("by_user_and_plan", (q) =>
        q.eq("userId", user._id).eq("planId", args.planId)
      )
      .unique();

    if (!membership) {
      throw new ConvexError({
        code: "NOT_FOUND",
        message: "Not enrolled in this plan",
      });
    }

    const completedEntries = (membership.completedEntries || []).filter(
      (order) => order !== args.entryOrder
    );

    // Calculate progress
    const totalEntries = await ctx.db
      .query("planEntries")
      .withIndex("by_plan", (q) => q.eq("planId", args.planId))
      .collect();

    const progress =
      totalEntries.length > 0
        ? Math.round((completedEntries.length / totalEntries.length) * 100)
        : 0;

    await ctx.db.patch(membership._id, {
      completedEntries,
      progress,
    });
  },
});
